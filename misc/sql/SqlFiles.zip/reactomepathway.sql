RAMP_P_000049657	R-HSA-8874211	reactome	NA	CREB3 factors activate genes
RAMP_P_000049658	R-HSA-5619107	reactome	NA	Defective TPR may confer susceptibility towards thyroid papillary carcinoma (TPC)
RAMP_P_000049659	R-HSA-390450	reactome	NA	Folding of actin by CCT/TriC
RAMP_P_000049660	R-HSA-432720	reactome	NA	Lysosome Vesicle Biogenesis
RAMP_P_000049661	R-HSA-1483076	reactome	NA	Synthesis of CL
RAMP_P_000049662	R-HSA-5625900	reactome	NA	RHO GTPases activate CIT
RAMP_P_000049663	R-HSA-156711	reactome	NA	Polo-like kinase mediated events
RAMP_P_000049664	R-HSA-77108	reactome	NA	Utilization of Ketone Bodies
RAMP_P_000049665	R-HSA-4719360	reactome	NA	Defective DPM3 causes DPM3-CDG (CDG-1o)
RAMP_P_000049666	R-HSA-5689896	reactome	NA	Ovarian tumor domain proteases
RAMP_P_000049667	R-HSA-9022538	reactome	NA	Loss of MECP2 binding ability to 5mC-DNA
RAMP_P_000049668	R-HSA-9615017	reactome	NA	FOXO-mediated transcription of oxidative stress, metabolic and neuronal genes
RAMP_P_000049669	R-HSA-446353	reactome	NA	Cell-extracellular matrix interactions
RAMP_P_000049670	R-HSA-1855183	reactome	NA	Synthesis of IP2, IP, and Ins in the cytosol
RAMP_P_000049671	R-HSA-5579011	reactome	NA	Defective CYP2U1 causes Spastic paraplegia 56, autosomal recessive (SPG56)
RAMP_P_000049672	R-HSA-211958	reactome	NA	Miscellaneous substrates
RAMP_P_000049673	R-HSA-9026357	reactome	NA	NTF4 activates NTRK2 (TRKB) signaling
RAMP_P_000049674	R-HSA-140837	reactome	NA	Intrinsic Pathway of Fibrin Clot Formation
RAMP_P_000049675	R-HSA-5619092	reactome	NA	Defective SLC9A6 causes  X-linked, syndromic mental retardation,, Christianson type (MRXSCH)
RAMP_P_000049676	R-HSA-400042	reactome	NA	Adrenaline,noradrenaline inhibits insulin secretion
RAMP_P_000049677	R-HSA-177504	reactome	NA	Retrograde neurotrophin signalling
RAMP_P_000049678	R-HSA-2022377	reactome	NA	Metabolism of Angiotensinogen to Angiotensins
RAMP_P_000049679	R-HSA-5668541	reactome	NA	TNFR2 non-canonical NF-kB pathway
RAMP_P_000049680	R-HSA-179409	reactome	NA	APC-Cdc20 mediated degradation of Nek2A
RAMP_P_000049681	R-HSA-8866652	reactome	NA	Synthesis of active ubiquitin: roles of E1 and E2 enzymes
RAMP_P_000049682	R-HSA-169893	reactome	NA	Prolonged ERK activation events
RAMP_P_000049683	R-HSA-5223345	reactome	NA	Miscellaneous transport and binding events
RAMP_P_000049684	R-HSA-71032	reactome	NA	Propionyl-CoA catabolism
RAMP_P_000049685	R-HSA-190242	reactome	NA	FGFR1 ligand binding and activation
RAMP_P_000049686	R-HSA-913531	reactome	NA	Interferon Signaling
RAMP_P_000049687	R-HSA-69091	reactome	NA	Polymerase switching
RAMP_P_000049688	R-HSA-8866906	reactome	NA	TFAP2 (AP-2) family regulates transcription of other transcription factors
RAMP_P_000049689	R-HSA-8874081	reactome	NA	MET activates PTK2 signaling
RAMP_P_000049690	R-HSA-163282	reactome	NA	Mitochondrial transcription initiation
RAMP_P_000049691	R-HSA-9614399	reactome	NA	Regulation of localization of FOXO transcription factors
RAMP_P_000049692	R-HSA-881907	reactome	NA	Gastrin-CREB signalling pathway via PKC and MAPK
RAMP_P_000049693	R-HSA-174362	reactome	NA	Transport and synthesis of PAPS
RAMP_P_000049694	R-HSA-187042	reactome	NA	TRKA activation by NGF
RAMP_P_000049695	R-HSA-8964043	reactome	NA	Plasma lipoprotein clearance
RAMP_P_000049696	R-HSA-5663220	reactome	NA	RHO GTPases Activate Formins
RAMP_P_000049697	R-HSA-8866376	reactome	NA	Reelin signalling pathway
RAMP_P_000049698	R-HSA-927802	reactome	NA	Nonsense-Mediated Decay (NMD)
RAMP_P_000049699	R-HSA-5619114	reactome	NA	Defective SLC5A7 causes distal hereditary motor neuronopathy 7A (HMN7A)
RAMP_P_000049700	R-HSA-75876	reactome	NA	Synthesis of very long-chain fatty acyl-CoAs
RAMP_P_000049701	R-HSA-199418	reactome	NA	Negative regulation of the PI3K/AKT network
RAMP_P_000049702	R-HSA-8949215	reactome	NA	Mitochondrial calcium ion transport
RAMP_P_000049703	R-HSA-1299316	reactome	NA	TWIK-releated acid-sensitive K+ channel (TASK)
RAMP_P_000049704	R-HSA-9020591	reactome	NA	Interleukin-12 signaling
RAMP_P_000049705	R-HSA-4717374	reactome	NA	Defective DPM1 causes DPM1-CDG (CDG-1e)
RAMP_P_000049706	R-HSA-199220	reactome	NA	Vitamin B5 (pantothenate) metabolism
RAMP_P_000049707	R-HSA-5467337	reactome	NA	APC truncation mutants have impaired AXIN binding
RAMP_P_000049708	R-HSA-8866654	reactome	NA	E3 ubiquitin ligases ubiquitinate target proteins
RAMP_P_000049709	R-HSA-8849471	reactome	NA	PTK6 Regulates RHO GTPases, RAS GTPase and MAP kinases
RAMP_P_000049710	R-HSA-76046	reactome	NA	RNA Polymerase III Transcription Initiation
RAMP_P_000049711	R-HSA-211163	reactome	NA	AKT-mediated inactivation of FOXO1A
RAMP_P_000049712	R-HSA-2644605	reactome	NA	FBXW7 Mutants and NOTCH1 in Cancer
RAMP_P_000049713	R-HSA-8983432	reactome	NA	Interleukin-15 signaling
RAMP_P_000049714	R-HSA-8853336	reactome	NA	Signaling by plasma membrane FGFR1 fusions
RAMP_P_000049715	R-HSA-5658471	reactome	NA	Defective SLC5A7 causes distal hereditary motor neuronopathy 7A (HMN7A)
RAMP_P_000049716	R-HSA-6804757	reactome	NA	Regulation of TP53 Degradation
RAMP_P_000049717	R-HSA-8866911	reactome	NA	TFAP2 (AP-2) family regulates transcription of cell cycle factors
RAMP_P_000049718	R-HSA-192456	reactome	NA	Digestion of dietary lipid
RAMP_P_000049719	R-HSA-2206292	reactome	NA	MPS VII - Sly syndrome
RAMP_P_000049720	R-HSA-450302	reactome	NA	activated TAK1 mediates p38 MAPK activation
RAMP_P_000049721	R-HSA-5688354	reactome	NA	Defective pro-SFTPC causes pulmonary surfactant metabolism dysfunction 2 (SMDP2) and respiratory distress syndrome (RDS)
RAMP_P_000049722	R-HSA-6803157	reactome	NA	Antimicrobial peptides
RAMP_P_000049723	R-HSA-5617833	reactome	NA	Cilium Assembly
RAMP_P_000049724	R-HSA-880009	reactome	NA	Interconversion of 2-oxoglutarate and 2-hydroxyglutarate
RAMP_P_000049725	R-HSA-1462054	reactome	NA	Alpha-defensins
RAMP_P_000049726	R-HSA-9020933	reactome	NA	Interleukin-23 signaling
RAMP_P_000049727	R-HSA-376172	reactome	NA	DSCAM interactions
RAMP_P_000049728	R-HSA-3899300	reactome	NA	SUMOylation of transcription cofactors
RAMP_P_000049729	R-HSA-186797	reactome	NA	Signaling by PDGF
RAMP_P_000049730	R-HSA-2033514	reactome	NA	FGFR3 mutant receptor activation
RAMP_P_000049731	R-HSA-8941332	reactome	NA	RUNX2 regulates genes involved in cell migration
RAMP_P_000049732	R-HSA-442729	reactome	NA	CREB1 phosphorylation through the activation of CaMKII/CaMKK/CaMKIV cascasde
RAMP_P_000049733	R-HSA-2142670	reactome	NA	Synthesis of epoxy (EET) and dihydroxyeicosatrienoic acids (DHET)
RAMP_P_000049734	R-HSA-389359	reactome	NA	CD28 dependent Vav1 pathway
RAMP_P_000049735	R-HSA-381070	reactome	NA	IRE1alpha activates chaperones
RAMP_P_000049736	R-HSA-9018896	reactome	NA	Biosynthesis of E-series 18(S)-resolvins
RAMP_P_000049737	R-HSA-389957	reactome	NA	Prefoldin mediated transfer of substrate  to CCT/TriC
RAMP_P_000049738	R-HSA-5693537	reactome	NA	Resolution of D-Loop Structures
RAMP_P_000049739	R-HSA-1660508	reactome	NA	PIPs transport between late endosome and Golgi membranes
RAMP_P_000049740	R-HSA-5609976	reactome	NA	Defective GALK1 can cause Galactosemia II (GALCT2)
RAMP_P_000049741	R-HSA-5579019	reactome	NA	Defective FMO3 causes Trimethylaminuria (TMAU)
RAMP_P_000049742	R-HSA-6811436	reactome	NA	COPI-independent Golgi-to-ER retrograde traffic
RAMP_P_000049743	R-HSA-166016	reactome	NA	Toll Like Receptor 4 (TLR4) Cascade
RAMP_P_000049744	R-HSA-446107	reactome	NA	Type I hemidesmosome assembly
RAMP_P_000049745	R-HSA-512988	reactome	NA	Interleukin-3, Interleukin-5 and GM-CSF signaling
RAMP_P_000049746	R-HSA-5250958	reactome	NA	Toxicity of botulinum toxin type B (BoNT/B)
RAMP_P_000049747	R-HSA-5619507	reactome	NA	Activation of HOX genes during differentiation
RAMP_P_000049748	R-HSA-3108232	reactome	NA	SUMO E3 ligases SUMOylate target proteins
RAMP_P_000049749	R-HSA-5579000	reactome	NA	Defective CYP1B1 causes Glaucoma
RAMP_P_000049750	R-HSA-8950505	reactome	NA	Gene and protein expression by JAK-STAT signaling after Interleukin-12 stimulation
RAMP_P_000049751	R-HSA-5654227	reactome	NA	Phospholipase C-mediated cascade; FGFR3
RAMP_P_000049752	R-HSA-416550	reactome	NA	Sema4D mediated inhibition of cell attachment and migration
RAMP_P_000049753	R-HSA-4549356	reactome	NA	Defective DPAGT1 causes DPAGT1-CDG (CDG-1j) and CMSTA2
RAMP_P_000049754	R-HSA-167060	reactome	NA	NGF processing
RAMP_P_000049755	R-HSA-5358346	reactome	NA	Hedgehog ligand biogenesis
RAMP_P_000049756	R-HSA-375280	reactome	NA	Amine ligand-binding receptors
RAMP_P_000049757	R-HSA-209563	reactome	NA	Axonal growth stimulation
RAMP_P_000049758	R-HSA-193048	reactome	NA	Androgen biosynthesis
RAMP_P_000049759	R-HSA-9619483	reactome	NA	Activation of AMPK downstream of NMDARs
RAMP_P_000049760	R-HSA-5682910	reactome	NA	LGI-ADAM interactions
RAMP_P_000049761	R-HSA-75815	reactome	NA	Ubiquitin-dependent degradation of Cyclin D
RAMP_P_000049762	R-HSA-69580	reactome	NA	p53-Dependent G1/S DNA damage checkpoint
RAMP_P_000049763	R-HSA-74752	reactome	NA	Signaling by Insulin receptor
RAMP_P_000049764	R-HSA-110312	reactome	NA	Translesion synthesis by REV1
RAMP_P_000049765	R-HSA-190840	reactome	NA	Microtubule-dependent trafficking of connexons from Golgi to the plasma membrane
RAMP_P_000049766	R-HSA-69202	reactome	NA	Cyclin E associated events during G1/S transition 
RAMP_P_000049767	R-HSA-674695	reactome	NA	RNA Polymerase II Pre-transcription Events
RAMP_P_000049768	R-HSA-909733	reactome	NA	Interferon alpha/beta signaling
RAMP_P_000049769	R-HSA-1300642	reactome	NA	Sperm Motility And Taxes
RAMP_P_000049770	R-HSA-171319	reactome	NA	Telomere Extension By Telomerase
RAMP_P_000049771	R-HSA-141333	reactome	NA	Biogenic amines are oxidatively deaminated to aldehydes by MAOA and MAOB
RAMP_P_000049772	R-HSA-4720454	reactome	NA	Defective ALG9 causes ALG9-CDG (CDG-1l)
RAMP_P_000049773	R-HSA-1433559	reactome	NA	Regulation of KIT signaling
RAMP_P_000049774	R-HSA-6814848	reactome	NA	Glycerophospholipid catabolism
RAMP_P_000049775	R-HSA-2408508	reactome	NA	Metabolism of ingested SeMet, Sec, MeSec into H2Se
RAMP_P_000049776	R-HSA-2514859	reactome	NA	Inactivation, recovery and regulation of the phototransduction cascade
RAMP_P_000049777	R-HSA-5619061	reactome	NA	Defective SLC33A1 causes spastic paraplegia 42 (SPG42)
RAMP_P_000049778	R-HSA-5602410	reactome	NA	TLR3 deficiency - HSE
RAMP_P_000049779	R-HSA-8853333	reactome	NA	Signaling by FGFR2 fusions
RAMP_P_000049780	R-HSA-5218900	reactome	NA	CASP8 activity is inhibited
RAMP_P_000049781	R-HSA-1660516	reactome	NA	Synthesis of PIPs at the early endosome membrane
RAMP_P_000049782	R-HSA-419037	reactome	NA	NCAM1 interactions
RAMP_P_000049783	R-HSA-2299718	reactome	NA	Condensation of Prophase Chromosomes
RAMP_P_000049784	R-HSA-211999	reactome	NA	CYP2E1 reactions
RAMP_P_000049785	R-HSA-2162123	reactome	NA	Synthesis of Prostaglandins (PG) and Thromboxanes (TX)
RAMP_P_000049786	R-HSA-5619062	reactome	NA	Defective SLC1A3 causes episodic ataxia 6 (EA6)
RAMP_P_000049787	R-HSA-9012546	reactome	NA	Interleukin-18 signaling
RAMP_P_000049788	R-HSA-1483213	reactome	NA	Synthesis of PE
RAMP_P_000049789	R-HSA-5632968	reactome	NA	Defective Mismatch Repair Associated With MSH6
RAMP_P_000049790	R-HSA-8863795	reactome	NA	Downregulation of ERBB2 signaling
RAMP_P_000049791	R-HSA-1474151	reactome	NA	Tetrahydrobiopterin (BH4) synthesis, recycling, salvage and regulation
RAMP_P_000049792	R-HSA-9022535	reactome	NA	Loss of phosphorylation of MECP2 at T308
RAMP_P_000049793	R-HSA-209822	reactome	NA	Glycoprotein hormones
RAMP_P_000049794	R-HSA-389960	reactome	NA	Formation of tubulin folding intermediates by CCT/TriC
RAMP_P_000049795	R-HSA-5578997	reactome	NA	Defective AHCY causes Hypermethioninemia with S-adenosylhomocysteine hydrolase deficiency (HMAHCHD)
RAMP_P_000049796	R-HSA-8865999	reactome	NA	MET activates PTPN11
RAMP_P_000049797	R-HSA-2559585	reactome	NA	Oncogene Induced Senescence
RAMP_P_000049798	R-HSA-186763	reactome	NA	Downstream signal transduction
RAMP_P_000049799	R-HSA-203927	reactome	NA	MicroRNA (miRNA) biogenesis
RAMP_P_000049800	R-HSA-3656225	reactome	NA	Defective CHST6 causes MCDC1
RAMP_P_000049801	R-HSA-8875878	reactome	NA	MET promotes cell motility
RAMP_P_000049802	R-HSA-182218	reactome	NA	Nef Mediated CD8 Down-regulation
RAMP_P_000049803	R-HSA-5693554	reactome	NA	Resolution of D-loop Structures through Synthesis-Dependent Strand Annealing (SDSA)
RAMP_P_000049804	R-HSA-204998	reactome	NA	Cell death signalling via NRAGE, NRIF and NADE
RAMP_P_000049805	R-HSA-844615	reactome	NA	The AIM2 inflammasome
RAMP_P_000049806	R-HSA-187037	reactome	NA	Signaling by NTRK1 (TRKA)
RAMP_P_000049807	R-HSA-111995	reactome	NA	phospho-PLA2 pathway
RAMP_P_000049808	R-HSA-5362798	reactome	NA	Release of Hh-Np from the secreting cell
RAMP_P_000049809	R-HSA-4793950	reactome	NA	Defective MAN1B1 causes MRT15
RAMP_P_000049810	R-HSA-5657560	reactome	NA	Hereditary fructose intolerance
RAMP_P_000049811	R-HSA-3315487	reactome	NA	SMAD2/3 MH2 Domain Mutants in Cancer
RAMP_P_000049812	R-HSA-5579014	reactome	NA	Defective CYP27B1 causes Rickets vitamin D-dependent 1A (VDDR1A)
RAMP_P_000049813	R-HSA-1362277	reactome	NA	Transcription of E2F targets under negative control by DREAM complex
RAMP_P_000049814	R-HSA-5632928	reactome	NA	Defective Mismatch Repair Associated With MSH2
RAMP_P_000049815	R-HSA-2408557	reactome	NA	Selenocysteine synthesis
RAMP_P_000049816	R-HSA-164843	reactome	NA	2-LTR circle formation
RAMP_P_000049817	R-HSA-5603037	reactome	NA	IRAK4 deficiency (TLR5)
RAMP_P_000049818	R-HSA-2565942	reactome	NA	Regulation of PLK1 Activity at G2/M Transition
RAMP_P_000049819	R-HSA-9006925	reactome	NA	Intracellular signaling by second messengers
RAMP_P_000049820	R-HSA-73894	reactome	NA	DNA Repair
RAMP_P_000049821	R-HSA-76002	reactome	NA	Platelet activation, signaling and aggregation
RAMP_P_000049822	R-HSA-3828062	reactome	NA	Glycogen storage disease type 0 (muscle GYS1)
RAMP_P_000049823	R-HSA-190704	reactome	NA	Oligomerization of connexins into connexons
RAMP_P_000049824	R-HSA-112126	reactome	NA	ALKBH3 mediated reversal of alkylation damage
RAMP_P_000049825	R-HSA-171007	reactome	NA	p38MAPK events
RAMP_P_000049826	R-HSA-5579022	reactome	NA	Defective GGT1 causes Glutathionuria (GLUTH)
RAMP_P_000049827	R-HSA-211728	reactome	NA	Regulation of PAK-2p34 activity by PS-GAP/RHG10
RAMP_P_000049828	R-HSA-8963888	reactome	NA	Chylomicron assembly
RAMP_P_000049829	R-HSA-168188	reactome	NA	Toll Like Receptor TLR6:TLR2 Cascade
RAMP_P_000049830	R-HSA-111458	reactome	NA	Formation of apoptosome
RAMP_P_000049831	R-HSA-1799339	reactome	NA	SRP-dependent cotranslational protein targeting to membrane
RAMP_P_000049832	R-HSA-181429	reactome	NA	Serotonin Neurotransmitter Release Cycle
RAMP_P_000049833	R-HSA-964975	reactome	NA	Vitamins B6 activation to pyridoxal phosphate
RAMP_P_000049834	R-HSA-5696394	reactome	NA	DNA Damage Recognition in GG-NER
RAMP_P_000049835	R-HSA-162791	reactome	NA	Attachment of GPI anchor to uPAR
RAMP_P_000049836	R-HSA-180689	reactome	NA	APOBEC3G mediated resistance to HIV-1 infection
RAMP_P_000049837	R-HSA-5619084	reactome	NA	ABC transporter disorders
RAMP_P_000049838	R-HSA-181431	reactome	NA	Acetylcholine binding and downstream events
RAMP_P_000049839	R-HSA-9022702	reactome	NA	MECP2 regulates transcription of neuronal ligands
RAMP_P_000049840	R-HSA-141334	reactome	NA	PAOs oxidise polyamines to amines
RAMP_P_000049841	R-HSA-380108	reactome	NA	Chemokine receptors bind chemokines
RAMP_P_000049842	R-HSA-937061	reactome	NA	TRIF(TICAM1)-mediated TLR4 signaling 
RAMP_P_000049843	R-HSA-428543	reactome	NA	Inactivation of CDC42 and RAC1
RAMP_P_000049844	R-HSA-5619050	reactome	NA	Defective SLC4A1 causes hereditary spherocytosis type 4 (HSP4),  distal renal tubular acidosis (dRTA) and dRTA with hemolytic anemia (dRTA-HA)
RAMP_P_000049845	R-HSA-9022699	reactome	NA	MECP2 regulates neuronal receptors and channels
RAMP_P_000049846	R-HSA-5689603	reactome	NA	UCH proteinases
RAMP_P_000049847	R-HSA-3906995	reactome	NA	Diseases associated with O-glycosylation of proteins
RAMP_P_000049848	R-HSA-5619088	reactome	NA	Defective SLC39A4 causes acrodermatitis enteropathica, zinc-deficiency type (AEZ)
RAMP_P_000049849	R-HSA-428930	reactome	NA	Thromboxane signalling through TP receptor
RAMP_P_000049850	R-HSA-5358747	reactome	NA	S33 mutants of beta-catenin aren't phosphorylated
RAMP_P_000049851	R-HSA-433692	reactome	NA	Proton-coupled monocarboxylate transport
RAMP_P_000049852	R-HSA-450408	reactome	NA	AUF1 (hnRNP D0) binds and destabilizes mRNA
RAMP_P_000049853	R-HSA-8939242	reactome	NA	RUNX1 regulates transcription of genes involved in differentiation of keratinocytes
RAMP_P_000049854	R-HSA-977442	reactome	NA	GABA A (rho) receptor activation
RAMP_P_000049855	R-HSA-449836	reactome	NA	Other interleukin signaling
RAMP_P_000049856	R-HSA-193697	reactome	NA	p75NTR regulates axonogenesis
RAMP_P_000049857	R-HSA-162906	reactome	NA	HIV Infection
RAMP_P_000049858	R-HSA-174411	reactome	NA	Polymerase switching on the C-strand of the telomere
RAMP_P_000049859	R-HSA-110320	reactome	NA	Translesion Synthesis by POLH
RAMP_P_000049860	R-HSA-5579010	reactome	NA	Defective CYP24A1 causes Hypercalcemia, infantile (HCAI)
RAMP_P_000049861	R-HSA-8853659	reactome	NA	RET signaling
RAMP_P_000049862	R-HSA-70326	reactome	NA	Glucose metabolism
RAMP_P_000049863	R-HSA-2142712	reactome	NA	Synthesis of 12-eicosatetraenoic acid derivatives
RAMP_P_000049864	R-HSA-163210	reactome	NA	Formation of ATP by chemiosmotic coupling
RAMP_P_000049865	R-HSA-3134963	reactome	NA	DEx/H-box helicases activate type I IFN and inflammatory cytokines production 
RAMP_P_000049866	R-HSA-168179	reactome	NA	Toll Like Receptor TLR1:TLR2 Cascade
RAMP_P_000049867	R-HSA-162592	reactome	NA	Integration of provirus
RAMP_P_000049868	R-HSA-5663213	reactome	NA	RHO GTPases Activate WASPs and WAVEs
RAMP_P_000049869	R-HSA-5658208	reactome	NA	Defective SLC5A2 causes renal glucosuria (GLYS1)
RAMP_P_000049870	R-HSA-5655291	reactome	NA	Signaling by FGFR4 in disease
RAMP_P_000049871	R-HSA-8951911	reactome	NA	RUNX3 regulates RUNX1-mediated transcription
RAMP_P_000049872	R-HSA-141444	reactome	NA	Amplification  of signal from unattached  kinetochores via a MAD2  inhibitory signal
RAMP_P_000049873	R-HSA-8963743	reactome	NA	Digestion and absorption
RAMP_P_000049874	R-HSA-75153	reactome	NA	Apoptotic execution phase
RAMP_P_000049875	R-HSA-1474244	reactome	NA	Extracellular matrix organization
RAMP_P_000049876	R-HSA-211897	reactome	NA	Cytochrome P450 - arranged by substrate type
RAMP_P_000049877	R-HSA-76009	reactome	NA	Platelet Aggregation (Plug Formation)
RAMP_P_000049878	R-HSA-69206	reactome	NA	G1/S Transition
RAMP_P_000049879	R-HSA-8847993	reactome	NA	ERBB2 Activates PTK6 Signaling
RAMP_P_000049880	R-HSA-354194	reactome	NA	GRB2:SOS provides linkage to MAPK signaling for Integrins 
RAMP_P_000049881	R-HSA-110331	reactome	NA	Cleavage of the damaged purine
RAMP_P_000049882	R-HSA-9018676	reactome	NA	Biosynthesis of D-series resolvins
RAMP_P_000049883	R-HSA-3065676	reactome	NA	SUMO is conjugated to E1 (UBA2:SAE1)
RAMP_P_000049884	R-HSA-5659898	reactome	NA	Intestinal saccharidase deficiencies
RAMP_P_000049885	R-HSA-177539	reactome	NA	Autointegration results in viral DNA circles
RAMP_P_000049886	R-HSA-2206307	reactome	NA	MPS IIIA - Sanfilippo syndrome A
RAMP_P_000049887	R-HSA-975138	reactome	NA	TRAF6 mediated induction of NFkB and MAP kinases upon TLR7/8 or 9 activation
RAMP_P_000049888	R-HSA-164939	reactome	NA	Nef mediated downregulation of CD28 cell surface expression
RAMP_P_000049889	R-HSA-9033500	reactome	NA	TYSND1 cleaves peroxisomal proteins
RAMP_P_000049890	R-HSA-1592230	reactome	NA	Mitochondrial biogenesis
RAMP_P_000049891	R-HSA-444411	reactome	NA	Rhesus glycoproteins mediate ammonium transport.
RAMP_P_000049892	R-HSA-391160	reactome	NA	Signal regulatory protein family interactions
RAMP_P_000049893	R-HSA-156827	reactome	NA	L13a-mediated translational silencing of Ceruloplasmin expression
RAMP_P_000049894	R-HSA-2428924	reactome	NA	IGF1R signaling cascade
RAMP_P_000049895	R-HSA-8964046	reactome	NA	VLDL clearance
RAMP_P_000049896	R-HSA-179419	reactome	NA	APC:Cdc20 mediated degradation of cell cycle proteins prior to satisfation of the cell cycle checkpoint
RAMP_P_000049897	R-HSA-210993	reactome	NA	Tie2 Signaling
RAMP_P_000049898	R-HSA-1168372	reactome	NA	Downstream signaling events of B Cell Receptor (BCR)
RAMP_P_000049899	R-HSA-216083	reactome	NA	Integrin cell surface interactions
RAMP_P_000049900	R-HSA-9619229	reactome	NA	Activation of RAC1 downstream of NMDARs
RAMP_P_000049901	R-HSA-5467340	reactome	NA	AXIN missense mutants destabilize the destruction complex
RAMP_P_000049902	R-HSA-3000171	reactome	NA	Non-integrin membrane-ECM interactions
RAMP_P_000049903	R-HSA-164378	reactome	NA	PKA activation in glucagon signalling
RAMP_P_000049904	R-HSA-8854214	reactome	NA	TBC/RABGAPs
RAMP_P_000049905	R-HSA-5661231	reactome	NA	Metallothioneins bind metals
RAMP_P_000049906	R-HSA-8939902	reactome	NA	Regulation of RUNX2 expression and activity
RAMP_P_000049907	R-HSA-5693538	reactome	NA	Homology Directed Repair
RAMP_P_000049908	R-HSA-2022928	reactome	NA	HS-GAG biosynthesis
RAMP_P_000049909	R-HSA-2025928	reactome	NA	Calcineurin activates NFAT
RAMP_P_000049910	R-HSA-1483248	reactome	NA	Synthesis of PIPs at the ER membrane
RAMP_P_000049911	R-HSA-211945	reactome	NA	Phase I - Functionalization of compounds
RAMP_P_000049912	R-HSA-5263617	reactome	NA	Metabolism of ingested MeSeO2H into MeSeH
RAMP_P_000049913	R-HSA-389661	reactome	NA	Glyoxylate metabolism and glycine degradation
RAMP_P_000049914	R-HSA-9617324	reactome	NA	Negative regulation of NMDA receptor-mediated neuronal transmission
RAMP_P_000049915	R-HSA-5579015	reactome	NA	Defective CYP26B1 causes Radiohumeral fusions with other skeletal and craniofacial anomalies (RHFCA)
RAMP_P_000049916	R-HSA-3214858	reactome	NA	RMTs methylate histone arginines
RAMP_P_000049917	R-HSA-5674499	reactome	NA	Negative feedback regulation of MAPK pathway
RAMP_P_000049918	R-HSA-5679001	reactome	NA	Defective ABCC2 causes Dubin-Johnson syndrome
RAMP_P_000049919	R-HSA-170968	reactome	NA	Frs2-mediated activation
RAMP_P_000049920	R-HSA-69416	reactome	NA	Dimerization of procaspase-8
RAMP_P_000049921	R-HSA-442720	reactome	NA	CREB1 phosphorylation through the activation of Adenylate Cyclase
RAMP_P_000049922	R-HSA-2022090	reactome	NA	Assembly of collagen fibrils and other multimeric structures
RAMP_P_000049923	R-HSA-72737	reactome	NA	Cap-dependent Translation Initiation
RAMP_P_000049924	R-HSA-168643	reactome	NA	Nucleotide-binding domain, leucine rich repeat containing receptor (NLR) signaling pathways
RAMP_P_000049925	R-HSA-425381	reactome	NA	Bicarbonate transporters
RAMP_P_000049926	R-HSA-73776	reactome	NA	RNA Polymerase II Promoter Escape
RAMP_P_000049927	R-HSA-168336	reactome	NA	Uncoating of the Influenza Virion
RAMP_P_000049928	R-HSA-3304356	reactome	NA	SMAD2/3 Phosphorylation Motif Mutants in Cancer
RAMP_P_000049929	R-HSA-8852135	reactome	NA	Protein ubiquitination
RAMP_P_000049930	R-HSA-1500620	reactome	NA	Meiosis
RAMP_P_000049931	R-HSA-193634	reactome	NA	Axonal growth inhibition (RHOA activation)
RAMP_P_000049932	R-HSA-392499	reactome	NA	Metabolism of proteins
RAMP_P_000049933	R-HSA-5358752	reactome	NA	T41 mutants of beta-catenin aren't phosphorylated
RAMP_P_000049934	R-HSA-5690338	reactome	NA	Defective ABCC6 causes pseudoxanthoma elasticum (PXE)
RAMP_P_000049935	R-HSA-111957	reactome	NA	Cam-PDE 1 activation
RAMP_P_000049936	R-HSA-110381	reactome	NA	Resolution of AP sites via the single-nucleotide replacement pathway
RAMP_P_000049937	R-HSA-5688849	reactome	NA	Defective CSF2RB causes pulmonary surfactant metabolism dysfunction 5 (SMDP5)
RAMP_P_000049938	R-HSA-5250955	reactome	NA	Toxicity of botulinum toxin type D (BoNT/D)
RAMP_P_000049939	R-HSA-426117	reactome	NA	Cation-coupled Chloride cotransporters
RAMP_P_000049940	R-HSA-168271	reactome	NA	Transport of Ribonucleoproteins into the Host Nucleus
RAMP_P_000049941	R-HSA-561048	reactome	NA	Organic anion transport
RAMP_P_000049942	R-HSA-4839735	reactome	NA	AXIN mutants destabilize the destruction complex, activating WNT signaling
RAMP_P_000049943	R-HSA-5659996	reactome	NA	RPIA deficiency: failed conversion of R5P to RU5P
RAMP_P_000049944	R-HSA-9018679	reactome	NA	Biosynthesis of EPA-derived SPMs
RAMP_P_000049945	R-HSA-400511	reactome	NA	Synthesis, secretion, and inactivation of Glucose-dependent Insulinotropic Polypeptide (GIP)
RAMP_P_000049946	R-HSA-532668	reactome	NA	N-glycan trimming in the ER and Calnexin/Calreticulin cycle
RAMP_P_000049947	R-HSA-2564830	reactome	NA	Cytosolic iron-sulfur cluster assembly
RAMP_P_000049948	R-HSA-196854	reactome	NA	Metabolism of vitamins and cofactors
RAMP_P_000049949	R-HSA-422356	reactome	NA	Regulation of insulin secretion
RAMP_P_000049950	R-HSA-446210	reactome	NA	Synthesis of UDP-N-acetyl-glucosamine
RAMP_P_000049951	R-HSA-3000497	reactome	NA	Scavenging by Class H Receptors
RAMP_P_000049952	R-HSA-390651	reactome	NA	Dopamine receptors
RAMP_P_000049953	R-HSA-5576886	reactome	NA	Phase 4 - resting membrane potential
RAMP_P_000049954	R-HSA-8853383	reactome	NA	Lysosomal oligosaccharide catabolism
RAMP_P_000049955	R-HSA-3656244	reactome	NA	Defective B4GALT1 causes B4GALT1-CDG (CDG-2d)
RAMP_P_000049956	R-HSA-168164	reactome	NA	Toll Like Receptor 3 (TLR3) Cascade
RAMP_P_000049957	R-HSA-168305	reactome	NA	Inhibition of Interferon Synthesis
RAMP_P_000049958	R-HSA-109582	reactome	NA	Hemostasis
RAMP_P_000049959	R-HSA-3359454	reactome	NA	Defective TCN2 causes hereditary megaloblastic anemia
RAMP_P_000049960	R-HSA-5619099	reactome	NA	Defective AVP does not bind AVPR1A,B and causes neurohypophyseal diabetes insipidus (NDI)
RAMP_P_000049961	R-HSA-5579020	reactome	NA	Defective SLC35D1 causes Schneckenbecken dysplasia (SCHBCKD)
RAMP_P_000049962	R-HSA-69275	reactome	NA	G2/M Transition
RAMP_P_000049963	R-HSA-8936459	reactome	NA	RUNX1 regulates genes involved in megakaryocyte differentiation and platelet function
RAMP_P_000049964	R-HSA-164516	reactome	NA	Minus-strand DNA synthesis
RAMP_P_000049965	R-HSA-189483	reactome	NA	Heme degradation
RAMP_P_000049966	R-HSA-5654696	reactome	NA	Downstream signaling of activated FGFR2
RAMP_P_000049967	R-HSA-6783984	reactome	NA	Glycine degradation
RAMP_P_000049968	R-HSA-500753	reactome	NA	Pyrimidine biosynthesis
RAMP_P_000049969	R-HSA-948021	reactome	NA	Transport to the Golgi and subsequent modification
RAMP_P_000049970	R-HSA-382556	reactome	NA	ABC-family proteins mediated transport
RAMP_P_000049971	R-HSA-2990846	reactome	NA	SUMOylation
RAMP_P_000049972	R-HSA-1433557	reactome	NA	Signaling by SCF-KIT
RAMP_P_000049973	R-HSA-6798695	reactome	NA	Neutrophil degranulation
RAMP_P_000049974	R-HSA-975871	reactome	NA	MyD88 cascade initiated on plasma membrane
RAMP_P_000049975	R-HSA-6804760	reactome	NA	Regulation of TP53 Activity through Methylation
RAMP_P_000049976	R-HSA-400508	reactome	NA	Incretin synthesis, secretion, and inactivation
RAMP_P_000049977	R-HSA-72202	reactome	NA	Transport of Mature Transcript to Cytoplasm
RAMP_P_000049978	R-HSA-1963642	reactome	NA	PI3K events in ERBB2 signaling
RAMP_P_000049979	R-HSA-5467348	reactome	NA	Truncations of AMER1 destabilize the destruction complex
RAMP_P_000049980	R-HSA-72764	reactome	NA	Eukaryotic Translation Termination
RAMP_P_000049981	R-HSA-68884	reactome	NA	Mitotic Telophase/Cytokinesis
RAMP_P_000049982	R-HSA-2206280	reactome	NA	MPS IX - Natowicz syndrome
RAMP_P_000049983	R-HSA-5685942	reactome	NA	HDR through Homologous Recombination (HRR)
RAMP_P_000049984	R-HSA-162589	reactome	NA	Reverse Transcription of HIV RNA
RAMP_P_000049985	R-HSA-1227986	reactome	NA	Signaling by ERBB2
RAMP_P_000049986	R-HSA-1483196	reactome	NA	PI and PC transport between ER and Golgi membranes
RAMP_P_000049987	R-HSA-450513	reactome	NA	Tristetraprolin (TTP, ZFP36) binds and destabilizes mRNA
RAMP_P_000049988	R-HSA-167161	reactome	NA	HIV Transcription Initiation
RAMP_P_000049989	R-HSA-5624138	reactome	NA	Trafficking of myristoylated proteins to the cilium
RAMP_P_000049990	R-HSA-390466	reactome	NA	Chaperonin-mediated protein folding
RAMP_P_000049991	R-HSA-159227	reactome	NA	Transport of the SLBP independent Mature mRNA
RAMP_P_000049992	R-HSA-5653890	reactome	NA	Lactose synthesis
RAMP_P_000049993	R-HSA-190873	reactome	NA	Gap junction degradation
RAMP_P_000049994	R-HSA-9006934	reactome	NA	Signaling by Receptor Tyrosine Kinases
RAMP_P_000049995	R-HSA-1638091	reactome	NA	Heparan sulfate/heparin (HS-GAG) metabolism
RAMP_P_000049996	R-HSA-381119	reactome	NA	Unfolded Protein Response (UPR)
RAMP_P_000049997	R-HSA-5619039	reactome	NA	Defective SLC12A6 causes agenesis of the corpus callosum, with peripheral neuropathy (ACCPN)
RAMP_P_000049998	R-HSA-73980	reactome	NA	RNA Polymerase III Transcription Termination
RAMP_P_000049999	R-HSA-77588	reactome	NA	SLBP Dependent Processing of Replication-Dependent Histone Pre-mRNAs
RAMP_P_000050000	R-HSA-380615	reactome	NA	Serotonin clearance from the synaptic cleft
RAMP_P_000050001	R-HSA-68877	reactome	NA	Mitotic Prometaphase
RAMP_P_000050002	R-HSA-446203	reactome	NA	Asparagine N-linked glycosylation
RAMP_P_000050003	R-HSA-202430	reactome	NA	Translocation of ZAP-70 to Immunological synapse
RAMP_P_000050004	R-HSA-2142691	reactome	NA	Synthesis of Leukotrienes (LT) and Eoxins (EX)
RAMP_P_000050005	R-HSA-6785470	reactome	NA	tRNA processing in the mitochondrion
RAMP_P_000050006	R-HSA-167590	reactome	NA	Nef Mediated CD4 Down-regulation
RAMP_P_000050007	R-HSA-1257604	reactome	NA	PIP3 activates AKT signaling
RAMP_P_000050008	R-HSA-5607764	reactome	NA	CLEC7A (Dectin-1) signaling
RAMP_P_000050009	R-HSA-72086	reactome	NA	mRNA Capping
RAMP_P_000050010	R-HSA-167160	reactome	NA	RNA Pol II CTD phosphorylation and interaction with CE during HIV infection
RAMP_P_000050011	R-HSA-3928662	reactome	NA	EPHB-mediated forward signaling
RAMP_P_000050012	R-HSA-1660514	reactome	NA	Synthesis of PIPs at the Golgi membrane
RAMP_P_000050013	R-HSA-5660526	reactome	NA	Response to metal ions
RAMP_P_000050014	R-HSA-5675482	reactome	NA	Regulation of necroptotic cell death
RAMP_P_000050015	R-HSA-438066	reactome	NA	Unblocking of NMDA receptors, glutamate binding and activation
RAMP_P_000050016	R-HSA-3371568	reactome	NA	Attenuation phase
RAMP_P_000050017	R-HSA-937072	reactome	NA	TRAF6-mediated induction of TAK1 complex within TLR4 complex
RAMP_P_000050018	R-HSA-8963678	reactome	NA	Intestinal lipid absorption
RAMP_P_000050019	R-HSA-163358	reactome	NA	PKA-mediated phosphorylation of key metabolic factors
RAMP_P_000050020	R-HSA-450604	reactome	NA	KSRP (KHSRP) binds and destabilizes mRNA
RAMP_P_000050021	R-HSA-5661270	reactome	NA	Formation of xylulose-5-phosphate
RAMP_P_000050022	R-HSA-5669034	reactome	NA	TNFs bind their physiological receptors
RAMP_P_000050023	R-HSA-5696397	reactome	NA	Gap-filling DNA repair synthesis and ligation in GG-NER
RAMP_P_000050024	R-HSA-450321	reactome	NA	JNK (c-Jun kinases) phosphorylation and  activation mediated by activated human TAK1
RAMP_P_000050025	R-HSA-69601	reactome	NA	Ubiquitin Mediated Degradation of Phosphorylated Cdc25A
RAMP_P_000050026	R-HSA-9014826	reactome	NA	Interleukin-36 pathway
RAMP_P_000050027	R-HSA-8875360	reactome	NA	InlB-mediated entry of Listeria monocytogenes into host cell
RAMP_P_000050028	R-HSA-5602680	reactome	NA	MyD88 deficiency (TLR5)
RAMP_P_000050029	R-HSA-195721	reactome	NA	Signaling by WNT
RAMP_P_000050030	R-HSA-1482839	reactome	NA	Acyl chain remodelling of PE
RAMP_P_000050031	R-HSA-1480926	reactome	NA	O2/CO2 exchange in erythrocytes
RAMP_P_000050032	R-HSA-5679090	reactome	NA	Defective ABCG8 causes gallbladder disease 4 and sitosterolemia
RAMP_P_000050033	R-HSA-73621	reactome	NA	Pyrimidine catabolism
RAMP_P_000050034	R-HSA-8941855	reactome	NA	RUNX3 regulates CDKN1A transcription
RAMP_P_000050035	R-HSA-5260271	reactome	NA	Diseases of Immune System
RAMP_P_000050036	R-HSA-2046105	reactome	NA	Linoleic acid (LA) metabolism
RAMP_P_000050037	R-HSA-1461957	reactome	NA	Beta defensins
RAMP_P_000050038	R-HSA-380095	reactome	NA	Tachykinin receptors bind tachykinins
RAMP_P_000050039	R-HSA-438064	reactome	NA	Post NMDA receptor activation events
RAMP_P_000050040	R-HSA-2660825	reactome	NA	Signaling by NOTCH1 t(7;9)(NOTCH1:M1580_K2555) Translocation Mutant
RAMP_P_000050041	R-HSA-5250913	reactome	NA	Positive epigenetic regulation of rRNA expression
RAMP_P_000050042	R-HSA-381676	reactome	NA	Glucagon-like Peptide-1 (GLP1) regulates insulin secretion
RAMP_P_000050043	R-HSA-1614517	reactome	NA	Sulfide oxidation to sulfate
RAMP_P_000050044	R-HSA-1226099	reactome	NA	Signaling by FGFR in disease
RAMP_P_000050045	R-HSA-69205	reactome	NA	G1/S-Specific Transcription
RAMP_P_000050046	R-HSA-77346	reactome	NA	Beta oxidation of decanoyl-CoA to octanoyl-CoA-CoA
RAMP_P_000050047	R-HSA-110362	reactome	NA	POLB-Dependent Long Patch Base Excision Repair
RAMP_P_000050048	R-HSA-168325	reactome	NA	Viral Messenger RNA Synthesis
RAMP_P_000050049	R-HSA-211736	reactome	NA	Stimulation of the cell death response by PAK-2p34
RAMP_P_000050050	R-HSA-419771	reactome	NA	Opsins
RAMP_P_000050051	R-HSA-193704	reactome	NA	p75 NTR receptor-mediated signalling
RAMP_P_000050052	R-HSA-5083630	reactome	NA	Defective LFNG causes SCDO3
RAMP_P_000050053	R-HSA-5652084	reactome	NA	Fructose metabolism
RAMP_P_000050054	R-HSA-420499	reactome	NA	Class C/3 (Metabotropic glutamate/pheromone receptors)
RAMP_P_000050055	R-HSA-73929	reactome	NA	Base-Excision Repair, AP Site Formation
RAMP_P_000050056	R-HSA-1483257	reactome	NA	Phospholipid metabolism
RAMP_P_000050057	R-HSA-194068	reactome	NA	Bile acid and bile salt metabolism
RAMP_P_000050058	R-HSA-888590	reactome	NA	GABA synthesis, release, reuptake and degradation
RAMP_P_000050059	R-HSA-389513	reactome	NA	CTLA4 inhibitory signaling
RAMP_P_000050060	R-HSA-111367	reactome	NA	SLBP independent Processing of Histone Pre-mRNAs
RAMP_P_000050061	R-HSA-6799990	reactome	NA	Metal sequestration by antimicrobial proteins
RAMP_P_000050062	R-HSA-167021	reactome	NA	PLC-gamma1 signalling
RAMP_P_000050063	R-HSA-8949664	reactome	NA	Processing of SMDT1
RAMP_P_000050064	R-HSA-5579002	reactome	NA	Defective UGT1A1 causes hyperbilirubinemia
RAMP_P_000050065	R-HSA-5083636	reactome	NA	Defective GALNT12 causes colorectal cancer 1 (CRCS1)
RAMP_P_000050066	R-HSA-5619048	reactome	NA	Defective SLC11A2 causes hypochromic microcytic anemia, with iron overload 1 (AHMIO1)
RAMP_P_000050067	R-HSA-8964572	reactome	NA	Lipid particle organization
RAMP_P_000050068	R-HSA-5654695	reactome	NA	PI-3K cascade:FGFR2
RAMP_P_000050069	R-HSA-450531	reactome	NA	Regulation of mRNA stability by proteins that bind AU-rich elements
RAMP_P_000050070	R-HSA-5655332	reactome	NA	Signaling by FGFR3 in disease
RAMP_P_000050071	R-HSA-70921	reactome	NA	Histidine catabolism
RAMP_P_000050072	R-HSA-3359485	reactome	NA	Defective CD320 causes methylmalonic aciduria
RAMP_P_000050073	R-HSA-913709	reactome	NA	O-linked glycosylation of mucins
RAMP_P_000050074	R-HSA-425393	reactome	NA	Transport of inorganic cations/anions and amino acids/oligopeptides
RAMP_P_000050075	R-HSA-5654736	reactome	NA	Signaling by FGFR1
RAMP_P_000050076	R-HSA-5423646	reactome	NA	Aflatoxin activation and detoxification
RAMP_P_000050077	R-HSA-8854518	reactome	NA	AURKA Activation by TPX2
RAMP_P_000050078	R-HSA-9028731	reactome	NA	Activated NTRK2 signals through FRS2 and FRS3
RAMP_P_000050079	R-HSA-5684996	reactome	NA	MAPK1/MAPK3 signaling
RAMP_P_000050080	R-HSA-5365859	reactome	NA	RA biosynthesis pathway
RAMP_P_000050081	R-HSA-166665	reactome	NA	Terminal pathway of complement
RAMP_P_000050082	R-HSA-177162	reactome	NA	Conjugation of phenylacetate with glutamine
RAMP_P_000050083	R-HSA-8940973	reactome	NA	RUNX2 regulates osteoblast differentiation
RAMP_P_000050084	R-HSA-5654687	reactome	NA	Downstream signaling of activated FGFR1
RAMP_P_000050085	R-HSA-2559584	reactome	NA	Formation of Senescence-Associated Heterochromatin Foci (SAHF)
RAMP_P_000050086	R-HSA-198725	reactome	NA	Nuclear Events (kinase and transcription factor activation)
RAMP_P_000050087	R-HSA-73930	reactome	NA	Abasic sugar-phosphate removal via the single-nucleotide replacement pathway
RAMP_P_000050088	R-HSA-164938	reactome	NA	Nef-mediates down modulation of cell surface receptors by recruiting them to clathrin adapters
RAMP_P_000050089	R-HSA-5633007	reactome	NA	Regulation of TP53 Activity
RAMP_P_000050090	R-HSA-6804758	reactome	NA	Regulation of TP53 Activity through Acetylation
RAMP_P_000050091	R-HSA-428643	reactome	NA	Organic anion transporters
RAMP_P_000050092	R-HSA-432142	reactome	NA	Platelet sensitization by LDL
RAMP_P_000050093	R-HSA-68689	reactome	NA	CDC6 association with the ORC:origin complex
RAMP_P_000050094	R-HSA-190241	reactome	NA	FGFR2 ligand binding and activation
RAMP_P_000050095	R-HSA-5619111	reactome	NA	Defective SLC20A2 causes idiopathic basal ganglia calcification 1 (IBGC1)
RAMP_P_000050096	R-HSA-2161522	reactome	NA	Abacavir transport and metabolism
RAMP_P_000050097	R-HSA-1834949	reactome	NA	Cytosolic sensors of pathogen-associated DNA 
RAMP_P_000050098	R-HSA-190371	reactome	NA	FGFR3b ligand binding and activation
RAMP_P_000050099	R-HSA-5250941	reactome	NA	Negative epigenetic regulation of rRNA expression
RAMP_P_000050100	R-HSA-983231	reactome	NA	Factors involved in megakaryocyte development and platelet production
RAMP_P_000050101	R-HSA-6785807	reactome	NA	Interleukin-4 and Interleukin-13 signaling
RAMP_P_000050102	R-HSA-446205	reactome	NA	Synthesis of GDP-mannose
RAMP_P_000050103	R-HSA-5682294	reactome	NA	Defective ABCA12 causes autosomal recessive congenital ichthyosis type 4B
RAMP_P_000050104	R-HSA-9609507	reactome	NA	Protein localization
RAMP_P_000050105	R-HSA-9017802	reactome	NA	Noncanonical activation of NOTCH3
RAMP_P_000050106	R-HSA-8963898	reactome	NA	Plasma lipoprotein assembly
RAMP_P_000050107	R-HSA-2644602	reactome	NA	Signaling by NOTCH1 PEST Domain Mutants in Cancer
RAMP_P_000050108	R-HSA-397795	reactome	NA	G-protein beta:gamma signalling
RAMP_P_000050109	R-HSA-4641258	reactome	NA	Degradation of DVL
RAMP_P_000050110	R-HSA-4724325	reactome	NA	Defective ALG8 causes ALG8-CDG (CDG-1h)
RAMP_P_000050111	R-HSA-3000480	reactome	NA	Scavenging by Class A Receptors
RAMP_P_000050112	R-HSA-5693616	reactome	NA	Presynaptic phase of homologous DNA pairing and strand exchange
RAMP_P_000050113	R-HSA-388844	reactome	NA	Receptor-type tyrosine-protein phosphatases
RAMP_P_000050114	R-HSA-2426168	reactome	NA	Activation of gene expression by SREBF (SREBP)
RAMP_P_000050115	R-HSA-1483115	reactome	NA	Hydrolysis of LPC
RAMP_P_000050116	R-HSA-9018683	reactome	NA	Biosynthesis of DPA-derived SPMs
RAMP_P_000050117	R-HSA-174184	reactome	NA	Cdc20:Phospho-APC/C mediated degradation of Cyclin A
RAMP_P_000050118	R-HSA-2408522	reactome	NA	Selenoamino acid metabolism
RAMP_P_000050119	R-HSA-194315	reactome	NA	Signaling by Rho GTPases
RAMP_P_000050120	R-HSA-8848584	reactome	NA	Wax biosynthesis
RAMP_P_000050121	R-HSA-9020956	reactome	NA	Interleukin-27 signaling
RAMP_P_000050122	R-HSA-69610	reactome	NA	p53-Independent DNA Damage Response
RAMP_P_000050123	R-HSA-381340	reactome	NA	Transcriptional regulation of white adipocyte differentiation
RAMP_P_000050124	R-HSA-5690714	reactome	NA	CD22 mediated BCR regulation
RAMP_P_000050125	R-HSA-445717	reactome	NA	Aquaporin-mediated transport
RAMP_P_000050126	R-HSA-190375	reactome	NA	FGFR2c ligand binding and activation
RAMP_P_000050127	R-HSA-69229	reactome	NA	Ubiquitin-dependent degradation of Cyclin D1
RAMP_P_000050128	R-HSA-1300652	reactome	NA	Sperm:Oocyte Membrane Binding
RAMP_P_000050129	R-HSA-5658034	reactome	NA	HHAT G278V abrogates palmitoylation of Hh-Np
RAMP_P_000050130	R-HSA-3304351	reactome	NA	Signaling by TGF-beta Receptor Complex in Cancer
RAMP_P_000050131	R-HSA-77310	reactome	NA	Beta oxidation of lauroyl-CoA to decanoyl-CoA-CoA
RAMP_P_000050132	R-HSA-1169092	reactome	NA	Activation of RAS in B cells
RAMP_P_000050133	R-HSA-1483171	reactome	NA	Synthesis of BMP
RAMP_P_000050134	R-HSA-6788656	reactome	NA	Histidine, lysine, phenylalanine, tyrosine, proline and tryptophan catabolism
RAMP_P_000050135	R-HSA-8943724	reactome	NA	Regulation of PTEN gene transcription
RAMP_P_000050136	R-HSA-379724	reactome	NA	tRNA Aminoacylation
RAMP_P_000050137	R-HSA-3214815	reactome	NA	HDACs deacetylate histones
RAMP_P_000050138	R-HSA-5368286	reactome	NA	Mitochondrial translation initiation
RAMP_P_000050139	R-HSA-5619078	reactome	NA	Defective SLC35C1 causes congenital disorder of glycosylation 2C (CDG2C)
RAMP_P_000050140	R-HSA-167152	reactome	NA	Formation of HIV elongation complex in the absence of HIV Tat
RAMP_P_000050141	R-HSA-5619077	reactome	NA	Defective SLC24A1 causes congenital stationary night blindness 1D (CSNB1D)
RAMP_P_000050142	R-HSA-5656169	reactome	NA	Termination of translesion DNA synthesis
RAMP_P_000050143	R-HSA-1251985	reactome	NA	Nuclear signaling by ERBB4
RAMP_P_000050144	R-HSA-5654688	reactome	NA	SHC-mediated cascade:FGFR1
RAMP_P_000050145	R-HSA-444257	reactome	NA	RSK activation
RAMP_P_000050146	R-HSA-5637810	reactome	NA	Constitutive Signaling by EGFRvIII
RAMP_P_000050147	R-HSA-5619081	reactome	NA	Defective SLC6A3 causes Parkinsonism-dystonia infantile (PKDYS)
RAMP_P_000050148	R-HSA-629597	reactome	NA	Highly calcium permeable nicotinic acetylcholine receptors
RAMP_P_000050149	R-HSA-5633231	reactome	NA	Defective ALG14 causes congenital myasthenic syndrome (ALG14-CMS)
RAMP_P_000050150	R-HSA-141424	reactome	NA	Amplification of signal from the kinetochores
RAMP_P_000050151	R-HSA-4043916	reactome	NA	Defective MPI causes MPI-CDG (CDG-1b)
RAMP_P_000050152	R-HSA-114604	reactome	NA	GPVI-mediated activation cascade
RAMP_P_000050153	R-HSA-5619101	reactome	NA	Variant SLC6A20 contributes towards hyperglycinuria (HG) and iminoglycinuria (IG)
RAMP_P_000050154	R-HSA-2151201	reactome	NA	Transcriptional activation of mitochondrial biogenesis
RAMP_P_000050155	R-HSA-8939243	reactome	NA	RUNX1 interacts with co-factors whose precise effect on RUNX1 targets is not known
RAMP_P_000050156	R-HSA-975634	reactome	NA	Retinoid metabolism and transport
RAMP_P_000050157	R-HSA-5619110	reactome	NA	Defective SLCO1B1 causes hyperbilirubinemia, Rotor type (HBLRR)
RAMP_P_000050158	R-HSA-5578998	reactome	NA	Defective OPLAH causes 5-oxoprolinase deficiency (OPLAHD)
RAMP_P_000050159	R-HSA-9013694	reactome	NA	Signaling by NOTCH4
RAMP_P_000050160	R-HSA-5619108	reactome	NA	Defective SLC27A4 causes ichthyosis prematurity syndrome (IPS)
RAMP_P_000050161	R-HSA-209952	reactome	NA	Peptide hormone biosynthesis
RAMP_P_000050162	R-HSA-5619042	reactome	NA	Defective RHAG causes regulator type Rh-null hemolytic anemia (RHN)
RAMP_P_000050163	R-HSA-202427	reactome	NA	Phosphorylation of CD3 and TCR zeta chains
RAMP_P_000050164	R-HSA-1369007	reactome	NA	Mitochondrial ABC transporters
RAMP_P_000050165	R-HSA-975956	reactome	NA	Nonsense Mediated Decay (NMD) independent of the Exon Junction Complex (EJC)
RAMP_P_000050166	R-HSA-5683057	reactome	NA	MAPK family signaling cascades
RAMP_P_000050167	R-HSA-2206285	reactome	NA	MPS VI - Maroteaux-Lamy syndrome
RAMP_P_000050168	R-HSA-72172	reactome	NA	mRNA Splicing
RAMP_P_000050169	R-HSA-373076	reactome	NA	Class A/1 (Rhodopsin-like receptors)
RAMP_P_000050170	R-HSA-5693579	reactome	NA	Homologous DNA Pairing and Strand Exchange
RAMP_P_000050171	R-HSA-5619076	reactome	NA	Defective SLC17A8 causes autosomal dominant deafness 25 (DFNA25)
RAMP_P_000050172	R-HSA-112399	reactome	NA	IRS-mediated signalling
RAMP_P_000050173	R-HSA-977444	reactome	NA	GABA B receptor activation
RAMP_P_000050174	R-HSA-9032845	reactome	NA	Activated NTRK2 signals through CDK5
RAMP_P_000050175	R-HSA-4755609	reactome	NA	Defective DHDDS causes retinitis pigmentosa 59
RAMP_P_000050176	R-HSA-4791275	reactome	NA	Signaling by WNT in cancer
RAMP_P_000050177	R-HSA-351906	reactome	NA	Apoptotic cleavage of cell adhesion  proteins
RAMP_P_000050178	R-HSA-437239	reactome	NA	Recycling pathway of L1
RAMP_P_000050179	R-HSA-5619073	reactome	NA	Defective GCK causes maturity-onset diabetes of the young 2 (MODY2)
RAMP_P_000050180	R-HSA-5610780	reactome	NA	Degradation of GLI1 by the proteasome
RAMP_P_000050181	R-HSA-111997	reactome	NA	CaM pathway
RAMP_P_000050182	R-HSA-442982	reactome	NA	Ras activation upon Ca2+ influx through NMDA receptor
RAMP_P_000050183	R-HSA-991365	reactome	NA	Activation of GABAB receptors
RAMP_P_000050184	R-HSA-5688890	reactome	NA	Defective CSF2RA causes pulmonary surfactant metabolism dysfunction 4 (SMDP4)
RAMP_P_000050185	R-HSA-196791	reactome	NA	Vitamin D (calciferol) metabolism
RAMP_P_000050186	R-HSA-9035968	reactome	NA	Defective GGT1 causes Glutathionuria (GLUTH)
RAMP_P_000050187	R-HSA-76066	reactome	NA	RNA Polymerase III Transcription Initiation From Type 2 Promoter
RAMP_P_000050188	R-HSA-9018677	reactome	NA	Biosynthesis of DHA-derived SPMs
RAMP_P_000050189	R-HSA-2428928	reactome	NA	IRS-related events triggered by IGF1R
RAMP_P_000050190	R-HSA-1483101	reactome	NA	Synthesis of PS
RAMP_P_000050191	R-HSA-166058	reactome	NA	MyD88:MAL(TIRAP) cascade initiated on plasma membrane
RAMP_P_000050192	R-HSA-901042	reactome	NA	Calnexin/calreticulin cycle
RAMP_P_000050193	R-HSA-209931	reactome	NA	Serotonin and melatonin biosynthesis
RAMP_P_000050194	R-HSA-5654693	reactome	NA	FRS-mediated FGFR1 signaling
RAMP_P_000050195	R-HSA-5357905	reactome	NA	Regulation of TNFR1 signaling
RAMP_P_000050196	R-HSA-2029485	reactome	NA	Role of phospholipids in phagocytosis
RAMP_P_000050197	R-HSA-2470946	reactome	NA	Cohesin Loading onto Chromatin
RAMP_P_000050198	R-HSA-2408550	reactome	NA	Metabolism of ingested H2SeO4 and H2SeO3 into H2Se
RAMP_P_000050199	R-HSA-427413	reactome	NA	NoRC negatively regulates rRNA expression
RAMP_P_000050200	R-HSA-5687868	reactome	NA	Defective SFTPA2 causes idiopathic pulmonary fibrosis (IPF)
RAMP_P_000050201	R-HSA-2122947	reactome	NA	NOTCH1 Intracellular Domain Regulates Transcription
RAMP_P_000050202	R-HSA-5579004	reactome	NA	Defective CYP26C1 causes Focal facial dermal dysplasia 4 (FFDD4)
RAMP_P_000050203	R-HSA-1839120	reactome	NA	Signaling by FGFR1 amplification mutants
RAMP_P_000050204	R-HSA-2029481	reactome	NA	FCGR activation
RAMP_P_000050205	R-HSA-5693548	reactome	NA	Sensing of DNA Double Strand Breaks
RAMP_P_000050206	R-HSA-73780	reactome	NA	RNA Polymerase III Chain Elongation
RAMP_P_000050207	R-HSA-2871796	reactome	NA	FCERI mediated MAPK activation
RAMP_P_000050208	R-HSA-8937144	reactome	NA	Aryl hydrocarbon receptor signalling
RAMP_P_000050209	R-HSA-5619045	reactome	NA	Defective SLC34A2 causes pulmonary alveolar microlithiasis (PALM)
RAMP_P_000050210	R-HSA-2408499	reactome	NA	Formation of selenosugars for excretion
RAMP_P_000050211	R-HSA-74158	reactome	NA	RNA Polymerase III Transcription
RAMP_P_000050212	R-HSA-5688031	reactome	NA	Defective pro-SFTPB causes pulmonary surfactant metabolism dysfunction 1 (SMDP1) and respiratory distress syndrome (RDS)
RAMP_P_000050213	R-HSA-8949613	reactome	NA	Cristae formation
RAMP_P_000050214	R-HSA-75953	reactome	NA	RNA Polymerase II Transcription Initiation
RAMP_P_000050215	R-HSA-5340588	reactome	NA	RNF mutants show enhanced WNT signaling and proliferation
RAMP_P_000050216	R-HSA-139915	reactome	NA	Activation of PUMA and translocation to mitochondria
RAMP_P_000050217	R-HSA-69613	reactome	NA	p53-Independent G1/S DNA damage checkpoint
RAMP_P_000050218	R-HSA-975577	reactome	NA	N-Glycan antennae elongation
RAMP_P_000050219	R-HSA-6811434	reactome	NA	COPI-dependent Golgi-to-ER retrograde traffic
RAMP_P_000050220	R-HSA-2555396	reactome	NA	Mitotic Metaphase and Anaphase
RAMP_P_000050221	R-HSA-165054	reactome	NA	Rev-mediated nuclear export of HIV RNA
RAMP_P_000050222	R-HSA-417973	reactome	NA	Adenosine P1 receptors
RAMP_P_000050223	R-HSA-5632987	reactome	NA	Defective Mismatch Repair Associated With PMS2
RAMP_P_000050224	R-HSA-9006921	reactome	NA	Integrin signaling
RAMP_P_000050225	R-HSA-446388	reactome	NA	Regulation of cytoskeletal remodeling and cell spreading by IPP complex components
RAMP_P_000050226	R-HSA-9603381	reactome	NA	Activated NTRK3 signals through PI3K
RAMP_P_000050227	R-HSA-8941326	reactome	NA	RUNX2 regulates bone development
RAMP_P_000050228	R-HSA-5619066	reactome	NA	Defective SLC22A18 causes lung cancer (LNCR) and embryonal rhabdomyosarcoma 1 (RMSE1)
RAMP_P_000050229	R-HSA-5619046	reactome	NA	Defective SLC26A4 causes Pendred syndrome (PDS)
RAMP_P_000050230	R-HSA-8849469	reactome	NA	PTK6 Regulates RTKs and Their Effectors AKT1 and DOK1
RAMP_P_000050231	R-HSA-69306	reactome	NA	DNA Replication
RAMP_P_000050232	R-HSA-111452	reactome	NA	Activation and oligomerization of BAK protein
RAMP_P_000050233	R-HSA-8866423	reactome	NA	VLDL assembly
RAMP_P_000050234	R-HSA-425986	reactome	NA	Sodium/Proton exchangers
RAMP_P_000050235	R-HSA-77595	reactome	NA	Processing of Intronless Pre-mRNAs
RAMP_P_000050236	R-HSA-72702	reactome	NA	Ribosomal scanning and start codon recognition
RAMP_P_000050237	R-HSA-1296072	reactome	NA	Voltage gated Potassium channels
RAMP_P_000050238	R-HSA-4570464	reactome	NA	SUMOylation of RNA binding proteins
RAMP_P_000050239	R-HSA-159418	reactome	NA	Recycling of bile acids and salts
RAMP_P_000050240	R-HSA-418597	reactome	NA	G alpha (z) signalling events
RAMP_P_000050241	R-HSA-2691230	reactome	NA	Signaling by NOTCH1 HD Domain Mutants in Cancer
RAMP_P_000050242	R-HSA-1855191	reactome	NA	Synthesis of IPs in the nucleus
RAMP_P_000050243	R-HSA-5210891	reactome	NA	Uptake and function of anthrax toxins
RAMP_P_000050244	R-HSA-4551638	reactome	NA	SUMOylation of chromatin organization proteins
RAMP_P_000050245	R-HSA-5693606	reactome	NA	DNA Double Strand Break Response
RAMP_P_000050246	R-HSA-5619097	reactome	NA	Defective SLC34A3 causes Hereditary hypophosphatemic rickets with hypercalciuria (HHRH)
RAMP_P_000050247	R-HSA-165158	reactome	NA	Activation of AKT2
RAMP_P_000050248	R-HSA-112409	reactome	NA	RAF-independent MAPK1/3 activation
RAMP_P_000050249	R-HSA-350562	reactome	NA	Regulation of ornithine decarboxylase (ODC)
RAMP_P_000050250	R-HSA-400685	reactome	NA	Sema4D in semaphorin signaling
RAMP_P_000050251	R-HSA-5625740	reactome	NA	RHO GTPases activate PKNs
RAMP_P_000050252	R-HSA-68962	reactome	NA	Activation of the pre-replicative complex
RAMP_P_000050253	R-HSA-76042	reactome	NA	RNA Polymerase II Transcription Initiation And Promoter Clearance
RAMP_P_000050254	R-HSA-453279	reactome	NA	Mitotic G1-G1/S phases
RAMP_P_000050255	R-HSA-166520	reactome	NA	Signaling by NTRKs
RAMP_P_000050256	R-HSA-5678420	reactome	NA	Defective ABCC9 causes dilated cardiomyopathy 10, familial atrial fibrillation 12 and hypertrichotic osteochondrodysplasia
RAMP_P_000050257	R-HSA-6798163	reactome	NA	Choline catabolism
RAMP_P_000050258	R-HSA-199920	reactome	NA	CREB phosphorylation
RAMP_P_000050259	R-HSA-5679096	reactome	NA	Defective ABCG5 causes sitosterolemia
RAMP_P_000050260	R-HSA-428542	reactome	NA	Regulation of commissural axon pathfinding by SLIT and ROBO
RAMP_P_000050261	R-HSA-629594	reactome	NA	Highly calcium permeable postsynaptic nicotinic acetylcholine receptors
RAMP_P_000050262	R-HSA-77288	reactome	NA	mitochondrial fatty acid beta-oxidation of unsaturated fatty acids
RAMP_P_000050263	R-HSA-1237044	reactome	NA	Erythrocytes take up carbon dioxide and release oxygen
RAMP_P_000050264	R-HSA-5083625	reactome	NA	Defective GALNT3 causes familial hyperphosphatemic tumoral calcinosis (HFTC)
RAMP_P_000050265	R-HSA-168303	reactome	NA	Packaging of Eight RNA Segments
RAMP_P_000050266	R-HSA-429947	reactome	NA	Deadenylation of mRNA
RAMP_P_000050267	R-HSA-5687583	reactome	NA	Defective SLC34A2 causes pulmonary alveolar microlithiasis (PALM)
RAMP_P_000050268	R-HSA-525793	reactome	NA	Myogenesis
RAMP_P_000050269	R-HSA-3371378	reactome	NA	Regulation by c-FLIP
RAMP_P_000050270	R-HSA-174048	reactome	NA	APC/C:Cdc20 mediated degradation of Cyclin B
RAMP_P_000050271	R-HSA-6802948	reactome	NA	Signaling by high-kinase activity BRAF mutants
RAMP_P_000050272	R-HSA-1839122	reactome	NA	Signaling by activated point mutants of FGFR1
RAMP_P_000050273	R-HSA-5658442	reactome	NA	Regulation of RAS by GAPs
RAMP_P_000050274	R-HSA-168302	reactome	NA	Budding
RAMP_P_000050275	R-HSA-8875555	reactome	NA	MET activates RAP1 and RAC1
RAMP_P_000050276	R-HSA-69481	reactome	NA	G2/M Checkpoints
RAMP_P_000050277	R-HSA-432030	reactome	NA	Transport of glycerol from adipocytes to the liver by Aquaporins
RAMP_P_000050278	R-HSA-203765	reactome	NA	eNOS activation and regulation
RAMP_P_000050279	R-HSA-1236975	reactome	NA	Antigen processing-Cross presentation
RAMP_P_000050280	R-HSA-5696398	reactome	NA	Nucleotide Excision Repair
RAMP_P_000050281	R-HSA-3359473	reactome	NA	Defective MMADHC causes methylmalonic aciduria and homocystinuria type cblD
RAMP_P_000050282	R-HSA-72731	reactome	NA	Recycling of eIF2:GDP
RAMP_P_000050283	R-HSA-174824	reactome	NA	Plasma lipoprotein assembly, remodeling, and clearance
RAMP_P_000050284	R-HSA-69478	reactome	NA	G2/M DNA replication checkpoint
RAMP_P_000050285	R-HSA-68867	reactome	NA	Assembly of the pre-replicative complex
RAMP_P_000050286	R-HSA-549132	reactome	NA	Organic cation/anion/zwitterion transport
RAMP_P_000050287	R-HSA-3359462	reactome	NA	Defective AMN causes hereditary megaloblastic anemia 1
RAMP_P_000050288	R-HSA-75064	reactome	NA	mRNA Editing: A to I Conversion
RAMP_P_000050289	R-HSA-4839744	reactome	NA	truncated APC mutants destabilize the destruction complex
RAMP_P_000050290	R-HSA-73762	reactome	NA	RNA Polymerase I Transcription Initiation
RAMP_P_000050291	R-HSA-1221632	reactome	NA	Meiotic synapsis
RAMP_P_000050292	R-HSA-176417	reactome	NA	Phosphorylation of Emi1
RAMP_P_000050293	R-HSA-937039	reactome	NA	IRAK1 recruits IKK complex
RAMP_P_000050294	R-HSA-2262752	reactome	NA	Cellular responses to stress
RAMP_P_000050295	R-HSA-1296041	reactome	NA	Activation of G protein gated Potassium channels
RAMP_P_000050296	R-HSA-983169	reactome	NA	Class I MHC mediated antigen processing & presentation
RAMP_P_000050297	R-HSA-390666	reactome	NA	Serotonin receptors
RAMP_P_000050298	R-HSA-196836	reactome	NA	Vitamin C (ascorbate) metabolism
RAMP_P_000050299	R-HSA-181430	reactome	NA	Norepinephrine Neurotransmitter Release Cycle
RAMP_P_000050300	R-HSA-6793080	reactome	NA	rRNA modification in the mitochondrion
RAMP_P_000050301	R-HSA-4641257	reactome	NA	Degradation of AXIN
RAMP_P_000050302	R-HSA-140834	reactome	NA	Extrinsic Pathway of Fibrin Clot Formation
RAMP_P_000050303	R-HSA-210990	reactome	NA	PECAM1 interactions
RAMP_P_000050304	R-HSA-5633008	reactome	NA	TP53 Regulates Transcription of Cell Death Genes
RAMP_P_000050305	R-HSA-3282872	reactome	NA	Severe congenital neutropenia type 4 (G6PC3)
RAMP_P_000050306	R-HSA-453276	reactome	NA	Regulation of mitotic cell cycle
RAMP_P_000050307	R-HSA-111465	reactome	NA	Apoptotic cleavage of cellular proteins
RAMP_P_000050308	R-HSA-1059683	reactome	NA	Interleukin-6 signaling
RAMP_P_000050309	R-HSA-6782861	reactome	NA	Synthesis of wybutosine at G37 of tRNA(Phe)
RAMP_P_000050310	R-HSA-5619035	reactome	NA	Defective SLC17A5 causes Salla disease (SD) and ISSD
RAMP_P_000050311	R-HSA-168176	reactome	NA	Toll Like Receptor 5 (TLR5) Cascade
RAMP_P_000050312	R-HSA-351200	reactome	NA	Interconversion of polyamines
RAMP_P_000050313	R-HSA-8985586	reactome	NA	SLIT2:ROBO1 increases RHOA activity
RAMP_P_000050314	R-HSA-1181150	reactome	NA	Signaling by NODAL
RAMP_P_000050315	R-HSA-8868766	reactome	NA	rRNA processing in the mitochondrion
RAMP_P_000050316	R-HSA-5659735	reactome	NA	Defective SLC6A19 causes Hartnup disorder (HND)
RAMP_P_000050317	R-HSA-4608870	reactome	NA	Asymmetric localization of PCP proteins
RAMP_P_000050318	R-HSA-71336	reactome	NA	Pentose phosphate pathway
RAMP_P_000050319	R-HSA-3000471	reactome	NA	Scavenging by Class B Receptors
RAMP_P_000050320	R-HSA-888568	reactome	NA	GABA synthesis
RAMP_P_000050321	R-HSA-2894858	reactome	NA	Signaling by NOTCH1 HD+PEST Domain Mutants in Cancer
RAMP_P_000050322	R-HSA-8964041	reactome	NA	LDL remodeling
RAMP_P_000050323	R-HSA-1300645	reactome	NA	Acrosome Reaction
RAMP_P_000050324	R-HSA-9020265	reactome	NA	Biosynthesis of aspirin-triggered D-series resolvins
RAMP_P_000050325	R-HSA-2151209	reactome	NA	Activation of PPARGC1A (PGC-1alpha) by phosphorylation
RAMP_P_000050326	R-HSA-5654726	reactome	NA	Negative regulation of FGFR1 signaling
RAMP_P_000050327	R-HSA-111463	reactome	NA	SMAC (DIABLO) binds to IAPs 
RAMP_P_000050328	R-HSA-168254	reactome	NA	Influenza Infection
RAMP_P_000050329	R-HSA-388479	reactome	NA	Vasopressin-like receptors
RAMP_P_000050330	R-HSA-68886	reactome	NA	M Phase
RAMP_P_000050331	R-HSA-209543	reactome	NA	p75NTR recruits signalling complexes
RAMP_P_000050332	R-HSA-198745	reactome	NA	Signalling to STAT3
RAMP_P_000050333	R-HSA-196843	reactome	NA	Vitamin B2 (riboflavin) metabolism
RAMP_P_000050334	R-HSA-5620912	reactome	NA	Anchoring of the basal body to the plasma membrane
RAMP_P_000050335	R-HSA-5576893	reactome	NA	Phase 2 - plateau phase
RAMP_P_000050336	R-HSA-5626978	reactome	NA	TNFR1-mediated ceramide production
RAMP_P_000050337	R-HSA-167238	reactome	NA	Pausing and recovery of Tat-mediated HIV elongation
RAMP_P_000050338	R-HSA-917977	reactome	NA	Transferrin endocytosis and recycling
RAMP_P_000050339	R-HSA-5619058	reactome	NA	Defective SLCO1B3 causes hyperbilirubinemia, Rotor type (HBLRR)
RAMP_P_000050340	R-HSA-916853	reactome	NA	Degradation of GABA
RAMP_P_000050341	R-HSA-193681	reactome	NA	Ceramide signalling
RAMP_P_000050342	R-HSA-168249	reactome	NA	Innate Immune System
RAMP_P_000050343	R-HSA-196071	reactome	NA	Metabolism of steroid hormones
RAMP_P_000050344	R-HSA-69473	reactome	NA	G2/M DNA damage checkpoint
RAMP_P_000050345	R-HSA-6802955	reactome	NA	Paradoxical activation of RAF signaling by kinase inactive BRAF
RAMP_P_000050346	R-HSA-5083629	reactome	NA	Defective POMT2 causes MDDGA2, MDDGB2 and MDDGC2
RAMP_P_000050347	R-HSA-2468052	reactome	NA	Establishment of Sister Chromatid Cohesion
RAMP_P_000050348	R-HSA-5357956	reactome	NA	TNFR1-induced NFkappaB signaling pathway
RAMP_P_000050349	R-HSA-9608287	reactome	NA	Defective MUTYH substrate binding
RAMP_P_000050350	R-HSA-4549380	reactome	NA	Defective ALG1 causes ALG1-CDG (CDG-1k)
RAMP_P_000050351	R-HSA-379726	reactome	NA	Mitochondrial tRNA aminoacylation
RAMP_P_000050352	R-HSA-428540	reactome	NA	Activation of RAC1
RAMP_P_000050353	R-HSA-352230	reactome	NA	Amino acid transport across the plasma membrane
RAMP_P_000050354	R-HSA-6787450	reactome	NA	tRNA modification in the mitochondrion
RAMP_P_000050355	R-HSA-162587	reactome	NA	HIV Life Cycle
RAMP_P_000050356	R-HSA-444821	reactome	NA	Relaxin receptors
RAMP_P_000050357	R-HSA-629602	reactome	NA	Activation of Nicotinic Acetylcholine Receptors
RAMP_P_000050358	R-HSA-5666185	reactome	NA	RHO GTPases Activate Rhotekin and Rhophilins
RAMP_P_000050359	R-HSA-5334118	reactome	NA	DNA methylation
RAMP_P_000050360	R-HSA-1489509	reactome	NA	DAG and IP3 signaling
RAMP_P_000050361	R-HSA-210746	reactome	NA	Regulation of gene expression in endocrine-committed (NEUROG3+) progenitor cells
RAMP_P_000050362	R-HSA-6807004	reactome	NA	Negative regulation of MET activity
RAMP_P_000050363	R-HSA-5657562	reactome	NA	Essential fructosuria
RAMP_P_000050364	R-HSA-375281	reactome	NA	Hormone ligand-binding receptors
RAMP_P_000050365	R-HSA-447115	reactome	NA	Interleukin-12 family signaling
RAMP_P_000050366	R-HSA-1250342	reactome	NA	PI3K events in ERBB4 signaling
RAMP_P_000050367	R-HSA-2142770	reactome	NA	Synthesis of 15-eicosatetraenoic acid derivatives
RAMP_P_000050368	R-HSA-2206308	reactome	NA	MPS IV - Morquio syndrome B
RAMP_P_000050369	R-HSA-5602636	reactome	NA	IKBKB deficiency causes SCID
RAMP_P_000050370	R-HSA-8964616	reactome	NA	G beta:gamma signalling through CDC42
RAMP_P_000050371	R-HSA-9006931	reactome	NA	Signaling by Nuclear Receptors
RAMP_P_000050372	R-HSA-217271	reactome	NA	FMO oxidises nucleophiles
RAMP_P_000050373	R-HSA-6782135	reactome	NA	Dual incision in TC-NER
RAMP_P_000050374	R-HSA-167044	reactome	NA	Signalling to RAS
RAMP_P_000050375	R-HSA-1660499	reactome	NA	Synthesis of PIPs at the plasma membrane
RAMP_P_000050376	R-HSA-3781860	reactome	NA	Diseases associated with N-glycosylation of proteins
RAMP_P_000050377	R-HSA-3249367	reactome	NA	STAT6-mediated induction of chemokines
RAMP_P_000050378	R-HSA-2871837	reactome	NA	FCERI mediated NF-kB activation
RAMP_P_000050379	R-HSA-390650	reactome	NA	Histamine receptors
RAMP_P_000050380	R-HSA-4551295	reactome	NA	Defective ALG11 causes ALG11-CDG (CDG-1p)
RAMP_P_000050381	R-HSA-5663084	reactome	NA	Diseases of carbohydrate metabolism
RAMP_P_000050382	R-HSA-427589	reactome	NA	Type II Na+/Pi cotransporters
RAMP_P_000050383	R-HSA-5579006	reactome	NA	Defective GSS causes Glutathione synthetase deficiency (GSS deficiency)
RAMP_P_000050384	R-HSA-451308	reactome	NA	Activation of Ca-permeable Kainate Receptor
RAMP_P_000050385	R-HSA-6796648	reactome	NA	TP53 Regulates Transcription of DNA Repair Genes
RAMP_P_000050386	R-HSA-72706	reactome	NA	GTP hydrolysis and joining of the 60S ribosomal subunit
RAMP_P_000050387	R-HSA-447038	reactome	NA	NrCAM interactions
RAMP_P_000050388	R-HSA-389958	reactome	NA	Cooperation of Prefoldin and TriC/CCT  in actin and tubulin folding
RAMP_P_000050389	R-HSA-1296067	reactome	NA	Potassium transport channels
RAMP_P_000050390	R-HSA-5627083	reactome	NA	RHO GTPases regulate CFTR trafficking
RAMP_P_000050391	R-HSA-9022927	reactome	NA	MECP2 regulates transcription of genes involved in GABA signaling
RAMP_P_000050392	R-HSA-5610787	reactome	NA	Hedgehog 'off' state
RAMP_P_000050393	R-HSA-5676594	reactome	NA	TNF receptor superfamily (TNFSF) members mediating non-canonical NF-kB pathway
RAMP_P_000050394	R-HSA-3299685	reactome	NA	Detoxification of Reactive Oxygen Species
RAMP_P_000050395	R-HSA-112303	reactome	NA	Electric Transmission Across Gap Junctions
RAMP_P_000050396	R-HSA-5654719	reactome	NA	SHC-mediated cascade:FGFR4
RAMP_P_000050397	R-HSA-3232118	reactome	NA	SUMOylation of transcription factors
RAMP_P_000050398	R-HSA-2032785	reactome	NA	YAP1- and WWTR1 (TAZ)-stimulated gene expression
RAMP_P_000050399	R-HSA-211916	reactome	NA	Vitamins
RAMP_P_000050400	R-HSA-8851708	reactome	NA	Signaling by FGFR2 IIIa TM
RAMP_P_000050401	R-HSA-446219	reactome	NA	Synthesis of substrates in N-glycan biosythesis
RAMP_P_000050402	R-HSA-418457	reactome	NA	cGMP effects
RAMP_P_000050403	R-HSA-9024909	reactome	NA	BDNF activates NTRK2 (TRKB) signaling
RAMP_P_000050404	R-HSA-170145	reactome	NA	Phosphorylation of proteins involved in the G2/M transition by Cyclin A:Cdc2 complexes
RAMP_P_000050405	R-HSA-167158	reactome	NA	Formation of the HIV-1 Early Elongation Complex
RAMP_P_000050406	R-HSA-1251932	reactome	NA	PLCG1 events in ERBB2 signaling
RAMP_P_000050407	R-HSA-1222499	reactome	NA	Response of Mtb to phagocytosis
RAMP_P_000050408	R-HSA-8964026	reactome	NA	Chylomicron clearance
RAMP_P_000050409	R-HSA-6791461	reactome	NA	RPIA deficiency: failed conversion of RU5P to R5P
RAMP_P_000050410	R-HSA-3270619	reactome	NA	IRF3-mediated induction of type I IFN
RAMP_P_000050411	R-HSA-205017	reactome	NA	NFG and proNGF binds to p75NTR
RAMP_P_000050412	R-HSA-1187000	reactome	NA	Fertilization
RAMP_P_000050413	R-HSA-417957	reactome	NA	P2Y receptors
RAMP_P_000050414	R-HSA-1502540	reactome	NA	Signaling by Activin
RAMP_P_000050415	R-HSA-165160	reactome	NA	PDE3B signalling
RAMP_P_000050416	R-HSA-5668599	reactome	NA	RHO GTPases Activate NADPH Oxidases
RAMP_P_000050417	R-HSA-4085023	reactome	NA	Defective GFPT1 causes CMSTA1
RAMP_P_000050418	R-HSA-5609978	reactome	NA	Defective GALT can cause Galactosemia
RAMP_P_000050419	R-HSA-109688	reactome	NA	Cleavage of Growing Transcript in the Termination Region 
RAMP_P_000050420	R-HSA-390247	reactome	NA	Beta-oxidation of very long chain fatty acids
RAMP_P_000050421	R-HSA-2562578	reactome	NA	TRIF-mediated programmed cell death
RAMP_P_000050422	R-HSA-5654720	reactome	NA	PI-3K cascade:FGFR4
RAMP_P_000050423	R-HSA-211957	reactome	NA	Aromatic amines can be N-hydroxylated or N-dealkylated by CYP1A2
RAMP_P_000050424	R-HSA-425561	reactome	NA	Sodium/Calcium exchangers
RAMP_P_000050425	R-HSA-203615	reactome	NA	eNOS activation
RAMP_P_000050426	R-HSA-69190	reactome	NA	DNA strand elongation
RAMP_P_000050427	R-HSA-8866904	reactome	NA	Negative regulation of activity of TFAP2 (AP-2) family transcription factors
RAMP_P_000050428	R-HSA-6814122	reactome	NA	Cooperation of PDCL (PhLP1) and TRiC/CCT in G-protein beta folding
RAMP_P_000050429	R-HSA-203754	reactome	NA	NOSIP mediated eNOS trafficking
RAMP_P_000050430	R-HSA-9027283	reactome	NA	Erythropoietin activates STAT5
RAMP_P_000050431	R-HSA-190828	reactome	NA	Gap junction trafficking
RAMP_P_000050432	R-HSA-3645790	reactome	NA	TGFBR2 Kinase Domain Mutants in Cancer
RAMP_P_000050433	R-HSA-373760	reactome	NA	L1CAM interactions
RAMP_P_000050434	R-HSA-5620916	reactome	NA	VxPx cargo-targeting to cilium
RAMP_P_000050435	R-HSA-3000178	reactome	NA	ECM proteoglycans
RAMP_P_000050436	R-HSA-71288	reactome	NA	Creatine metabolism
RAMP_P_000050437	R-HSA-164944	reactome	NA	Nef and signal transduction
RAMP_P_000050438	R-HSA-73857	reactome	NA	RNA Polymerase II Transcription
RAMP_P_000050439	R-HSA-1296065	reactome	NA	Inwardly rectifying K+ channels
RAMP_P_000050440	R-HSA-1236977	reactome	NA	Endosomal/Vacuolar pathway
RAMP_P_000050441	R-HSA-8876493	reactome	NA	InlA-mediated entry of Listeria monocytogenes into host cells
RAMP_P_000050442	R-HSA-112043	reactome	NA	PLC beta mediated events
RAMP_P_000050443	R-HSA-9020958	reactome	NA	Interleukin-21 signaling
RAMP_P_000050444	R-HSA-176974	reactome	NA	Unwinding of DNA
RAMP_P_000050445	R-HSA-442755	reactome	NA	Activation of NMDA receptors and postsynaptic events
RAMP_P_000050446	R-HSA-140875	reactome	NA	Common Pathway of Fibrin Clot Formation
RAMP_P_000050447	R-HSA-426486	reactome	NA	Small interfering RNA (siRNA) biogenesis
RAMP_P_000050448	R-HSA-2500257	reactome	NA	Resolution of Sister Chromatid Cohesion
RAMP_P_000050449	R-HSA-69236	reactome	NA	G1 Phase
RAMP_P_000050450	R-HSA-1852241	reactome	NA	Organelle biogenesis and maintenance
RAMP_P_000050451	R-HSA-168142	reactome	NA	Toll Like Receptor 10 (TLR10) Cascade
RAMP_P_000050452	R-HSA-177128	reactome	NA	Conjugation of salicylate with glycine
RAMP_P_000050453	R-HSA-2033515	reactome	NA	t(4;14) translocations of FGFR3
RAMP_P_000050454	R-HSA-5213460	reactome	NA	RIPK1-mediated regulated necrosis
RAMP_P_000050455	R-HSA-390471	reactome	NA	Association of TriC/CCT with target proteins during biosynthesis
RAMP_P_000050456	R-HSA-113507	reactome	NA	E2F-enabled inhibition of pre-replication complex formation
RAMP_P_000050457	R-HSA-69200	reactome	NA	Phosphorylation of proteins involved in G1/S transition by active Cyclin E:Cdk2 complexes
RAMP_P_000050458	R-HSA-5619115	reactome	NA	Disorders of transmembrane transporters
RAMP_P_000050459	R-HSA-111471	reactome	NA	Apoptotic factor-mediated response
RAMP_P_000050460	R-HSA-381042	reactome	NA	PERK regulates gene expression
RAMP_P_000050461	R-HSA-194313	reactome	NA	VEGF ligand-receptor interactions
RAMP_P_000050462	R-HSA-5339700	reactome	NA	TCF7L2 mutants don't bind CTBP
RAMP_P_000050463	R-HSA-430116	reactome	NA	GP1b-IX-V activation signalling
RAMP_P_000050464	R-HSA-5545483	reactome	NA	Defective Mismatch Repair Associated With MLH1
RAMP_P_000050465	R-HSA-1236394	reactome	NA	Signaling by ERBB4
RAMP_P_000050466	R-HSA-75094	reactome	NA	Formation of the Editosome
RAMP_P_000050467	R-HSA-167826	reactome	NA	The fatty acid cycling model
RAMP_P_000050468	R-HSA-8979227	reactome	NA	Triglyceride metabolism
RAMP_P_000050469	R-HSA-2173791	reactome	NA	TGF-beta receptor signaling in EMT (epithelial to mesenchymal transition)
RAMP_P_000050470	R-HSA-418217	reactome	NA	G beta:gamma signalling through PLC beta
RAMP_P_000050471	R-HSA-389948	reactome	NA	PD-1 signaling
RAMP_P_000050472	R-HSA-2559586	reactome	NA	DNA Damage/Telomere Stress Induced Senescence
RAMP_P_000050473	R-HSA-2465910	reactome	NA	MASTL Facilitates Mitotic Progression
RAMP_P_000050474	R-HSA-975110	reactome	NA	TRAF6 mediated IRF7 activation in TLR7/8 or 9 signaling
RAMP_P_000050475	R-HSA-112311	reactome	NA	Neurotransmitter clearance
RAMP_P_000050476	R-HSA-162582	reactome	NA	Signal Transduction
RAMP_P_000050477	R-HSA-73928	reactome	NA	Depyrimidination
RAMP_P_000050478	R-HSA-111931	reactome	NA	PKA-mediated phosphorylation of CREB
RAMP_P_000050479	R-HSA-8877627	reactome	NA	Vitamin E
RAMP_P_000050480	R-HSA-5619060	reactome	NA	Defective CP causes aceruloplasminemia (ACERULOP)
RAMP_P_000050481	R-HSA-194002	reactome	NA	Glucocorticoid biosynthesis
RAMP_P_000050482	R-HSA-2206296	reactome	NA	MPS II - Hunter syndrome
RAMP_P_000050483	R-HSA-195253	reactome	NA	Degradation of beta-catenin by the destruction complex
RAMP_P_000050484	R-HSA-388396	reactome	NA	GPCR downstream signalling
RAMP_P_000050485	R-HSA-982772	reactome	NA	Growth hormone receptor signaling
RAMP_P_000050486	R-HSA-9027284	reactome	NA	Erythropoietin activates RAS
RAMP_P_000050487	R-HSA-2485179	reactome	NA	Activation of the phototransduction cascade
RAMP_P_000050488	R-HSA-8948216	reactome	NA	Collagen chain trimerization
RAMP_P_000050489	R-HSA-450282	reactome	NA	MAPK targets/ Nuclear events mediated by MAP kinases
RAMP_P_000050490	R-HSA-983189	reactome	NA	Kinesins
RAMP_P_000050491	R-HSA-211979	reactome	NA	Eicosanoids
RAMP_P_000050492	R-HSA-3814836	reactome	NA	Glycogen storage disease type XV (GYG1)
RAMP_P_000050493	R-HSA-3769402	reactome	NA	Deactivation of the beta-catenin transactivating complex
RAMP_P_000050494	R-HSA-168898	reactome	NA	Toll-like Receptor Cascades
RAMP_P_000050495	R-HSA-1306955	reactome	NA	GRB7 events in ERBB2 signaling
RAMP_P_000050496	R-HSA-6784531	reactome	NA	tRNA processing in the nucleus
RAMP_P_000050497	R-HSA-169911	reactome	NA	Regulation of Apoptosis
RAMP_P_000050498	R-HSA-5682113	reactome	NA	Defective ABCA1 causes Tangier disease
RAMP_P_000050499	R-HSA-165159	reactome	NA	mTOR signalling
RAMP_P_000050500	R-HSA-5625970	reactome	NA	RHO GTPases activate KTN1
RAMP_P_000050501	R-HSA-448706	reactome	NA	Interleukin-1 processing
RAMP_P_000050502	R-HSA-391903	reactome	NA	Eicosanoid ligand-binding receptors
RAMP_P_000050503	R-HSA-445095	reactome	NA	Interaction between L1 and Ankyrins
RAMP_P_000050504	R-HSA-112412	reactome	NA	SOS-mediated signalling
RAMP_P_000050505	R-HSA-5654221	reactome	NA	Phospholipase C-mediated cascade; FGFR2
RAMP_P_000050506	R-HSA-9007101	reactome	NA	Rab regulation of trafficking
RAMP_P_000050507	R-HSA-2024096	reactome	NA	HS-GAG degradation
RAMP_P_000050508	R-HSA-399954	reactome	NA	Sema3A PAK dependent Axon repulsion
RAMP_P_000050509	R-HSA-140180	reactome	NA	COX reactions
RAMP_P_000050510	R-HSA-844456	reactome	NA	The NLRP3 inflammasome
RAMP_P_000050511	R-HSA-9018682	reactome	NA	Biosynthesis of maresins
RAMP_P_000050512	R-HSA-191859	reactome	NA	snRNP Assembly
RAMP_P_000050513	R-HSA-170670	reactome	NA	Adenylate cyclase inhibitory pathway
RAMP_P_000050514	R-HSA-9014325	reactome	NA	TICAM1,TRAF6-dependent induction of TAK1 complex
RAMP_P_000050515	R-HSA-5467333	reactome	NA	APC truncation mutants are not K63 polyubiquitinated
RAMP_P_000050516	R-HSA-9620244	reactome	NA	Long-term potentiation
RAMP_P_000050517	R-HSA-5686938	reactome	NA	Regulation of TLR by endogenous ligand
RAMP_P_000050518	R-HSA-6785631	reactome	NA	ERBB2 Regulates Cell Motility
RAMP_P_000050519	R-HSA-1428517	reactome	NA	The citric acid (TCA) cycle and respiratory electron transport
RAMP_P_000050520	R-HSA-5619113	reactome	NA	Defective SLC3A1 causes cystinuria (CSNU)
RAMP_P_000050521	R-HSA-1660524	reactome	NA	PIPs transport between plasma and early endosome membranes
RAMP_P_000050522	R-HSA-199977	reactome	NA	ER to Golgi Anterograde Transport
RAMP_P_000050523	R-HSA-6802957	reactome	NA	Oncogenic MAPK signaling
RAMP_P_000050524	R-HSA-391908	reactome	NA	Prostanoid ligand receptors
RAMP_P_000050525	R-HSA-879518	reactome	NA	Transport of organic anions
RAMP_P_000050526	R-HSA-113501	reactome	NA	Inhibition of replication initiation of damaged DNA by RB1/E2F1
RAMP_P_000050527	R-HSA-1266695	reactome	NA	Interleukin-7 signaling
RAMP_P_000050528	R-HSA-140179	reactome	NA	Amine Oxidase reactions
RAMP_P_000050529	R-HSA-432040	reactome	NA	Vasopressin regulates renal water homeostasis via Aquaporins
RAMP_P_000050530	R-HSA-1855156	reactome	NA	IPs transport between ER lumen and nucleus
RAMP_P_000050531	R-HSA-2029482	reactome	NA	Regulation of actin dynamics for phagocytic cup formation
RAMP_P_000050532	R-HSA-8952158	reactome	NA	RUNX3 regulates BCL2L11 (BIM) transcription
RAMP_P_000050533	R-HSA-4090294	reactome	NA	SUMOylation of intracellular receptors
RAMP_P_000050534	R-HSA-8941858	reactome	NA	Regulation of RUNX3 expression and activity
RAMP_P_000050535	R-HSA-211227	reactome	NA	Activation of DNA fragmentation factor
RAMP_P_000050536	R-HSA-187024	reactome	NA	NGF-independant TRKA activation
RAMP_P_000050537	R-HSA-163767	reactome	NA	PP2A-mediated dephosphorylation of key metabolic factors
RAMP_P_000050538	R-HSA-3642278	reactome	NA	Loss of Function of TGFBR2 in Cancer
RAMP_P_000050539	R-HSA-3296197	reactome	NA	Hydroxycarboxylic acid-binding receptors
RAMP_P_000050540	R-HSA-5358751	reactome	NA	S45 mutants of beta-catenin aren't phosphorylated
RAMP_P_000050541	R-HSA-4720475	reactome	NA	Defective ALG3 causes ALG3-CDG (CDG-1d)
RAMP_P_000050542	R-HSA-73893	reactome	NA	DNA Damage Bypass
RAMP_P_000050543	R-HSA-9018678	reactome	NA	Biosynthesis of specialized proresolving mediators (SPMs)
RAMP_P_000050544	R-HSA-425407	reactome	NA	SLC-mediated transmembrane transport
RAMP_P_000050545	R-HSA-159234	reactome	NA	Transport of Mature mRNAs Derived from Intronless Transcripts
RAMP_P_000050546	R-HSA-5368598	reactome	NA	Negative regulation of TCF-dependent signaling by DVL-interacting proteins
RAMP_P_000050547	R-HSA-113510	reactome	NA	E2F mediated regulation of DNA replication
RAMP_P_000050548	R-HSA-9027276	reactome	NA	Erythropoietin activates Phosphoinositide-3-kinase (PI3K)
RAMP_P_000050549	R-HSA-9027307	reactome	NA	Biosynthesis of maresin-like SPMs
RAMP_P_000050550	R-HSA-112313	reactome	NA	Neurotransmitter uptake and metabolism In glial cells
RAMP_P_000050551	R-HSA-159231	reactome	NA	Transport of Mature mRNA Derived from an Intronless Transcript
RAMP_P_000050552	R-HSA-1663150	reactome	NA	The activation of arylsulfatases
RAMP_P_000050553	R-HSA-5602415	reactome	NA	UNC93B1 deficiency - HSE
RAMP_P_000050554	R-HSA-5654700	reactome	NA	FRS-mediated FGFR2 signaling
RAMP_P_000050555	R-HSA-1236978	reactome	NA	Cross-presentation of soluble exogenous antigens (endosomes)
RAMP_P_000050556	R-HSA-1234174	reactome	NA	Regulation of Hypoxia-inducible Factor (HIF) by oxygen
RAMP_P_000050557	R-HSA-1222449	reactome	NA	Mtb iron assimilation by chelation
RAMP_P_000050558	R-HSA-110330	reactome	NA	Recognition and association of DNA glycosylase with site containing an affected purine
RAMP_P_000050559	R-HSA-72613	reactome	NA	Eukaryotic Translation Initiation
RAMP_P_000050560	R-HSA-9006335	reactome	NA	Signaling by Erythropoietin
RAMP_P_000050561	R-HSA-176412	reactome	NA	Phosphorylation of the APC/C
RAMP_P_000050562	R-HSA-9614085	reactome	NA	FOXO-mediated transcription
RAMP_P_000050563	R-HSA-5678895	reactome	NA	Defective CFTR causes cystic fibrosis
RAMP_P_000050564	R-HSA-5579016	reactome	NA	Defective UGT1A4 causes hyperbilirubinemia
RAMP_P_000050565	R-HSA-8876725	reactome	NA	Protein methylation
RAMP_P_000050566	R-HSA-9006115	reactome	NA	Signaling by NTRK2 (TRKB)
RAMP_P_000050567	R-HSA-76061	reactome	NA	RNA Polymerase III Transcription Initiation From Type 1 Promoter
RAMP_P_000050568	R-HSA-170984	reactome	NA	ARMS-mediated activation
RAMP_P_000050569	R-HSA-166786	reactome	NA	Creation of C4 and C2 activators
RAMP_P_000050570	R-HSA-1368071	reactome	NA	NR1D1 (REV-ERBA) represses gene expression
RAMP_P_000050571	R-HSA-9027277	reactome	NA	Erythropoietin activates Phospholipase C gamma (PLCG)
RAMP_P_000050572	R-HSA-1296071	reactome	NA	Potassium Channels
RAMP_P_000050573	R-HSA-8851680	reactome	NA	Butyrophilin (BTN) family interactions
RAMP_P_000050574	R-HSA-75102	reactome	NA	C6 deamination of adenosine
RAMP_P_000050575	R-HSA-4793952	reactome	NA	Defective MGAT2 causes MGAT2-CDG (CDG-2a)
RAMP_P_000050576	R-HSA-162658	reactome	NA	Golgi Cisternae Pericentriolar Stack Reorganization
RAMP_P_000050577	R-HSA-5635838	reactome	NA	Activation of SMO
RAMP_P_000050578	R-HSA-5687613	reactome	NA	Diseases associated with surfactant metabolism
RAMP_P_000050579	R-HSA-9018681	reactome	NA	Biosynthesis of protectins
RAMP_P_000050580	R-HSA-69560	reactome	NA	Transcriptional activation of p53 responsive genes  
RAMP_P_000050581	R-HSA-5654727	reactome	NA	Negative regulation of FGFR2 signaling
RAMP_P_000050582	R-HSA-1482922	reactome	NA	Acyl chain remodelling of PI
RAMP_P_000050583	R-HSA-381426	reactome	NA	Regulation of Insulin-like Growth Factor (IGF) transport and uptake by Insulin-like Growth Factor Binding Proteins (IGFBPs)
RAMP_P_000050584	R-HSA-5099900	reactome	NA	WNT5A-dependent internalization of FZD4
RAMP_P_000050585	R-HSA-176814	reactome	NA	Activation of APC/C and APC/C:Cdc20 mediated degradation of mitotic proteins
RAMP_P_000050586	R-HSA-8982491	reactome	NA	Glycogen metabolism
RAMP_P_000050587	R-HSA-189085	reactome	NA	Digestion of dietary carbohydrate
RAMP_P_000050588	R-HSA-1482925	reactome	NA	Acyl chain remodelling of PG
RAMP_P_000050589	R-HSA-111932	reactome	NA	CaMK IV-mediated phosphorylation of CREB
RAMP_P_000050590	R-HSA-372708	reactome	NA	p130Cas linkage to MAPK signaling for integrins
RAMP_P_000050591	R-HSA-156587	reactome	NA	Amino Acid conjugation
RAMP_P_000050592	R-HSA-190374	reactome	NA	FGFR1c and Klotho ligand binding and activation
RAMP_P_000050593	R-HSA-180585	reactome	NA	Vif-mediated degradation of APOBEC3G
RAMP_P_000050594	R-HSA-416700	reactome	NA	Other semaphorin interactions
RAMP_P_000050595	R-HSA-5621481	reactome	NA	C-type lectin receptors (CLRs)
RAMP_P_000050596	R-HSA-2022854	reactome	NA	Keratan sulfate biosynthesis
RAMP_P_000050597	R-HSA-1222352	reactome	NA	Latent infection of Homo sapiens with Mycobacterium tuberculosis
RAMP_P_000050598	R-HSA-196741	reactome	NA	Cobalamin (Cbl, vitamin B12) transport and metabolism
RAMP_P_000050599	R-HSA-381771	reactome	NA	Synthesis, secretion, and inactivation of Glucagon-like Peptide-1 (GLP-1)
RAMP_P_000050600	R-HSA-74259	reactome	NA	Purine catabolism
RAMP_P_000050601	R-HSA-451927	reactome	NA	Interleukin-2 family signaling
RAMP_P_000050602	R-HSA-166020	reactome	NA	Transfer of LPS from LBP carrier to CD14
RAMP_P_000050603	R-HSA-197264	reactome	NA	Nicotinamide salvaging
RAMP_P_000050604	R-HSA-2173793	reactome	NA	Transcriptional activity of SMAD2/SMAD3:SMAD4 heterotrimer
RAMP_P_000050605	R-HSA-166208	reactome	NA	mTORC1-mediated signalling
RAMP_P_000050606	R-HSA-8851805	reactome	NA	MET activates RAS signaling
RAMP_P_000050607	R-HSA-5579030	reactome	NA	Defective CYP19A1 causes Aromatase excess syndrome (AEXS)
RAMP_P_000050608	R-HSA-5693532	reactome	NA	DNA Double-Strand Break Repair
RAMP_P_000050609	R-HSA-9605308	reactome	NA	Diseases of Base Excision Repair
RAMP_P_000050610	R-HSA-3323169	reactome	NA	Defects in biotin (Btn) metabolism
RAMP_P_000050611	R-HSA-212718	reactome	NA	EGFR interacts with phospholipase C-gamma
RAMP_P_000050612	R-HSA-389356	reactome	NA	CD28 co-stimulation
RAMP_P_000050613	R-HSA-209560	reactome	NA	NF-kB is activated and signals survival
RAMP_P_000050614	R-HSA-187015	reactome	NA	Activation of TRKA receptors
RAMP_P_000050615	R-HSA-5250968	reactome	NA	Toxicity of botulinum toxin type A (BoNT/A)
RAMP_P_000050616	R-HSA-9007892	reactome	NA	Interleukin-38 signaling
RAMP_P_000050617	R-HSA-210991	reactome	NA	Basigin interactions
RAMP_P_000050618	R-HSA-446728	reactome	NA	Cell junction organization
RAMP_P_000050619	R-HSA-8856828	reactome	NA	Clathrin-mediated endocytosis
RAMP_P_000050620	R-HSA-8957275	reactome	NA	Post-translational protein phosphorylation
RAMP_P_000050621	R-HSA-9605310	reactome	NA	Defective Base Excision Repair Associated with MUTYH
RAMP_P_000050622	R-HSA-5603029	reactome	NA	IkBA variant leads to EDA-ID
RAMP_P_000050623	R-HSA-194306	reactome	NA	Neurophilin interactions with VEGF and VEGFR
RAMP_P_000050624	R-HSA-9013507	reactome	NA	NOTCH3 Activation and Transmission of Signal to the Nucleus
RAMP_P_000050625	R-HSA-975163	reactome	NA	IRAK2 mediated activation of TAK1 complex upon TLR7/8 or 9 stimulation
RAMP_P_000050626	R-HSA-2428933	reactome	NA	SHC-related events triggered by IGF1R
RAMP_P_000050627	R-HSA-947581	reactome	NA	Molybdenum cofactor biosynthesis
RAMP_P_000050628	R-HSA-192814	reactome	NA	vRNA Synthesis
RAMP_P_000050629	R-HSA-6791055	reactome	NA	TALDO1 deficiency: failed conversion of SH7P, GA3P to Fru(6)P, E4P
RAMP_P_000050630	R-HSA-3656234	reactome	NA	Defective HEXA causes GM2G1
RAMP_P_000050631	R-HSA-9026519	reactome	NA	Activated NTRK2 signals through RAS
RAMP_P_000050632	R-HSA-2172127	reactome	NA	DAP12 interactions
RAMP_P_000050633	R-HSA-110329	reactome	NA	Cleavage of the damaged pyrimidine 
RAMP_P_000050634	R-HSA-1855167	reactome	NA	Synthesis of pyrophosphates in the cytosol
RAMP_P_000050635	R-HSA-6781827	reactome	NA	Transcription-Coupled Nucleotide Excision Repair (TC-NER)
RAMP_P_000050636	R-HSA-977606	reactome	NA	Regulation of Complement cascade
RAMP_P_000050637	R-HSA-76005	reactome	NA	Response to elevated platelet cytosolic Ca2+
RAMP_P_000050638	R-HSA-5140745	reactome	NA	WNT5A-dependent internalization of FZD2, FZD5 and ROR2
RAMP_P_000050639	R-HSA-5340573	reactome	NA	WNT ligand secretion is abrogated by the PORCN inhibitor LGK974
RAMP_P_000050640	R-HSA-212300	reactome	NA	PRC2 methylates histones and DNA
RAMP_P_000050641	R-HSA-375170	reactome	NA	CDO in myogenesis
RAMP_P_000050642	R-HSA-5654710	reactome	NA	PI-3K cascade:FGFR3
RAMP_P_000050643	R-HSA-168928	reactome	NA	DDX58/IFIH1-mediated induction of interferon-alpha/beta
RAMP_P_000050644	R-HSA-68882	reactome	NA	Mitotic Anaphase
RAMP_P_000050645	R-HSA-9025106	reactome	NA	Biosynthesis of DPAn-6 SPMs
RAMP_P_000050646	R-HSA-193692	reactome	NA	Regulated proteolysis of p75NTR
RAMP_P_000050647	R-HSA-2206282	reactome	NA	MPS IIIB - Sanfilippo syndrome B
RAMP_P_000050648	R-HSA-416476	reactome	NA	G alpha (q) signalling events
RAMP_P_000050649	R-HSA-888593	reactome	NA	Reuptake of GABA
RAMP_P_000050650	R-HSA-416993	reactome	NA	Trafficking of GluR2-containing AMPA receptors
RAMP_P_000050651	R-HSA-71384	reactome	NA	Ethanol oxidation
RAMP_P_000050652	R-HSA-168927	reactome	NA	TICAM1, RIP1-mediated IKK complex recruitment 
RAMP_P_000050653	R-HSA-109606	reactome	NA	Intrinsic Pathway for Apoptosis
RAMP_P_000050654	R-HSA-191647	reactome	NA	c-src mediated regulation of Cx43 function and closure of gap junctions
RAMP_P_000050655	R-HSA-114608	reactome	NA	Platelet degranulation 
RAMP_P_000050656	R-HSA-1250196	reactome	NA	SHC1 events in ERBB2 signaling
RAMP_P_000050657	R-HSA-211000	reactome	NA	Gene Silencing by RNA
RAMP_P_000050658	R-HSA-379716	reactome	NA	Cytosolic tRNA aminoacylation
RAMP_P_000050659	R-HSA-5619055	reactome	NA	Defective SLC24A4 causes hypomineralized amelogenesis imperfecta (AI)
RAMP_P_000050660	R-HSA-194840	reactome	NA	Rho GTPase cycle
RAMP_P_000050661	R-HSA-73943	reactome	NA	Reversal of alkylation damage by DNA dioxygenases
RAMP_P_000050662	R-HSA-5684045	reactome	NA	Defective ABCD1 causes adrenoleukodystrophy (ALD)
RAMP_P_000050663	R-HSA-5250981	reactome	NA	Toxicity of botulinum toxin type F (BoNT/F)
RAMP_P_000050664	R-HSA-392518	reactome	NA	Signal amplification
RAMP_P_000050665	R-HSA-539107	reactome	NA	Activation of E2F1 target genes at G1/S
RAMP_P_000050666	R-HSA-174430	reactome	NA	Telomere C-strand synthesis initiation
RAMP_P_000050667	R-HSA-5578996	reactome	NA	Defective CYP27A1 causes Cerebrotendinous xanthomatosis (CTX)
RAMP_P_000050668	R-HSA-5619079	reactome	NA	Defective SLC6A18 may confer susceptibility to iminoglycinuria and/or hyperglycinuria
RAMP_P_000050669	R-HSA-5609974	reactome	NA	Defective PGM1 causes PGM1-CDG (CDG1t)
RAMP_P_000050670	R-HSA-72662	reactome	NA	Activation of the mRNA upon binding of the cap-binding complex and eIFs, and subsequent binding to 43S
RAMP_P_000050671	R-HSA-912631	reactome	NA	Regulation of signaling by CBL
RAMP_P_000050672	R-HSA-166658	reactome	NA	Complement cascade
RAMP_P_000050673	R-HSA-9034793	reactome	NA	Activated NTRK3 signals through PLCG1
RAMP_P_000050674	R-HSA-180746	reactome	NA	Nuclear import of Rev protein
RAMP_P_000050675	R-HSA-349425	reactome	NA	Autodegradation of the E3 ubiquitin ligase COP1
RAMP_P_000050676	R-HSA-139853	reactome	NA	Elevation of cytosolic Ca2+ levels
RAMP_P_000050677	R-HSA-3560796	reactome	NA	Defective PAPSS2 causes SEMD-PA
RAMP_P_000050678	R-HSA-202670	reactome	NA	ERKs are inactivated
RAMP_P_000050679	R-HSA-1566948	reactome	NA	Elastic fibre formation
RAMP_P_000050680	R-HSA-2142688	reactome	NA	Synthesis of 5-eicosatetraenoic acids
RAMP_P_000050681	R-HSA-5205685	reactome	NA	Pink/Parkin Mediated Mitophagy
RAMP_P_000050682	R-HSA-69242	reactome	NA	S Phase
RAMP_P_000050683	R-HSA-380287	reactome	NA	Centrosome maturation
RAMP_P_000050684	R-HSA-3560792	reactome	NA	Defective SLC26A2 causes chondrodysplasias
RAMP_P_000050685	R-HSA-1483226	reactome	NA	Synthesis of PI
RAMP_P_000050686	R-HSA-9603505	reactome	NA	NTRK3 as a dependence receptor
RAMP_P_000050687	R-HSA-3595172	reactome	NA	Defective CHST3 causes SEDCJD
RAMP_P_000050688	R-HSA-5620924	reactome	NA	Intraflagellar transport
RAMP_P_000050689	R-HSA-170660	reactome	NA	Adenylate cyclase activating pathway
RAMP_P_000050690	R-HSA-2559582	reactome	NA	Senescence-Associated Secretory Phenotype (SASP)
RAMP_P_000050691	R-HSA-9013695	reactome	NA	NOTCH4 Intracellular Domain Regulates Transcription
RAMP_P_000050692	R-HSA-5652227	reactome	NA	Fructose biosynthesis
RAMP_P_000050693	R-HSA-8854691	reactome	NA	Interleukin-20 family signaling
RAMP_P_000050694	R-HSA-877300	reactome	NA	Interferon gamma signaling
RAMP_P_000050695	R-HSA-597592	reactome	NA	Post-translational protein modification
RAMP_P_000050696	R-HSA-1660510	reactome	NA	PIPs transport between Golgi and plasma membranes
RAMP_P_000050697	R-HSA-5578999	reactome	NA	Defective GCLC causes Hemolytic anemia due to gamma-glutamylcysteine synthetase deficiency (HAGGSD)
RAMP_P_000050698	R-HSA-1640170	reactome	NA	Cell Cycle
RAMP_P_000050699	R-HSA-432047	reactome	NA	Passive transport by Aquaporins
RAMP_P_000050700	R-HSA-9026403	reactome	NA	Biosynthesis of DPAn-3-derived 13-series resolvins
RAMP_P_000050701	R-HSA-9036092	reactome	NA	Defective AVP does not bind AVPR2 and causes neurohypophyseal diabetes insipidus (NDI)
RAMP_P_000050702	R-HSA-163316	reactome	NA	Mitochondrial transcription termination
RAMP_P_000050703	R-HSA-70614	reactome	NA	Amino acid synthesis and interconversion (transamination)
RAMP_P_000050704	R-HSA-2173782	reactome	NA	Binding and Uptake of Ligands by Scavenger Receptors
RAMP_P_000050705	R-HSA-5610785	reactome	NA	GLI3 is processed to GLI3R by the proteasome
RAMP_P_000050706	R-HSA-3359469	reactome	NA	Defective MTR causes methylmalonic aciduria and homocystinuria type cblG
RAMP_P_000050707	R-HSA-165181	reactome	NA	Inhibition of TSC complex formation by PKB
RAMP_P_000050708	R-HSA-983712	reactome	NA	Ion channel transport
RAMP_P_000050709	R-HSA-9032759	reactome	NA	NTRK2 activates RAC1
RAMP_P_000050710	R-HSA-70263	reactome	NA	Gluconeogenesis
RAMP_P_000050711	R-HSA-5620920	reactome	NA	Cargo trafficking to the periciliary membrane
RAMP_P_000050712	R-HSA-5579029	reactome	NA	Metabolic disorders of biological oxidation enzymes
RAMP_P_000050713	R-HSA-3371571	reactome	NA	HSF1-dependent transactivation
RAMP_P_000050714	R-HSA-2408517	reactome	NA	SeMet incorporation into proteins
RAMP_P_000050715	R-HSA-196780	reactome	NA	Biotin transport and metabolism
RAMP_P_000050716	R-HSA-4411364	reactome	NA	Binding of TCF/LEF:CTNNB1 to target gene promoters
RAMP_P_000050717	R-HSA-8875791	reactome	NA	MET activates STAT3
RAMP_P_000050718	R-HSA-6804116	reactome	NA	TP53 Regulates Transcription of Genes Involved in G1 Cell Cycle Arrest
RAMP_P_000050719	R-HSA-5621575	reactome	NA	CD209 (DC-SIGN) signaling
RAMP_P_000050720	R-HSA-1368108	reactome	NA	BMAL1:CLOCK,NPAS2 activates circadian gene expression
RAMP_P_000050721	R-HSA-190322	reactome	NA	FGFR4 ligand binding and activation
RAMP_P_000050722	R-HSA-427975	reactome	NA	Proton/oligopeptide cotransporters
RAMP_P_000050723	R-HSA-173736	reactome	NA	Alternative complement activation
RAMP_P_000050724	R-HSA-2142696	reactome	NA	Synthesis of Hepoxilins (HX) and Trioxilins (TrX)
RAMP_P_000050725	R-HSA-749476	reactome	NA	RNA Polymerase III Abortive And Retractive Initiation
RAMP_P_000050726	R-HSA-5339716	reactome	NA	Misspliced GSK3beta mutants stabilize beta-catenin
RAMP_P_000050727	R-HSA-1980143	reactome	NA	Signaling by NOTCH1
RAMP_P_000050728	R-HSA-6805567	reactome	NA	Keratinization
RAMP_P_000050729	R-HSA-5696395	reactome	NA	Formation of Incision Complex in GG-NER
RAMP_P_000050730	R-HSA-180292	reactome	NA	GAB1 signalosome
RAMP_P_000050731	R-HSA-5602358	reactome	NA	Diseases associated with the TLR signaling cascade
RAMP_P_000050732	R-HSA-2559580	reactome	NA	Oxidative Stress Induced Senescence
RAMP_P_000050733	R-HSA-5660686	reactome	NA	Variant SLC6A20 contributes towards hyperglycinuria (HG) and iminoglycinuria (IG)
RAMP_P_000050734	R-HSA-77289	reactome	NA	Mitochondrial Fatty Acid Beta-Oxidation
RAMP_P_000050735	R-HSA-8986944	reactome	NA	Transcriptional Regulation by MECP2
RAMP_P_000050736	R-HSA-69186	reactome	NA	Lagging Strand Synthesis
RAMP_P_000050737	R-HSA-77111	reactome	NA	Synthesis of Ketone Bodies
RAMP_P_000050738	R-HSA-3247509	reactome	NA	Chromatin modifying enzymes
RAMP_P_000050739	R-HSA-5632684	reactome	NA	Hedgehog 'on' state
RAMP_P_000050740	R-HSA-9025046	reactome	NA	NTF3 activates NTRK2 (TRKB) signaling
RAMP_P_000050741	R-HSA-2262749	reactome	NA	Cellular response to hypoxia
RAMP_P_000050742	R-HSA-6807878	reactome	NA	COPI-mediated anterograde transport
RAMP_P_000050743	R-HSA-111461	reactome	NA	Cytochrome c-mediated apoptotic response
RAMP_P_000050744	R-HSA-8875656	reactome	NA	MET receptor recycling
RAMP_P_000050745	R-HSA-159740	reactome	NA	Gamma-carboxylation of protein precursors
RAMP_P_000050746	R-HSA-425366	reactome	NA	Transport of bile salts and organic acids, metal ions and amine compounds
RAMP_P_000050747	R-HSA-391906	reactome	NA	Leukotriene receptors
RAMP_P_000050748	R-HSA-70895	reactome	NA	Branched-chain amino acid catabolism
RAMP_P_000050749	R-HSA-8866910	reactome	NA	TFAP2 (AP-2) family regulates transcription of growth factors and their receptors
RAMP_P_000050750	R-HSA-389397	reactome	NA	Orexin and neuropeptides FF and QRFP bind to their respective receptors
RAMP_P_000050751	R-HSA-2466712	reactome	NA	Biosynthesis of A2E, implicated in retinal degradation
RAMP_P_000050752	R-HSA-3229133	reactome	NA	Glycogen storage disease type Ib (SLC37A4)
RAMP_P_000050753	R-HSA-74217	reactome	NA	Purine salvage
RAMP_P_000050754	R-HSA-5693567	reactome	NA	HDR through Homologous Recombination (HRR) or Single Strand Annealing (SSA)
RAMP_P_000050755	R-HSA-8939246	reactome	NA	RUNX1 regulates transcription of genes involved in differentiation of myeloid cells
RAMP_P_000050756	R-HSA-5619095	reactome	NA	Defective SLCO2A1 causes primary, autosomal recessive hypertrophic osteoarthropathy 2 (PHOAR2)
RAMP_P_000050757	R-HSA-350054	reactome	NA	Notch-HLH transcription pathway
RAMP_P_000050758	R-HSA-177243	reactome	NA	Interactions of Rev with host cellular proteins
RAMP_P_000050759	R-HSA-168275	reactome	NA	Entry of Influenza Virion into Host Cell via Endocytosis
RAMP_P_000050760	R-HSA-112382	reactome	NA	Formation of RNA Pol II elongation complex 
RAMP_P_000050761	R-HSA-1538133	reactome	NA	G0 and Early G1
RAMP_P_000050762	R-HSA-6781823	reactome	NA	Formation of TC-NER Pre-Incision Complex
RAMP_P_000050763	R-HSA-9025094	reactome	NA	Biosynthesis of DPAn-3 SPMs
RAMP_P_000050764	R-HSA-110056	reactome	NA	MAPK3 (ERK1) activation
RAMP_P_000050765	R-HSA-2393930	reactome	NA	Phosphate bond hydrolysis by NUDT proteins
RAMP_P_000050766	R-HSA-3274531	reactome	NA	Glycogen storage disease type Ia (G6PC)
RAMP_P_000050767	R-HSA-4086398	reactome	NA	Ca2+ pathway
RAMP_P_000050768	R-HSA-15869	reactome	NA	Metabolism of nucleotides
RAMP_P_000050769	R-HSA-4793953	reactome	NA	Defective B4GALT1 causes B4GALT1-CDG (CDG-2d)
RAMP_P_000050770	R-HSA-202424	reactome	NA	Downstream TCR signaling
RAMP_P_000050771	R-HSA-5579021	reactome	NA	Defective CYP21A2 causes Adrenal hyperplasia 3 (AH3)
RAMP_P_000050772	R-HSA-5687128	reactome	NA	MAPK6/MAPK4 signaling
RAMP_P_000050773	R-HSA-1643713	reactome	NA	Signaling by EGFR in Cancer
RAMP_P_000050774	R-HSA-5250989	reactome	NA	Toxicity of botulinum toxin type G (BoNT/G)
RAMP_P_000050775	R-HSA-5693568	reactome	NA	Resolution of D-loop Structures through Holliday Junction Intermediates
RAMP_P_000050776	R-HSA-9026762	reactome	NA	Biosynthesis of maresin conjugates in tissue regeneration (MCTR)
RAMP_P_000050777	R-HSA-193144	reactome	NA	Estrogen biosynthesis
RAMP_P_000050778	R-HSA-180534	reactome	NA	Vpu mediated degradation of CD4
RAMP_P_000050779	R-HSA-5654228	reactome	NA	Phospholipase C-mediated cascade; FGFR4
RAMP_P_000050780	R-HSA-71403	reactome	NA	Citric acid cycle (TCA cycle)
RAMP_P_000050781	R-HSA-164940	reactome	NA	Nef mediated downregulation of MHC class I complex cell surface expression
RAMP_P_000050782	R-HSA-68952	reactome	NA	DNA replication initiation
RAMP_P_000050783	R-HSA-975578	reactome	NA	Reactions specific to the complex N-glycan synthesis pathway
RAMP_P_000050784	R-HSA-170822	reactome	NA	Regulation of Glucokinase by Glucokinase Regulatory Protein
RAMP_P_000050785	R-HSA-2980767	reactome	NA	Activation of NIMA Kinases NEK9, NEK6, NEK7
RAMP_P_000050786	R-HSA-187577	reactome	NA	SCF(Skp2)-mediated degradation of p27/p21
RAMP_P_000050787	R-HSA-6804754	reactome	NA	Regulation of TP53 Expression
RAMP_P_000050788	R-HSA-1433617	reactome	NA	Regulation of signaling by NODAL
RAMP_P_000050789	R-HSA-198203	reactome	NA	PI3K/AKT activation
RAMP_P_000050790	R-HSA-400253	reactome	NA	Circadian Clock
RAMP_P_000050791	R-HSA-5683678	reactome	NA	Defective ABCA3 causes pulmonary surfactant metabolism dysfunction type 3 (SMDP3)
RAMP_P_000050792	R-HSA-2214320	reactome	NA	Anchoring fibril formation
RAMP_P_000050793	R-HSA-422085	reactome	NA	Synthesis, secretion, and deacylation of Ghrelin
RAMP_P_000050794	R-HSA-9022537	reactome	NA	Loss of MECP2 binding ability to the NCoR/SMRT complex
RAMP_P_000050795	R-HSA-3371599	reactome	NA	Defective HLCS causes multiple carboxylase deficiency
RAMP_P_000050796	R-HSA-168288	reactome	NA	Fusion of the Influenza Virion to the Host Cell Endosome
RAMP_P_000050797	R-HSA-500657	reactome	NA	Presynaptic function of Kainate receptors
RAMP_P_000050798	R-HSA-5607761	reactome	NA	Dectin-1 mediated noncanonical NF-kB signaling
RAMP_P_000050799	R-HSA-194138	reactome	NA	Signaling by VEGF
RAMP_P_000050800	R-HSA-75944	reactome	NA	Transcription from mitochondrial promoters
RAMP_P_000050801	R-HSA-9614657	reactome	NA	FOXO-mediated transcription of cell death genes
RAMP_P_000050802	R-HSA-73884	reactome	NA	Base Excision Repair
RAMP_P_000050803	R-HSA-5673000	reactome	NA	RAF activation
RAMP_P_000050804	R-HSA-6806942	reactome	NA	MET Receptor Activation
RAMP_P_000050805	R-HSA-70171	reactome	NA	Glycolysis
RAMP_P_000050806	R-HSA-8934593	reactome	NA	Regulation of RUNX1 Expression and Activity
RAMP_P_000050807	R-HSA-1362300	reactome	NA	Transcription of E2F targets under negative control by p107 (RBL1) and p130 (RBL2) in complex with HDAC1
RAMP_P_000050808	R-HSA-1236382	reactome	NA	Constitutive Signaling by Ligand-Responsive EGFR Cancer Variants
RAMP_P_000050809	R-HSA-5673001	reactome	NA	RAF/MAP kinase cascade
RAMP_P_000050810	R-HSA-5083633	reactome	NA	Defective POMT1 causes MDDGA1, MDDGB1 and MDDGC1
RAMP_P_000050811	R-HSA-204626	reactome	NA	Hypusine synthesis from eIF5A-lysine
RAMP_P_000050812	R-HSA-2473224	reactome	NA	Antagonism of Activin by Follistatin
RAMP_P_000050813	R-HSA-5579005	reactome	NA	Defective CYP4F22 causes Ichthyosis, congenital, autosomal recessive 5 (ARCI5)
RAMP_P_000050814	R-HSA-429593	reactome	NA	Inositol transporters
RAMP_P_000050815	R-HSA-5362517	reactome	NA	Signaling by Retinoic Acid
RAMP_P_000050816	R-HSA-6811438	reactome	NA	Intra-Golgi traffic
RAMP_P_000050817	R-HSA-6791226	reactome	NA	Major pathway of rRNA processing in the nucleolus and cytosol
RAMP_P_000050818	R-HSA-1650814	reactome	NA	Collagen biosynthesis and modifying enzymes
RAMP_P_000050819	R-HSA-209905	reactome	NA	Catecholamine biosynthesis
RAMP_P_000050820	R-HSA-3878781	reactome	NA	Glycogen storage disease type IV (GBE1)
RAMP_P_000050821	R-HSA-804914	reactome	NA	Transport of fatty acids
RAMP_P_000050822	R-HSA-5579007	reactome	NA	Defective ACY1 causes encephalopathy
RAMP_P_000050823	R-HSA-75955	reactome	NA	RNA Polymerase II Transcription Elongation
RAMP_P_000050824	R-HSA-74182	reactome	NA	Ketone body metabolism
RAMP_P_000050825	R-HSA-3322077	reactome	NA	Glycogen synthesis
RAMP_P_000050826	R-HSA-5358493	reactome	NA	Synthesis of diphthamide-EEF2
RAMP_P_000050827	R-HSA-168138	reactome	NA	Toll Like Receptor 9 (TLR9) Cascade
RAMP_P_000050828	R-HSA-173623	reactome	NA	Classical antibody-mediated complement activation
RAMP_P_000050829	R-HSA-3595174	reactome	NA	Defective CHST14 causes EDS, musculocontractural type
RAMP_P_000050830	R-HSA-3700989	reactome	NA	Transcriptional Regulation by TP53
RAMP_P_000050831	R-HSA-3304349	reactome	NA	Loss of Function of SMAD2/3 in Cancer
RAMP_P_000050832	R-HSA-5619037	reactome	NA	Defective SLC35A1 causes congenital disorder of glycosylation 2F (CDG2F)
RAMP_P_000050833	R-HSA-8981607	reactome	NA	Intracellular oxygen transport
RAMP_P_000050834	R-HSA-111885	reactome	NA	Opioid Signalling
RAMP_P_000050835	R-HSA-445989	reactome	NA	TAK1 activates NFkB by phosphorylation and activation of IKKs complex
RAMP_P_000050836	R-HSA-453274	reactome	NA	Mitotic G2-G2/M phases
RAMP_P_000050837	R-HSA-9026527	reactome	NA	Activated NTRK2 signals through PLCG1
RAMP_P_000050838	R-HSA-5668914	reactome	NA	Diseases of metabolism
RAMP_P_000050839	R-HSA-71387	reactome	NA	Metabolism of carbohydrates
RAMP_P_000050840	R-HSA-69278	reactome	NA	Cell Cycle, Mitotic
RAMP_P_000050841	R-HSA-936440	reactome	NA	Negative regulators of DDX58/IFIH1 signaling
RAMP_P_000050842	R-HSA-202733	reactome	NA	Cell surface interactions at the vascular wall
RAMP_P_000050843	R-HSA-6807505	reactome	NA	RNA polymerase II transcribes snRNA genes
RAMP_P_000050844	R-HSA-2672351	reactome	NA	Stimuli-sensing channels
RAMP_P_000050845	R-HSA-75892	reactome	NA	Platelet Adhesion to exposed collagen
RAMP_P_000050846	R-HSA-1679131	reactome	NA	Trafficking and processing of endosomal TLR
RAMP_P_000050847	R-HSA-3311021	reactome	NA	SMAD4 MH2 Domain Mutants in Cancer
RAMP_P_000050848	R-HSA-180897	reactome	NA	Vpr-mediated induction of apoptosis by mitochondrial outer membrane permeabilization
RAMP_P_000050849	R-HSA-1222541	reactome	NA	Cell redox homeostasis
RAMP_P_000050850	R-HSA-6809583	reactome	NA	Retinoid metabolism disease events
RAMP_P_000050851	R-HSA-174113	reactome	NA	SCF-beta-TrCP mediated degradation of Emi1
RAMP_P_000050852	R-HSA-3214841	reactome	NA	PKMTs methylate histone lysines
RAMP_P_000050853	R-HSA-168256	reactome	NA	Immune System
RAMP_P_000050854	R-HSA-5221030	reactome	NA	TET1,2,3 and TDG demethylate DNA
RAMP_P_000050855	R-HSA-182971	reactome	NA	EGFR downregulation
RAMP_P_000050856	R-HSA-70688	reactome	NA	Proline catabolism
RAMP_P_000050857	R-HSA-2173788	reactome	NA	Downregulation of TGF-beta receptor signaling
RAMP_P_000050858	R-HSA-8848021	reactome	NA	Signaling by PTK6
RAMP_P_000050859	R-HSA-4085011	reactome	NA	Defective GNE causes sialuria, Nonaka myopathy and inclusion body myopathy 2
RAMP_P_000050860	R-HSA-2022923	reactome	NA	Dermatan sulfate biosynthesis
RAMP_P_000050861	R-HSA-456926	reactome	NA	Thrombin signalling through proteinase activated receptors (PARs)
RAMP_P_000050862	R-HSA-3371598	reactome	NA	Defective BTD causes biotidinase deficiency
RAMP_P_000050863	R-HSA-5674135	reactome	NA	MAP2K and MAPK activation
RAMP_P_000050864	R-HSA-6803544	reactome	NA	Ion influx/efflux at host-pathogen interface
RAMP_P_000050865	R-HSA-6802952	reactome	NA	Signaling by BRAF and RAF fusions
RAMP_P_000050866	R-HSA-933541	reactome	NA	TRAF6 mediated IRF7 activation
RAMP_P_000050867	R-HSA-159763	reactome	NA	Transport of gamma-carboxylated protein precursors from the endoplasmic reticulum to the Golgi apparatus
RAMP_P_000050868	R-HSA-168277	reactome	NA	Influenza Virus Induced Apoptosis
RAMP_P_000050869	R-HSA-429958	reactome	NA	mRNA decay by 3' to 5' exoribonuclease
RAMP_P_000050870	R-HSA-2132295	reactome	NA	MHC class II antigen presentation
RAMP_P_000050871	R-HSA-9617828	reactome	NA	FOXO-mediated transcription of cell cycle genes
RAMP_P_000050872	R-HSA-9010642	reactome	NA	ROBO receptors bind AKAP5
RAMP_P_000050873	R-HSA-1170546	reactome	NA	Prolactin receptor signaling
RAMP_P_000050874	R-HSA-3296469	reactome	NA	Defects in cobalamin (B12) metabolism
RAMP_P_000050875	R-HSA-8953897	reactome	NA	Cellular responses to external stimuli
RAMP_P_000050876	R-HSA-2122948	reactome	NA	Activated NOTCH1 Transmits Signal to the Nucleus
RAMP_P_000050877	R-HSA-400206	reactome	NA	Regulation of lipid metabolism by Peroxisome proliferator-activated receptor alpha (PPARalpha)
RAMP_P_000050878	R-HSA-2173795	reactome	NA	Downregulation of SMAD2/3:SMAD4 transcriptional activity
RAMP_P_000050879	R-HSA-447043	reactome	NA	Neurofascin interactions
RAMP_P_000050880	R-HSA-1482788	reactome	NA	Acyl chain remodelling of PC
RAMP_P_000050881	R-HSA-8951430	reactome	NA	RUNX3 regulates WNT signaling
RAMP_P_000050882	R-HSA-9027604	reactome	NA	Biosynthesis of electrophilic ω-3 PUFA oxo-derivatives
RAMP_P_000050883	R-HSA-8863678	reactome	NA	Neurodegenerative Diseases
RAMP_P_000050884	R-HSA-622327	reactome	NA	Postsynaptic nicotinic acetylcholine receptors
RAMP_P_000050885	R-HSA-1834941	reactome	NA	STING mediated induction of host immune responses
RAMP_P_000050886	R-HSA-373753	reactome	NA	Nephrin family interactions
RAMP_P_000050887	R-HSA-5545619	reactome	NA	XAV939 inhibits tankyrase, stabilizing AXIN
RAMP_P_000050888	R-HSA-6806834	reactome	NA	Signaling by MET
RAMP_P_000050889	R-HSA-6803204	reactome	NA	TP53 Regulates Transcription of Genes Involved in Cytochrome C Release
RAMP_P_000050890	R-HSA-1989781	reactome	NA	PPARA activates gene expression
RAMP_P_000050891	R-HSA-167200	reactome	NA	Formation of HIV-1 elongation complex containing HIV-1 Tat
RAMP_P_000050892	R-HSA-163200	reactome	NA	Respiratory electron transport, ATP synthesis by chemiosmotic coupling, and heat production by uncoupling proteins.
RAMP_P_000050893	R-HSA-9006936	reactome	NA	Signaling by TGF-beta family members
RAMP_P_000050894	R-HSA-112040	reactome	NA	G-protein mediated events
RAMP_P_000050895	R-HSA-426496	reactome	NA	Post-transcriptional silencing by small RNAs
RAMP_P_000050896	R-HSA-8878171	reactome	NA	Transcriptional regulation by RUNX1
RAMP_P_000050897	R-HSA-5576894	reactome	NA	Phase 1 - inactivation of fast Na+ channels
RAMP_P_000050898	R-HSA-174417	reactome	NA	Telomere C-strand (Lagging Strand) Synthesis
RAMP_P_000050899	R-HSA-77042	reactome	NA	Formation of editosomes by ADAR proteins
RAMP_P_000050900	R-HSA-71240	reactome	NA	Tryptophan catabolism
RAMP_P_000050901	R-HSA-448424	reactome	NA	Interleukin-17 signaling
RAMP_P_000050902	R-HSA-170834	reactome	NA	Signaling by TGF-beta Receptor Complex
RAMP_P_000050903	R-HSA-774815	reactome	NA	Nucleosome assembly
RAMP_P_000050904	R-HSA-376176	reactome	NA	Signaling by ROBO receptors
RAMP_P_000050905	R-HSA-5694530	reactome	NA	Cargo concentration in the ER
RAMP_P_000050906	R-HSA-392154	reactome	NA	Nitric oxide stimulates guanylate cyclase
RAMP_P_000050907	R-HSA-193670	reactome	NA	p75NTR negatively regulates cell cycle via SC1
RAMP_P_000050908	R-HSA-1855170	reactome	NA	IPs transport between nucleus and cytosol
RAMP_P_000050909	R-HSA-9012852	reactome	NA	Signaling by NOTCH3
RAMP_P_000050910	R-HSA-879415	reactome	NA	Advanced glycosylation endproduct receptor signaling
RAMP_P_000050911	R-HSA-1234176	reactome	NA	Oxygen-dependent proline hydroxylation of Hypoxia-inducible Factor Alpha
RAMP_P_000050912	R-HSA-5173214	reactome	NA	O-glycosylation of TSR domain-containing proteins
RAMP_P_000050913	R-HSA-5083635	reactome	NA	Defective B3GALTL causes Peters-plus syndrome (PpS)
RAMP_P_000050914	R-HSA-1299308	reactome	NA	Tandem of pore domain in a weak inwardly rectifying K+ channels (TWIK)
RAMP_P_000050915	R-HSA-5579017	reactome	NA	Defective CYP11B1 causes Adrenal hyperplasia 4 (AH4)
RAMP_P_000050916	R-HSA-388841	reactome	NA	Costimulation by the CD28 family
RAMP_P_000050917	R-HSA-8941237	reactome	NA	Invadopodia formation
RAMP_P_000050918	R-HSA-983168	reactome	NA	Antigen processing: Ubiquitination & Proteasome degradation
RAMP_P_000050919	R-HSA-168273	reactome	NA	Influenza Viral RNA Transcription and Replication
RAMP_P_000050920	R-HSA-167172	reactome	NA	Transcription of the HIV genome
RAMP_P_000050921	R-HSA-171286	reactome	NA	Synthesis and processing of ENV and VPU
RAMP_P_000050922	R-HSA-418555	reactome	NA	G alpha (s) signalling events
RAMP_P_000050923	R-HSA-162710	reactome	NA	Synthesis of glycosylphosphatidylinositol (GPI)
RAMP_P_000050924	R-HSA-1614558	reactome	NA	Degradation of cysteine and homocysteine
RAMP_P_000050925	R-HSA-399955	reactome	NA	SEMA3A-Plexin repulsion signaling by inhibiting Integrin adhesion
RAMP_P_000050926	R-HSA-8941413	reactome	NA	Events associated with phagocytolytic activity of PMN cells
RAMP_P_000050927	R-HSA-5250982	reactome	NA	Toxicity of tetanus toxin (TeNT)
RAMP_P_000050928	R-HSA-420029	reactome	NA	Tight junction interactions
RAMP_P_000050929	R-HSA-452723	reactome	NA	Transcriptional regulation of pluripotent stem cells
RAMP_P_000050930	R-HSA-5601884	reactome	NA	PIWI-interacting RNA (piRNA) biogenesis
RAMP_P_000050931	R-HSA-1912399	reactome	NA	Pre-NOTCH Processing in the Endoplasmic Reticulum
RAMP_P_000050932	R-HSA-164952	reactome	NA	The role of Nef in HIV-1 replication and disease pathogenesis
RAMP_P_000050933	R-HSA-5579012	reactome	NA	Defective MAOA causes Brunner syndrome (BRUNS)
RAMP_P_000050934	R-HSA-5578775	reactome	NA	Ion homeostasis
RAMP_P_000050935	R-HSA-74713	reactome	NA	IRS activation
RAMP_P_000050936	R-HSA-8862803	reactome	NA	Deregulated CDK5 triggers multiple neurodegenerative pathways in Alzheimer's disease models
RAMP_P_000050937	R-HSA-5358749	reactome	NA	S37 mutants of beta-catenin aren't phosphorylated
RAMP_P_000050938	R-HSA-2408552	reactome	NA	Methylation of MeSeH for excretion
RAMP_P_000050939	R-HSA-977225	reactome	NA	Amyloid fiber formation
RAMP_P_000050940	R-HSA-2046106	reactome	NA	alpha-linolenic acid (ALA) metabolism
RAMP_P_000050941	R-HSA-5654699	reactome	NA	SHC-mediated cascade:FGFR2
RAMP_P_000050942	R-HSA-382551	reactome	NA	Transport of small molecules
RAMP_P_000050943	R-HSA-2395516	reactome	NA	Electron transport from NADPH to Ferredoxin
RAMP_P_000050944	R-HSA-4793954	reactome	NA	Defective MOGS causes MOGS-CDG (CDG-2b)
RAMP_P_000050945	R-HSA-6803207	reactome	NA	TP53 Regulates Transcription of Caspase Activators and Caspases
RAMP_P_000050946	R-HSA-5638302	reactome	NA	Signaling by Overexpressed Wild-Type EGFR in Cancer
RAMP_P_000050947	R-HSA-5368287	reactome	NA	Mitochondrial translation
RAMP_P_000050948	R-HSA-210500	reactome	NA	Glutamate Neurotransmitter Release Cycle
RAMP_P_000050949	R-HSA-433137	reactome	NA	Sodium-coupled sulphate, di- and tri-carboxylate transporters
RAMP_P_000050950	R-HSA-418990	reactome	NA	Adherens junctions interactions
RAMP_P_000050951	R-HSA-480985	reactome	NA	Synthesis of dolichyl-phosphate-glucose
RAMP_P_000050952	R-HSA-399997	reactome	NA	Acetylcholine regulates insulin secretion
RAMP_P_000050953	R-HSA-1614635	reactome	NA	Sulfur amino acid metabolism
RAMP_P_000050954	R-HSA-451326	reactome	NA	Activation of kainate receptors upon glutamate binding
RAMP_P_000050955	R-HSA-2029480	reactome	NA	Fcgamma receptor (FCGR) dependent phagocytosis
RAMP_P_000050956	R-HSA-202403	reactome	NA	TCR signaling
RAMP_P_000050957	R-HSA-109704	reactome	NA	PI3K Cascade
RAMP_P_000050958	R-HSA-5358606	reactome	NA	Mismatch repair (MMR) directed by MSH2:MSH3 (MutSbeta)
RAMP_P_000050959	R-HSA-204174	reactome	NA	Regulation of pyruvate dehydrogenase (PDH) complex
RAMP_P_000050960	R-HSA-2179392	reactome	NA	EGFR Transactivation by Gastrin
RAMP_P_000050961	R-HSA-176407	reactome	NA	Conversion from APC/C:Cdc20 to APC/C:Cdh1 in late anaphase
RAMP_P_000050962	R-HSA-189445	reactome	NA	Metabolism of porphyrins
RAMP_P_000050963	R-HSA-4570571	reactome	NA	Defective RFT1 causes RFT1-CDG (CDG-1n)
RAMP_P_000050964	R-HSA-2855086	reactome	NA	Ficolins bind to repetitive carbohydrate structures on the target cell surface
RAMP_P_000050965	R-HSA-2206302	reactome	NA	MPS I - Hurler syndrome
RAMP_P_000050966	R-HSA-5654741	reactome	NA	Signaling by FGFR3
RAMP_P_000050967	R-HSA-5653656	reactome	NA	Vesicle-mediated transport
RAMP_P_000050968	R-HSA-446199	reactome	NA	Synthesis of Dolichyl-phosphate
RAMP_P_000050969	R-HSA-5619104	reactome	NA	Defective SLC12A1 causes Bartter syndrome 1 (BS1)
RAMP_P_000050970	R-HSA-997269	reactome	NA	Inhibition of adenylate cyclase pathway
RAMP_P_000050971	R-HSA-8941333	reactome	NA	RUNX2 regulates genes involved in differentiation of myeloid cells
RAMP_P_000050972	R-HSA-1474290	reactome	NA	Collagen formation
RAMP_P_000050973	R-HSA-5654708	reactome	NA	Downstream signaling of activated FGFR3
RAMP_P_000050974	R-HSA-1482798	reactome	NA	Acyl chain remodeling of CL
RAMP_P_000050975	R-HSA-166187	reactome	NA	Mitochondrial Uncoupling Proteins
RAMP_P_000050976	R-HSA-162909	reactome	NA	Host Interactions of HIV factors
RAMP_P_000050977	R-HSA-381038	reactome	NA	XBP1(S) activates chaperone genes
RAMP_P_000050978	R-HSA-9013700	reactome	NA	NOTCH4 Activation and Transmission of Signal to the Nucleus
RAMP_P_000050979	R-HSA-1169410	reactome	NA	Antiviral mechanism by IFN-stimulated genes
RAMP_P_000050980	R-HSA-177135	reactome	NA	Conjugation of benzoate with glycine
RAMP_P_000050981	R-HSA-1369062	reactome	NA	ABC transporters in lipid homeostasis
RAMP_P_000050982	R-HSA-174403	reactome	NA	Glutathione synthesis and recycling
RAMP_P_000050983	R-HSA-2206291	reactome	NA	MPS IIIC - Sanfilippo syndrome C
RAMP_P_000050984	R-HSA-5602566	reactome	NA	TICAM1 deficiency - HSE
RAMP_P_000050985	R-HSA-168276	reactome	NA	NS1 Mediated Effects on Host Pathways
RAMP_P_000050986	R-HSA-5663205	reactome	NA	Infectious disease
RAMP_P_000050987	R-HSA-446193	reactome	NA	Biosynthesis of the N-glycan precursor (dolichol lipid-linked oligosaccharide, LLO) and transfer to a nascent protein
RAMP_P_000050988	R-HSA-157579	reactome	NA	Telomere Maintenance
RAMP_P_000050989	R-HSA-5617472	reactome	NA	Activation of anterior HOX genes in hindbrain development during early embryogenesis
RAMP_P_000050990	R-HSA-2454202	reactome	NA	Fc epsilon receptor (FCERI) signaling
RAMP_P_000050991	R-HSA-2586552	reactome	NA	Signaling by Leptin
RAMP_P_000050992	R-HSA-5662702	reactome	NA	Melanin biosynthesis
RAMP_P_000050993	R-HSA-4641265	reactome	NA	Repression of WNT target genes
RAMP_P_000050994	R-HSA-1638074	reactome	NA	Keratan sulfate/keratin metabolism
RAMP_P_000050995	R-HSA-3214847	reactome	NA	HATs acetylate histones
RAMP_P_000050996	R-HSA-180910	reactome	NA	Vpr-mediated nuclear import of PICs
RAMP_P_000050997	R-HSA-196025	reactome	NA	Formation of annular gap junctions
RAMP_P_000050998	R-HSA-156580	reactome	NA	Phase II - Conjugation of compounds
RAMP_P_000050999	R-HSA-4641262	reactome	NA	Disassembly of the destruction complex and recruitment of AXIN to the membrane
RAMP_P_000051000	R-HSA-198753	reactome	NA	ERK/MAPK targets
RAMP_P_000051001	R-HSA-6811558	reactome	NA	PI5P, PP2A and IER3 Regulate PI3K/AKT Signaling
RAMP_P_000051002	R-HSA-3359478	reactome	NA	Defective MUT causes methylmalonic aciduria mut type
RAMP_P_000051003	R-HSA-180024	reactome	NA	DARPP-32 events
RAMP_P_000051004	R-HSA-1606341	reactome	NA	IRF3 mediated activation of type 1 IFN
RAMP_P_000051005	R-HSA-73772	reactome	NA	RNA Polymerase I Promoter Escape
RAMP_P_000051006	R-HSA-1566977	reactome	NA	Fibronectin matrix formation
RAMP_P_000051007	R-HSA-499943	reactome	NA	Interconversion of nucleotide di- and triphosphates
RAMP_P_000051008	R-HSA-68827	reactome	NA	CDT1 association with the CDC6:ORC:origin complex
RAMP_P_000051009	R-HSA-114294	reactome	NA	Activation, translocation and oligomerization of BAX
RAMP_P_000051010	R-HSA-9014843	reactome	NA	Interleukin-33 signaling
RAMP_P_000051011	R-HSA-8948751	reactome	NA	Regulation of PTEN stability and activity
RAMP_P_000051012	R-HSA-72689	reactome	NA	Formation of a pool of free 40S subunits
RAMP_P_000051013	R-HSA-2022857	reactome	NA	Keratan sulfate degradation
RAMP_P_000051014	R-HSA-4687000	reactome	NA	Defective MPDU1 causes MPDU1-CDG (CDG-1f)
RAMP_P_000051015	R-HSA-936964	reactome	NA	Activation of IRF3/IRF7 mediated by TBK1/IKK epsilon
RAMP_P_000051016	R-HSA-174143	reactome	NA	APC/C-mediated degradation of cell cycle proteins
RAMP_P_000051017	R-HSA-912446	reactome	NA	Meiotic recombination
RAMP_P_000051018	R-HSA-193807	reactome	NA	Synthesis of bile acids and bile salts via 27-hydroxycholesterol
RAMP_P_000051019	R-HSA-5619102	reactome	NA	SLC transporter disorders
RAMP_P_000051020	R-HSA-8963676	reactome	NA	Intestinal absorption
RAMP_P_000051021	R-HSA-5619087	reactome	NA	Defective SLC12A3 causes Gitelman syndrome (GS)
RAMP_P_000051022	R-HSA-9026286	reactome	NA	Biosynthesis of DPAn-3-derived protectins and resolvins
RAMP_P_000051023	R-HSA-918233	reactome	NA	TRAF3-dependent IRF activation pathway
RAMP_P_000051024	R-HSA-3560783	reactome	NA	Defective B4GALT7 causes EDS, progeroid type
RAMP_P_000051025	R-HSA-8949275	reactome	NA	RUNX3 Regulates Immune Response and Cell Migration
RAMP_P_000051026	R-HSA-156902	reactome	NA	Peptide chain elongation
RAMP_P_000051027	R-HSA-72312	reactome	NA	rRNA processing
RAMP_P_000051028	R-HSA-5660724	reactome	NA	Defective SLC6A3 causes Parkinsonism-dystonia infantile (PKDYS)
RAMP_P_000051029	R-HSA-5619072	reactome	NA	Defective SLC35A2 causes congenital disorder of glycosylation 2M (CDG2M)
RAMP_P_000051030	R-HSA-3238698	reactome	NA	WNT ligand biogenesis and trafficking
RAMP_P_000051031	R-HSA-210455	reactome	NA	Astrocytic Glutamate-Glutamine Uptake And Metabolism
RAMP_P_000051032	R-HSA-3134973	reactome	NA	LRR FLII-interacting protein 1 (LRRFIP1) activates type I IFN production
RAMP_P_000051033	R-HSA-5357786	reactome	NA	TNFR1-induced proapoptotic signaling
RAMP_P_000051034	R-HSA-3928665	reactome	NA	EPH-ephrin mediated repulsion of cells
RAMP_P_000051035	R-HSA-6811440	reactome	NA	Retrograde transport at the Trans-Golgi-Network
RAMP_P_000051036	R-HSA-3656253	reactome	NA	Defective EXT1 causes exostoses 1, TRPS2 and CHDS
RAMP_P_000051037	R-HSA-418359	reactome	NA	Reduction of cytosolic Ca++ levels
RAMP_P_000051038	R-HSA-198933	reactome	NA	Immunoregulatory interactions between a Lymphoid and a non-Lymphoid cell
RAMP_P_000051039	R-HSA-3359475	reactome	NA	Defective MMAA causes methylmalonic aciduria type cblA
RAMP_P_000051040	R-HSA-75108	reactome	NA	Activation, myristolyation of BID and translocation to mitochondria
RAMP_P_000051041	R-HSA-9010553	reactome	NA	Regulation of expression of SLITs and ROBOs
RAMP_P_000051042	R-HSA-1296059	reactome	NA	G protein gated Potassium channels
RAMP_P_000051043	R-HSA-163754	reactome	NA	Insulin effects increased synthesis of Xylulose-5-Phosphate
RAMP_P_000051044	R-HSA-168888	reactome	NA	Inhibition of IFN-beta
RAMP_P_000051045	R-HSA-163615	reactome	NA	PKA activation
RAMP_P_000051046	R-HSA-1169408	reactome	NA	ISG15 antiviral mechanism
RAMP_P_000051047	R-HSA-5358508	reactome	NA	Mismatch Repair
RAMP_P_000051048	R-HSA-212676	reactome	NA	Dopamine Neurotransmitter Release Cycle
RAMP_P_000051049	R-HSA-1614603	reactome	NA	Cysteine formation from homocysteine
RAMP_P_000051050	R-HSA-373752	reactome	NA	Netrin-1 signaling
RAMP_P_000051051	R-HSA-1222538	reactome	NA	Tolerance by Mtb to nitric oxide produced by macrophages
RAMP_P_000051052	R-HSA-8869496	reactome	NA	TFAP2A acts as a transcriptional repressor during retinoic acid induced cell differentiation
RAMP_P_000051053	R-HSA-202040	reactome	NA	G-protein activation
RAMP_P_000051054	R-HSA-373756	reactome	NA	SDK interactions
RAMP_P_000051055	R-HSA-69109	reactome	NA	Leading Strand Synthesis
RAMP_P_000051056	R-HSA-6803205	reactome	NA	TP53 regulates transcription of several additional cell death genes whose specific roles in p53-dependent apoptosis remain uncertain
RAMP_P_000051057	R-HSA-1247673	reactome	NA	Erythrocytes take up oxygen and release carbon dioxide
RAMP_P_000051058	R-HSA-727802	reactome	NA	Transport of nucleotide sugars
RAMP_P_000051059	R-HSA-70268	reactome	NA	Pyruvate metabolism
RAMP_P_000051060	R-HSA-392170	reactome	NA	ADP signalling through P2Y purinoceptor 12
RAMP_P_000051061	R-HSA-380320	reactome	NA	Recruitment of NuMA to mitotic centrosomes
RAMP_P_000051062	R-HSA-2028269	reactome	NA	Signaling by Hippo
RAMP_P_000051063	R-HSA-5619089	reactome	NA	Defective SLC6A5 causes hyperekplexia 3 (HKPX3)
RAMP_P_000051064	R-HSA-157858	reactome	NA	Gap junction trafficking and regulation
RAMP_P_000051065	R-HSA-4549349	reactome	NA	Defective ALG2 causes ALG2-CDG (CDG-1i)
RAMP_P_000051066	R-HSA-389542	reactome	NA	NADPH regeneration
RAMP_P_000051067	R-HSA-5663020	reactome	NA	Defective SLC35A1 causes congenital disorder of glycosylation 2F (CDG2F)
RAMP_P_000051068	R-HSA-1660661	reactome	NA	Sphingolipid de novo biosynthesis
RAMP_P_000051069	R-HSA-1660502	reactome	NA	PIPs transport between early and late endosome membranes
RAMP_P_000051070	R-HSA-936837	reactome	NA	Ion transport by P-type ATPases
RAMP_P_000051071	R-HSA-389599	reactome	NA	Alpha-oxidation of phytanate
RAMP_P_000051072	R-HSA-418889	reactome	NA	Caspase activation via Dependence Receptors in the absence of ligand
RAMP_P_000051073	R-HSA-75157	reactome	NA	FasL/ CD95L signaling
RAMP_P_000051074	R-HSA-418890	reactome	NA	Role of second messengers in netrin-1 signaling
RAMP_P_000051075	R-HSA-418592	reactome	NA	ADP signalling through P2Y purinoceptor 1
RAMP_P_000051076	R-HSA-5357769	reactome	NA	Caspase activation via extrinsic apoptotic signalling pathway
RAMP_P_000051077	R-HSA-2219530	reactome	NA	Constitutive Signaling by Aberrant PI3K in Cancer
RAMP_P_000051078	R-HSA-8878166	reactome	NA	Transcriptional regulation by RUNX2
RAMP_P_000051079	R-HSA-1482801	reactome	NA	Acyl chain remodelling of PS
RAMP_P_000051080	R-HSA-199991	reactome	NA	Membrane Trafficking
RAMP_P_000051081	R-HSA-1222387	reactome	NA	Tolerance of reactive oxygen produced by macrophages
RAMP_P_000051082	R-HSA-68881	reactome	NA	Mitotic Metaphase/Anaphase Transition
RAMP_P_000051083	R-HSA-500792	reactome	NA	GPCR ligand binding
RAMP_P_000051084	R-HSA-1445148	reactome	NA	Translocation of SLC2A4 (GLUT4) to the plasma membrane
RAMP_P_000051085	R-HSA-2995410	reactome	NA	Nuclear Envelope Reassembly
RAMP_P_000051086	R-HSA-9026766	reactome	NA	Biosynthesis of protectin and resolvin conjugates in tissue regeneration (PCTR and RCTR)
RAMP_P_000051087	R-HSA-5693607	reactome	NA	Processing of DNA double-strand break ends
RAMP_P_000051088	R-HSA-72203	reactome	NA	Processing of Capped Intron-Containing Pre-mRNA
RAMP_P_000051089	R-HSA-5250924	reactome	NA	B-WICH complex positively regulates rRNA expression
RAMP_P_000051090	R-HSA-5250971	reactome	NA	Toxicity of botulinum toxin type C (BoNT/C)
RAMP_P_000051091	R-HSA-3215018	reactome	NA	Processing and activation of SUMO
RAMP_P_000051092	R-HSA-174084	reactome	NA	Autodegradation of Cdh1 by Cdh1:APC/C
RAMP_P_000051093	R-HSA-1630316	reactome	NA	Glycosaminoglycan metabolism
RAMP_P_000051094	R-HSA-4839748	reactome	NA	AMER1 mutants destabilize the destruction complex
RAMP_P_000051095	R-HSA-177929	reactome	NA	Signaling by EGFR
RAMP_P_000051096	R-HSA-389977	reactome	NA	Post-chaperonin tubulin folding pathway
RAMP_P_000051097	R-HSA-190372	reactome	NA	FGFR3c ligand binding and activation
RAMP_P_000051098	R-HSA-166663	reactome	NA	Initial triggering of complement
RAMP_P_000051099	R-HSA-162599	reactome	NA	Late Phase of HIV Life Cycle
RAMP_P_000051100	R-HSA-5651801	reactome	NA	PCNA-Dependent Long Patch Base Excision Repair
RAMP_P_000051101	R-HSA-397014	reactome	NA	Muscle contraction
RAMP_P_000051102	R-HSA-173107	reactome	NA	Binding and entry of HIV virion
RAMP_P_000051103	R-HSA-2644606	reactome	NA	Constitutive Signaling by NOTCH1 PEST Domain Mutants
RAMP_P_000051104	R-HSA-5660862	reactome	NA	Defective SLC7A7 causes lysinuric protein intolerance (LPI)
RAMP_P_000051105	R-HSA-8849175	reactome	NA	Threonine catabolism
RAMP_P_000051106	R-HSA-5619094	reactome	NA	Variant SLC6A14 may confer susceptibility towards obesity
RAMP_P_000051107	R-HSA-937042	reactome	NA	IRAK2 mediated activation of TAK1 complex
RAMP_P_000051108	R-HSA-73863	reactome	NA	RNA Polymerase I Transcription Termination
RAMP_P_000051109	R-HSA-1234158	reactome	NA	Regulation of gene expression by Hypoxia-inducible Factor
RAMP_P_000051110	R-HSA-5083632	reactome	NA	Defective C1GALT1C1 causes Tn polyagglutination syndrome (TNPS)
RAMP_P_000051111	R-HSA-111996	reactome	NA	Ca-dependent events
RAMP_P_000051112	R-HSA-5683826	reactome	NA	Surfactant metabolism
RAMP_P_000051113	R-HSA-451307	reactome	NA	Activation of Na-permeable kainate receptors
RAMP_P_000051114	R-HSA-5655799	reactome	NA	Defective SLC40A1 causes hemochromatosis 4 (HFE4) (duodenum)
RAMP_P_000051115	R-HSA-4755579	reactome	NA	Defective SRD5A3 causes SRD5A3-CDG (CDG-1q) and KHRZ
RAMP_P_000051116	R-HSA-1971475	reactome	NA	A tetrasaccharide linker sequence is required for GAG synthesis
RAMP_P_000051117	R-HSA-112310	reactome	NA	Neurotransmitter release cycle
RAMP_P_000051118	R-HSA-1169091	reactome	NA	Activation of NF-kappaB in B cells
RAMP_P_000051119	R-HSA-390522	reactome	NA	Striated Muscle Contraction
RAMP_P_000051120	R-HSA-5637815	reactome	NA	Signaling by Ligand-Responsive EGFR Variants in Cancer
RAMP_P_000051121	R-HSA-392451	reactome	NA	G beta:gamma signalling through PI3Kgamma
RAMP_P_000051122	R-HSA-157118	reactome	NA	Signaling by NOTCH
RAMP_P_000051123	R-HSA-5578768	reactome	NA	Physiological factors
RAMP_P_000051124	R-HSA-1368082	reactome	NA	RORA activates gene expression
RAMP_P_000051125	R-HSA-5654712	reactome	NA	FRS-mediated FGFR4 signaling
RAMP_P_000051126	R-HSA-73927	reactome	NA	Depurination
RAMP_P_000051127	R-HSA-2892245	reactome	NA	POU5F1 (OCT4), SOX2, NANOG repress genes related to differentiation
RAMP_P_000051128	R-HSA-1912422	reactome	NA	Pre-NOTCH Expression and Processing
RAMP_P_000051129	R-HSA-3359471	reactome	NA	Defective MMAB causes methylmalonic aciduria type cblB
RAMP_P_000051130	R-HSA-427652	reactome	NA	Sodium-coupled phosphate cotransporters
RAMP_P_000051131	R-HSA-201451	reactome	NA	Signaling by BMP
RAMP_P_000051132	R-HSA-8983711	reactome	NA	OAS antiviral response
RAMP_P_000051133	R-HSA-200425	reactome	NA	Import of palmitoyl-CoA into the mitochondrial matrix
RAMP_P_000051134	R-HSA-6807062	reactome	NA	Cholesterol biosynthesis via lathosterol
RAMP_P_000051135	R-HSA-76071	reactome	NA	RNA Polymerase III Transcription Initiation From Type 3 Promoter
RAMP_P_000051136	R-HSA-5619036	reactome	NA	Defective SLC24A5 causes oculocutaneous albinism 6 (OCA6)
RAMP_P_000051137	R-HSA-77387	reactome	NA	Insulin receptor recycling
RAMP_P_000051138	R-HSA-2514853	reactome	NA	Condensation of Prometaphase Chromosomes
RAMP_P_000051139	R-HSA-390648	reactome	NA	Muscarinic acetylcholine receptors
RAMP_P_000051140	R-HSA-69166	reactome	NA	Removal of the Flap Intermediate
RAMP_P_000051141	R-HSA-211976	reactome	NA	Endogenous sterols
RAMP_P_000051142	R-HSA-5083627	reactome	NA	Defective LARGE causes MDDGA6 and MDDGB6
RAMP_P_000051143	R-HSA-1296346	reactome	NA	Tandem pore domain potassium channels
RAMP_P_000051144	R-HSA-69656	reactome	NA	Cyclin A:Cdk2-associated events at S phase entry
RAMP_P_000051145	R-HSA-8955332	reactome	NA	Carboxyterminal post-translational modifications of tubulin
RAMP_P_000051146	R-HSA-193648	reactome	NA	NRAGE signals death through JNK
RAMP_P_000051147	R-HSA-5609975	reactome	NA	Diseases associated with glycosylation precursor biosynthesis
RAMP_P_000051148	R-HSA-5579024	reactome	NA	Defective MAT1A causes Methionine adenosyltransferase deficiency (MATD)
RAMP_P_000051149	R-HSA-5619054	reactome	NA	Defective SLC4A4 causes renal tubular acidosis, proximal, with ocular abnormalities and mental retardation (pRTA-OA)
RAMP_P_000051150	R-HSA-8857538	reactome	NA	PTK6 promotes HIF1A stabilization
RAMP_P_000051151	R-HSA-109703	reactome	NA	PKB-mediated events
RAMP_P_000051152	R-HSA-389357	reactome	NA	CD28 dependent PI3K/Akt signaling
RAMP_P_000051153	R-HSA-70370	reactome	NA	Galactose catabolism
RAMP_P_000051154	R-HSA-2892247	reactome	NA	POU5F1 (OCT4), SOX2, NANOG activate genes related to proliferation
RAMP_P_000051155	R-HSA-1810476	reactome	NA	RIP-mediated NFkB activation via ZBP1
RAMP_P_000051156	R-HSA-1296025	reactome	NA	ATP sensitive Potassium channels
RAMP_P_000051157	R-HSA-5619109	reactome	NA	Defective SLC6A2 causes orthostatic intolerance (OI)
RAMP_P_000051158	R-HSA-392851	reactome	NA	Prostacyclin signalling through prostacyclin receptor
RAMP_P_000051159	R-HSA-418346	reactome	NA	Platelet homeostasis
RAMP_P_000051160	R-HSA-113418	reactome	NA	Formation of the Early Elongation Complex
RAMP_P_000051161	R-HSA-202433	reactome	NA	Generation of second messenger molecules
RAMP_P_000051162	R-HSA-8964038	reactome	NA	LDL clearance
RAMP_P_000051163	R-HSA-5619098	reactome	NA	Defective SLC2A2 causes Fanconi-Bickel syndrome (FBS)
RAMP_P_000051164	R-HSA-418885	reactome	NA	DCC mediated attractive signaling
RAMP_P_000051165	R-HSA-2644603	reactome	NA	Signaling by NOTCH1 in Cancer
RAMP_P_000051166	R-HSA-2161541	reactome	NA	Abacavir metabolism
RAMP_P_000051167	R-HSA-168330	reactome	NA	Viral RNP Complexes in the Host Cell Nucleus
RAMP_P_000051168	R-HSA-8853334	reactome	NA	Signaling by FGFR3 fusions in cancer
RAMP_P_000051169	R-HSA-2467813	reactome	NA	Separation of Sister Chromatids
RAMP_P_000051170	R-HSA-77075	reactome	NA	RNA Pol II CTD phosphorylation and interaction with CE
RAMP_P_000051171	R-HSA-1483206	reactome	NA	Glycerophospholipid biosynthesis
RAMP_P_000051172	R-HSA-159424	reactome	NA	Conjugation of carboxylic acids
RAMP_P_000051173	R-HSA-1474228	reactome	NA	Degradation of the extracellular matrix
RAMP_P_000051174	R-HSA-2187338	reactome	NA	Visual phototransduction
RAMP_P_000051175	R-HSA-9020702	reactome	NA	Interleukin-1 signaling
RAMP_P_000051176	R-HSA-8939236	reactome	NA	RUNX1 regulates transcription of genes involved in differentiation of HSCs
RAMP_P_000051177	R-HSA-425410	reactome	NA	Metal ion SLC transporters
RAMP_P_000051178	R-HSA-9026290	reactome	NA	Biosynthesis of DPAn-3-derived maresins
RAMP_P_000051179	R-HSA-140342	reactome	NA	Apoptosis induced DNA fragmentation
RAMP_P_000051180	R-HSA-9608290	reactome	NA	Defective MUTYH substrate processing
RAMP_P_000051181	R-HSA-2206281	reactome	NA	Mucopolysaccharidoses
RAMP_P_000051182	R-HSA-1299344	reactome	NA	TWIK-related spinal cord K+ channel (TRESK)
RAMP_P_000051183	R-HSA-3560801	reactome	NA	Defective B3GAT3 causes JDSSDHD
RAMP_P_000051184	R-HSA-2173796	reactome	NA	SMAD2/SMAD3:SMAD4 heterotrimer regulates transcription
RAMP_P_000051185	R-HSA-190827	reactome	NA	Transport of connexins along the secretory pathway
RAMP_P_000051186	R-HSA-419408	reactome	NA	Lysosphingolipid and LPA receptors
RAMP_P_000051187	R-HSA-111448	reactome	NA	Activation of NOXA and translocation to mitochondria
RAMP_P_000051188	R-HSA-5389840	reactome	NA	Mitochondrial translation elongation
RAMP_P_000051189	R-HSA-549127	reactome	NA	Organic cation transport
RAMP_P_000051190	R-HSA-211981	reactome	NA	Xenobiotics
RAMP_P_000051191	R-HSA-9013957	reactome	NA	TLR3-mediated TICAM1-dependent programmed cell death
RAMP_P_000051192	R-HSA-6806664	reactome	NA	Metabolism of vitamin K
RAMP_P_000051193	R-HSA-69183	reactome	NA	Processive synthesis on the lagging strand
RAMP_P_000051194	R-HSA-5579026	reactome	NA	Defective CYP11A1 causes Adrenal insufficiency, congenital, with 46,XY sex reversal (AICSR)
RAMP_P_000051195	R-HSA-4641263	reactome	NA	Regulation of FZD by ubiquitination
RAMP_P_000051196	R-HSA-425397	reactome	NA	Transport of vitamins, nucleosides, and related molecules
RAMP_P_000051197	R-HSA-5632681	reactome	NA	Ligand-receptor interactions
RAMP_P_000051198	R-HSA-5627117	reactome	NA	RHO GTPases Activate ROCKs
RAMP_P_000051199	R-HSA-111469	reactome	NA	SMAC, XIAP-regulated apoptotic response
RAMP_P_000051200	R-HSA-418360	reactome	NA	Platelet calcium homeostasis
RAMP_P_000051201	R-HSA-3656535	reactome	NA	TGFBR1 LBD Mutants in Cancer
RAMP_P_000051202	R-HSA-435354	reactome	NA	Zinc transporters
RAMP_P_000051203	R-HSA-5619053	reactome	NA	Defective SLC22A5 causes systemic primary carnitine deficiency (CDSP)
RAMP_P_000051204	R-HSA-195399	reactome	NA	VEGF binds to VEGFR leading to receptor dimerization
RAMP_P_000051205	R-HSA-156582	reactome	NA	Acetylation
RAMP_P_000051206	R-HSA-5654706	reactome	NA	FRS-mediated FGFR3 signaling
RAMP_P_000051207	R-HSA-1483148	reactome	NA	Synthesis of PG
RAMP_P_000051208	R-HSA-1253288	reactome	NA	Downregulation of ERBB4 signaling
RAMP_P_000051209	R-HSA-5655302	reactome	NA	Signaling by FGFR1 in disease
RAMP_P_000051210	R-HSA-111464	reactome	NA	SMAC(DIABLO)-mediated dissociation of IAP:caspase complexes 
RAMP_P_000051211	R-HSA-381753	reactome	NA	Olfactory Signaling Pathway
RAMP_P_000051212	R-HSA-449147	reactome	NA	Signaling by Interleukins
RAMP_P_000051213	R-HSA-68875	reactome	NA	Mitotic Prophase
RAMP_P_000051214	R-HSA-9617629	reactome	NA	Regulation of FOXO transcriptional activity by acetylation
RAMP_P_000051215	R-HSA-6782210	reactome	NA	Gap-filling DNA repair synthesis and ligation in TC-NER
RAMP_P_000051216	R-HSA-1461973	reactome	NA	Defensins
RAMP_P_000051217	R-HSA-975574	reactome	NA	Reactions specific to the hybrid N-glycan synthesis pathway
RAMP_P_000051218	R-HSA-71406	reactome	NA	Pyruvate metabolism and Citric Acid (TCA) cycle
RAMP_P_000051219	R-HSA-6782315	reactome	NA	tRNA modification in the nucleus and cytosol
RAMP_P_000051220	R-HSA-209776	reactome	NA	Amine-derived hormones
RAMP_P_000051221	R-HSA-2691232	reactome	NA	Constitutive Signaling by NOTCH1 HD Domain Mutants
RAMP_P_000051222	R-HSA-8951664	reactome	NA	Neddylation
RAMP_P_000051223	R-HSA-74160	reactome	NA	Gene expression (Transcription)
RAMP_P_000051224	R-HSA-192105	reactome	NA	Synthesis of bile acids and bile salts
RAMP_P_000051225	R-HSA-175474	reactome	NA	Assembly Of The HIV Virion
RAMP_P_000051226	R-HSA-73856	reactome	NA	RNA Polymerase II Transcription Termination
RAMP_P_000051227	R-HSA-1839128	reactome	NA	FGFR4 mutant receptor activation
RAMP_P_000051228	R-HSA-167243	reactome	NA	Tat-mediated HIV elongation arrest and recovery
RAMP_P_000051229	R-HSA-9020558	reactome	NA	Interleukin-2 signaling
RAMP_P_000051230	R-HSA-6803211	reactome	NA	TP53 Regulates Transcription of Death Receptors and Ligands
RAMP_P_000051231	R-HSA-112411	reactome	NA	MAPK1 (ERK2) activation
RAMP_P_000051232	R-HSA-6807070	reactome	NA	PTEN Regulation
RAMP_P_000051233	R-HSA-6806003	reactome	NA	Regulation of TP53 Expression and Degradation
RAMP_P_000051234	R-HSA-6794361	reactome	NA	Neurexins and neuroligins
RAMP_P_000051235	R-HSA-75072	reactome	NA	mRNA Editing
RAMP_P_000051236	R-HSA-5693571	reactome	NA	Nonhomologous End-Joining (NHEJ)
RAMP_P_000051237	R-HSA-964827	reactome	NA	Progressive trimming of alpha-1,2-linked mannose residues from Man9/8/7GlcNAc2 to produce Man5GlcNAc2
RAMP_P_000051238	R-HSA-176033	reactome	NA	Interactions of Vpr with host cellular proteins
RAMP_P_000051239	R-HSA-5619052	reactome	NA	Defective SLC9A9 causes autism 16 (AUTS16)
RAMP_P_000051240	R-HSA-6804115	reactome	NA	TP53 regulates transcription of additional cell cycle genes whose exact role in the p53 pathway remain uncertain
RAMP_P_000051241	R-HSA-9005891	reactome	NA	Loss of function of MECP2 in Rett syndrome
RAMP_P_000051242	R-HSA-3359458	reactome	NA	Defective LMBRD1 causes methylmalonic aciduria and homocystinuria type cblF
RAMP_P_000051243	R-HSA-8978868	reactome	NA	Fatty acid metabolism
RAMP_P_000051244	R-HSA-71262	reactome	NA	Carnitine synthesis
RAMP_P_000051245	R-HSA-391251	reactome	NA	Protein folding
RAMP_P_000051246	R-HSA-983705	reactome	NA	Signaling by the B Cell Receptor (BCR)
RAMP_P_000051247	R-HSA-162594	reactome	NA	Early Phase of HIV Life Cycle
RAMP_P_000051248	R-HSA-3304347	reactome	NA	Loss of Function of SMAD4 in Cancer
RAMP_P_000051249	R-HSA-877312	reactome	NA	Regulation of IFNG signaling
RAMP_P_000051250	R-HSA-72163	reactome	NA	mRNA Splicing - Major Pathway
RAMP_P_000051251	R-HSA-5423599	reactome	NA	Diseases of Mismatch Repair (MMR)
RAMP_P_000051252	R-HSA-112315	reactome	NA	Transmission across Chemical Synapses
RAMP_P_000051253	R-HSA-180336	reactome	NA	SHC1 events in EGFR signaling
RAMP_P_000051254	R-HSA-977347	reactome	NA	Serine biosynthesis
RAMP_P_000051255	R-HSA-3301854	reactome	NA	Nuclear Pore Complex (NPC) Disassembly
RAMP_P_000051256	R-HSA-73864	reactome	NA	RNA Polymerase I Transcription
RAMP_P_000051257	R-HSA-418594	reactome	NA	G alpha (i) signalling events
RAMP_P_000051258	R-HSA-1855215	reactome	NA	IPs transport between ER lumen and cytosol
RAMP_P_000051259	R-HSA-1234162	reactome	NA	Oxygen-dependent asparagine hydroxylation of Hypoxia-inducible Factor Alpha
RAMP_P_000051260	R-HSA-77348	reactome	NA	Beta oxidation of octanoyl-CoA to hexanoyl-CoA
RAMP_P_000051261	R-HSA-5339717	reactome	NA	Misspliced LRP5 mutants have enhanced beta-catenin-dependent signaling
RAMP_P_000051262	R-HSA-73614	reactome	NA	Pyrimidine salvage
RAMP_P_000051263	R-HSA-611105	reactome	NA	Respiratory electron transport
RAMP_P_000051264	R-HSA-164525	reactome	NA	Plus-strand DNA synthesis
RAMP_P_000051265	R-HSA-427601	reactome	NA	Multifunctional anion exchangers
RAMP_P_000051266	R-HSA-5619096	reactome	NA	Defective SLC5A5 causes thyroid dyshormonogenesis 1 (TDH1)
RAMP_P_000051267	R-HSA-5689901	reactome	NA	Metalloprotease DUBs
RAMP_P_000051268	R-HSA-190239	reactome	NA	FGFR3 ligand binding and activation
RAMP_P_000051269	R-HSA-1358803	reactome	NA	Downregulation of ERBB2:ERBB3 signaling
RAMP_P_000051270	R-HSA-75205	reactome	NA	Dissolution of Fibrin Clot
RAMP_P_000051271	R-HSA-168181	reactome	NA	Toll Like Receptor 7/8 (TLR7/8) Cascade
RAMP_P_000051272	R-HSA-351143	reactome	NA	Agmatine biosynthesis
RAMP_P_000051273	R-HSA-162585	reactome	NA	Uncoating of the HIV Virion
RAMP_P_000051274	R-HSA-3134975	reactome	NA	Regulation of innate immune responses to cytosolic DNA
RAMP_P_000051275	R-HSA-3656532	reactome	NA	TGFBR1 KD Mutants in Cancer
RAMP_P_000051276	R-HSA-5218920	reactome	NA	VEGFR2 mediated vascular permeability
RAMP_P_000051277	R-HSA-201681	reactome	NA	TCF dependent signaling in response to WNT
RAMP_P_000051278	R-HSA-1442490	reactome	NA	Collagen degradation
RAMP_P_000051279	R-HSA-430039	reactome	NA	mRNA decay by 5' to 3' exoribonuclease
RAMP_P_000051280	R-HSA-3858494	reactome	NA	Beta-catenin independent WNT signaling
RAMP_P_000051281	R-HSA-937041	reactome	NA	IKK complex recruitment mediated by RIP1
RAMP_P_000051282	R-HSA-73887	reactome	NA	Death Receptor Signalling
RAMP_P_000051283	R-HSA-163841	reactome	NA	Gamma carboxylation, hypusine formation and arylsulfatase activation
RAMP_P_000051284	R-HSA-212165	reactome	NA	Epigenetic regulation of gene expression
RAMP_P_000051285	R-HSA-8951671	reactome	NA	RUNX3 regulates YAP1-mediated transcription
RAMP_P_000051286	R-HSA-2142816	reactome	NA	Synthesis of (16-20)-hydroxyeicosatetraenoic acids (HETE)
RAMP_P_000051287	R-HSA-166662	reactome	NA	Lectin pathway of complement activation
RAMP_P_000051288	R-HSA-416572	reactome	NA	Sema4D induced cell migration and growth-cone collapse
RAMP_P_000051289	R-HSA-5579009	reactome	NA	Defective CYP11B2 causes Corticosterone methyloxidase 1 deficiency (CMO-1 deficiency)
RAMP_P_000051290	R-HSA-196849	reactome	NA	Metabolism of water-soluble vitamins and cofactors
RAMP_P_000051291	R-HSA-379398	reactome	NA	Enzymatic degradation of Dopamine by monoamine oxidase
RAMP_P_000051292	R-HSA-622312	reactome	NA	Inflammasomes
RAMP_P_000051293	R-HSA-351202	reactome	NA	Metabolism of polyamines
RAMP_P_000051294	R-HSA-2424491	reactome	NA	DAP12 signaling
RAMP_P_000051295	R-HSA-8953750	reactome	NA	Transcriptional Regulation by E2F6
RAMP_P_000051296	R-HSA-8948700	reactome	NA	Competing endogenous RNAs (ceRNAs) regulate PTEN translation
RAMP_P_000051297	R-HSA-5635851	reactome	NA	GLI proteins bind promoters of Hh responsive genes to promote transcription
RAMP_P_000051298	R-HSA-8856825	reactome	NA	Cargo recognition for clathrin-mediated endocytosis
RAMP_P_000051299	R-HSA-159782	reactome	NA	Removal of aminoterminal propeptides from gamma-carboxylated proteins
RAMP_P_000051300	R-HSA-3359467	reactome	NA	Defective MTRR causes methylmalonic aciduria and homocystinuria type cblE
RAMP_P_000051301	R-HSA-198765	reactome	NA	Signalling to ERK5
RAMP_P_000051302	R-HSA-8854050	reactome	NA	FBXL7 down-regulates AURKA during mitotic entry and in early mitosis
RAMP_P_000051303	R-HSA-997272	reactome	NA	Inhibition  of voltage gated Ca2+ channels via Gbeta/gamma subunits
RAMP_P_000051304	R-HSA-9022707	reactome	NA	MECP2 regulates transcription factors
RAMP_P_000051305	R-HSA-6811555	reactome	NA	PI5P Regulates TP53 Acetylation
RAMP_P_000051306	R-HSA-2161517	reactome	NA	Abacavir transmembrane transport
RAMP_P_000051307	R-HSA-446343	reactome	NA	Localization of the PINCH-ILK-PARVIN complex to focal adhesions
RAMP_P_000051308	R-HSA-917729	reactome	NA	Endosomal Sorting Complex Required For Transport (ESCRT)
RAMP_P_000051309	R-HSA-8948747	reactome	NA	Regulation of PTEN localization
RAMP_P_000051310	R-HSA-901032	reactome	NA	ER Quality Control Compartment (ERQC)
RAMP_P_000051311	R-HSA-426048	reactome	NA	Arachidonate production from DAG
RAMP_P_000051312	R-HSA-1280218	reactome	NA	Adaptive Immune System
RAMP_P_000051313	R-HSA-8941856	reactome	NA	RUNX3 regulates NOTCH signaling
RAMP_P_000051314	R-HSA-187706	reactome	NA	Signalling to p38 via RIT and RIN
RAMP_P_000051315	R-HSA-3928663	reactome	NA	EPHA-mediated growth cone collapse
RAMP_P_000051316	R-HSA-187687	reactome	NA	Signalling to ERKs
RAMP_P_000051317	R-HSA-2142845	reactome	NA	Hyaluronan metabolism
RAMP_P_000051318	R-HSA-418886	reactome	NA	Netrin mediated repulsion signals
RAMP_P_000051319	R-HSA-8864260	reactome	NA	Transcriptional regulation by the AP-2 (TFAP2) family of transcription factors
RAMP_P_000051320	R-HSA-204005	reactome	NA	COPII-mediated vesicle transport
RAMP_P_000051321	R-HSA-975576	reactome	NA	N-glycan antennae elongation in the medial/trans-Golgi
RAMP_P_000051322	R-HSA-444473	reactome	NA	Formyl peptide receptors bind formyl peptides and many other ligands
RAMP_P_000051323	R-HSA-5689877	reactome	NA	Josephin domain DUBs
RAMP_P_000051324	R-HSA-8934903	reactome	NA	Receptor Mediated Mitophagy
RAMP_P_000051325	R-HSA-6802949	reactome	NA	Signaling by RAS mutants
RAMP_P_000051326	R-HSA-5676934	reactome	NA	Protein repair
RAMP_P_000051327	R-HSA-2023837	reactome	NA	Signaling by FGFR2 amplification mutants
RAMP_P_000051328	R-HSA-6804759	reactome	NA	Regulation of TP53 Activity through Association with Co-factors
RAMP_P_000051329	R-HSA-5654743	reactome	NA	Signaling by FGFR4
RAMP_P_000051330	R-HSA-190872	reactome	NA	Transport of connexons to the plasma membrane
RAMP_P_000051331	R-HSA-4755583	reactome	NA	Defective DOLK causes DOLK-CDG (CDG-1m)
RAMP_P_000051332	R-HSA-977068	reactome	NA	Termination of O-glycan biosynthesis
RAMP_P_000051333	R-HSA-8849472	reactome	NA	PTK6 Down-Regulation
RAMP_P_000051334	R-HSA-5173105	reactome	NA	O-linked glycosylation
RAMP_P_000051335	R-HSA-163680	reactome	NA	AMPK inhibits chREBP transcriptional activation activity
RAMP_P_000051336	R-HSA-72187	reactome	NA	mRNA 3'-end processing
RAMP_P_000051337	R-HSA-191650	reactome	NA	Regulation of gap junction activity
RAMP_P_000051338	R-HSA-181438	reactome	NA	Toll Like Receptor 2 (TLR2) Cascade
RAMP_P_000051339	R-HSA-445144	reactome	NA	Signal transduction by L1
RAMP_P_000051340	R-HSA-8953854	reactome	NA	Metabolism of RNA
RAMP_P_000051341	R-HSA-69895	reactome	NA	Transcriptional  activation of  cell cycle inhibitor p21 
RAMP_P_000051342	R-HSA-192905	reactome	NA	vRNP Assembly
RAMP_P_000051343	R-HSA-5579031	reactome	NA	Defective ACTH causes Obesity and Pro-opiomelanocortinin deficiency (POMCD)
RAMP_P_000051344	R-HSA-169131	reactome	NA	Inhibition of PKR
RAMP_P_000051345	R-HSA-112316	reactome	NA	Neuronal System
RAMP_P_000051346	R-HSA-5620922	reactome	NA	BBSome-mediated cargo-targeting to cilium
RAMP_P_000051347	R-HSA-196819	reactome	NA	Vitamin B1 (thiamin) metabolism
RAMP_P_000051348	R-HSA-8854521	reactome	NA	Interaction between PHLDA1 and AURKA
RAMP_P_000051349	R-HSA-156588	reactome	NA	Glucuronidation
RAMP_P_000051350	R-HSA-6799198	reactome	NA	Complex I biogenesis
RAMP_P_000051351	R-HSA-163560	reactome	NA	Triglyceride catabolism
RAMP_P_000051352	R-HSA-5660489	reactome	NA	MTF1 activates gene expression
RAMP_P_000051353	R-HSA-1592389	reactome	NA	Activation of Matrix Metalloproteinases
RAMP_P_000051354	R-HSA-4655427	reactome	NA	SUMOylation of DNA methylation proteins
RAMP_P_000051355	R-HSA-8850843	reactome	NA	Phosphate bond hydrolysis by NTPDase proteins
RAMP_P_000051356	R-HSA-6790901	reactome	NA	rRNA modification in the nucleus and cytosol
RAMP_P_000051357	R-HSA-163359	reactome	NA	Glucagon signaling in metabolic regulation
RAMP_P_000051358	R-HSA-372790	reactome	NA	Signaling by GPCR
RAMP_P_000051359	R-HSA-5619040	reactome	NA	Defective SLC34A1 causes hypophosphatemic nephrolithiasis/osteoporosis 1 (NPHLOP1)
RAMP_P_000051360	R-HSA-5362768	reactome	NA	Hh mutants that don't undergo autocatalytic processing are degraded by ERAD
RAMP_P_000051361	R-HSA-2022870	reactome	NA	Chondroitin sulfate biosynthesis
RAMP_P_000051362	R-HSA-375276	reactome	NA	Peptide ligand-binding receptors
RAMP_P_000051363	R-HSA-5578749	reactome	NA	Transcriptional regulation by small RNAs
RAMP_P_000051364	R-HSA-176187	reactome	NA	Activation of ATR in response to replication stress
RAMP_P_000051365	R-HSA-73886	reactome	NA	Chromosome Maintenance
RAMP_P_000051366	R-HSA-9036866	reactome	NA	Expression and Processing of Neurotrophins
RAMP_P_000051367	R-HSA-5649702	reactome	NA	APEX1-Independent Resolution of AP Sites via the Single Nucleotide Replacement Pathway
RAMP_P_000051368	R-HSA-168333	reactome	NA	NEP/NS2 Interacts with the Cellular Export Machinery
RAMP_P_000051369	R-HSA-2534343	reactome	NA	Interaction With Cumulus Cells
RAMP_P_000051370	R-HSA-195258	reactome	NA	RHO GTPase Effectors
RAMP_P_000051371	R-HSA-1912420	reactome	NA	Pre-NOTCH Processing in Golgi
RAMP_P_000051372	R-HSA-6803529	reactome	NA	FGFR2 alternative splicing
RAMP_P_000051373	R-HSA-264876	reactome	NA	Insulin processing
RAMP_P_000051374	R-HSA-432722	reactome	NA	Golgi Associated Vesicle Biogenesis
RAMP_P_000051375	R-HSA-1236974	reactome	NA	ER-Phagosome pathway
RAMP_P_000051376	R-HSA-9023661	reactome	NA	Biosynthesis of E-series 18(R)-resolvins
RAMP_P_000051377	R-HSA-1855196	reactome	NA	IP3 and IP4 transport between cytosol and nucleus
RAMP_P_000051378	R-HSA-140534	reactome	NA	Caspase activation via Death Receptors in the presence of ligand
RAMP_P_000051379	R-HSA-3371556	reactome	NA	Cellular response to heat stress
RAMP_P_000051380	R-HSA-390696	reactome	NA	Adrenoceptors
RAMP_P_000051381	R-HSA-6787639	reactome	NA	GDP-fucose biosynthesis
RAMP_P_000051382	R-HSA-399719	reactome	NA	Trafficking of AMPA receptors
RAMP_P_000051383	R-HSA-9018519	reactome	NA	Estrogen-dependent gene expression
RAMP_P_000051384	R-HSA-264642	reactome	NA	Acetylcholine Neurotransmitter Release Cycle
RAMP_P_000051385	R-HSA-159230	reactome	NA	Transport of the SLBP Dependant Mature mRNA
RAMP_P_000051386	R-HSA-1839126	reactome	NA	FGFR2 mutant receptor activation
RAMP_P_000051387	R-HSA-5602571	reactome	NA	TRAF3 deficiency - HSE
RAMP_P_000051388	R-HSA-193993	reactome	NA	Mineralocorticoid biosynthesis
RAMP_P_000051389	R-HSA-201688	reactome	NA	WNT mediated activation of DVL
RAMP_P_000051390	R-HSA-176409	reactome	NA	APC/C:Cdc20 mediated degradation of mitotic proteins
RAMP_P_000051391	R-HSA-2142700	reactome	NA	Synthesis of Lipoxins (LX)
RAMP_P_000051392	R-HSA-8852276	reactome	NA	The role of GTSE1 in G2/M progression after G2 checkpoint
RAMP_P_000051393	R-HSA-3656534	reactome	NA	Loss of Function of TGFBR1 in Cancer
RAMP_P_000051394	R-HSA-427389	reactome	NA	ERCC6 (CSB) and EHMT2 (G9a) positively regulate rRNA expression
RAMP_P_000051395	R-HSA-8957322	reactome	NA	Metabolism of steroids
RAMP_P_000051396	R-HSA-112314	reactome	NA	Neurotransmitter receptors and postsynaptic signal transmission
RAMP_P_000051397	R-HSA-186712	reactome	NA	Regulation of beta-cell development
RAMP_P_000051398	R-HSA-69618	reactome	NA	Mitotic Spindle Checkpoint
RAMP_P_000051399	R-HSA-2979096	reactome	NA	NOTCH2 Activation and Transmission of Signal to the Nucleus
RAMP_P_000051400	R-HSA-1483152	reactome	NA	Hydrolysis of LPE
RAMP_P_000051401	R-HSA-8978934	reactome	NA	Metabolism of cofactors
RAMP_P_000051402	R-HSA-6804756	reactome	NA	Regulation of TP53 Activity through Phosphorylation
RAMP_P_000051403	R-HSA-2219528	reactome	NA	PI3K/AKT Signaling in Cancer
RAMP_P_000051404	R-HSA-450385	reactome	NA	Butyrate Response Factor 1 (BRF1) binds and destabilizes mRNA
RAMP_P_000051405	R-HSA-201722	reactome	NA	Formation of the beta-catenin:TCF transactivating complex
RAMP_P_000051406	R-HSA-2243919	reactome	NA	Crosslinking of collagen fibrils
RAMP_P_000051407	R-HSA-174577	reactome	NA	Activation of C3 and C5
RAMP_P_000051408	R-HSA-3656243	reactome	NA	Defective ST3GAL3 causes MCT12 and EIEE15
RAMP_P_000051409	R-HSA-1655829	reactome	NA	Regulation of cholesterol biosynthesis by SREBP (SREBF)
RAMP_P_000051410	R-HSA-8935964	reactome	NA	RUNX1 regulates expression of components of tight junctions
RAMP_P_000051411	R-HSA-69541	reactome	NA	Stabilization of p53
RAMP_P_000051412	R-HSA-5625886	reactome	NA	Activated PKN1 stimulates transcription of AR (androgen receptor) regulated genes KLK2 and KLK3
RAMP_P_000051413	R-HSA-2980766	reactome	NA	Nuclear Envelope Breakdown
RAMP_P_000051414	R-HSA-5619068	reactome	NA	Defective SLC2A10 causes arterial tortuosity syndrome (ATS)
RAMP_P_000051415	R-HSA-173599	reactome	NA	Formation of the active cofactor, UDP-glucuronate
RAMP_P_000051416	R-HSA-176034	reactome	NA	Interactions of Tat with host cellular proteins
RAMP_P_000051417	R-HSA-975144	reactome	NA	IRAK1 recruits IKK complex upon TLR7/8 or 9 stimulation
RAMP_P_000051418	R-HSA-5676590	reactome	NA	NIK-->noncanonical NF-kB signaling
RAMP_P_000051419	R-HSA-2142789	reactome	NA	Ubiquinol biosynthesis
RAMP_P_000051420	R-HSA-1855184	reactome	NA	IPs transport between cytosol and ER lumen
RAMP_P_000051421	R-HSA-9034015	reactome	NA	Signaling by NTRK3 (TRKC)
RAMP_P_000051422	R-HSA-8849473	reactome	NA	PTK6 Expression
RAMP_P_000051423	R-HSA-4420332	reactome	NA	Defective B3GALT6 causes EDSP2 and SEMDJL1
RAMP_P_000051424	R-HSA-72649	reactome	NA	Translation initiation complex formation
RAMP_P_000051425	R-HSA-69615	reactome	NA	G1/S DNA Damage Checkpoints
RAMP_P_000051426	R-HSA-5685938	reactome	NA	HDR through Single Strand Annealing (SSA)
RAMP_P_000051427	R-HSA-69017	reactome	NA	CDK-mediated phosphorylation and removal of Cdc6
RAMP_P_000051428	R-HSA-74749	reactome	NA	Signal attenuation
RAMP_P_000051429	R-HSA-8877330	reactome	NA	RUNX1 and FOXP3 control the development of regulatory T lymphocytes (Tregs)
RAMP_P_000051430	R-HSA-435368	reactome	NA	Zinc efflux and compartmentalization by the SLC30 family
RAMP_P_000051431	R-HSA-75893	reactome	NA	TNF signaling
RAMP_P_000051432	R-HSA-8856688	reactome	NA	Golgi-to-ER retrograde transport
RAMP_P_000051433	R-HSA-983695	reactome	NA	Antigen activates B Cell Receptor (BCR) leading to generation of second messengers
RAMP_P_000051434	R-HSA-174495	reactome	NA	Synthesis And Processing Of GAG, GAGPOL Polyproteins
RAMP_P_000051435	R-HSA-1912408	reactome	NA	Pre-NOTCH Transcription and Translation
RAMP_P_000051436	R-HSA-5663202	reactome	NA	Diseases of signal transduction
RAMP_P_000051437	R-HSA-1500931	reactome	NA	Cell-Cell communication
RAMP_P_000051438	R-HSA-4839743	reactome	NA	phosphorylation site mutants of CTNNB1 are not targeted to the proteasome by the destruction complex
RAMP_P_000051439	R-HSA-4085377	reactome	NA	SUMOylation of SUMOylation proteins
RAMP_P_000051440	R-HSA-3858516	reactome	NA	Glycogen storage disease type 0 (liver GYS2)
RAMP_P_000051441	R-HSA-168874	reactome	NA	Transport of HA trimer, NA tetramer and M2 tetramer from the endoplasmic reticulum to the Golgi Apparatus
RAMP_P_000051442	R-HSA-5674404	reactome	NA	PTEN Loss of Function in Cancer
RAMP_P_000051443	R-HSA-5683371	reactome	NA	Defective ABCB6 causes isolated colobomatous microphthalmia 7 (MCOPCB7)
RAMP_P_000051444	R-HSA-373080	reactome	NA	Class B/2 (Secretin family receptors)
RAMP_P_000051445	R-HSA-419812	reactome	NA	Calcitonin-like ligand receptors
RAMP_P_000051446	R-HSA-844623	reactome	NA	The IPAF inflammasome
RAMP_P_000051447	R-HSA-1660517	reactome	NA	Synthesis of PIPs at the late endosome membrane
RAMP_P_000051448	R-HSA-179812	reactome	NA	GRB2 events in EGFR signaling
RAMP_P_000051449	R-HSA-444209	reactome	NA	Free fatty acid receptors
RAMP_P_000051450	R-HSA-3229121	reactome	NA	Glycogen storage diseases
RAMP_P_000051451	R-HSA-5660883	reactome	NA	Defective SLC7A9 causes cystinuria (CSNU)
RAMP_P_000051452	R-HSA-8964011	reactome	NA	HDL clearance
RAMP_P_000051453	R-HSA-8939256	reactome	NA	RUNX1 regulates transcription of genes involved in WNT signaling
RAMP_P_000051454	R-HSA-2980736	reactome	NA	Peptide hormone metabolism
RAMP_P_000051455	R-HSA-5660668	reactome	NA	CLEC7A/inflammasome pathway
RAMP_P_000051456	R-HSA-1483191	reactome	NA	Synthesis of PC
RAMP_P_000051457	R-HSA-2197563	reactome	NA	NOTCH2 intracellular domain regulates transcription
RAMP_P_000051458	R-HSA-6783783	reactome	NA	Interleukin-10 signaling
RAMP_P_000051459	R-HSA-6783310	reactome	NA	Fanconi Anemia Pathway
RAMP_P_000051460	R-HSA-4043911	reactome	NA	Defective PMM2 causes PMM2-CDG (CDG-1a)
RAMP_P_000051461	R-HSA-1483166	reactome	NA	Synthesis of PA
RAMP_P_000051462	R-HSA-3642279	reactome	NA	TGFBR2 MSI Frameshift Mutants in Cancer
RAMP_P_000051463	R-HSA-1839117	reactome	NA	Signaling by cytosolic FGFR1 fusion mutants
RAMP_P_000051464	R-HSA-9026395	reactome	NA	Biosynthesis of DHA-derived sulfido conjugates
RAMP_P_000051465	R-HSA-2173789	reactome	NA	TGF-beta receptor signaling activates SMADs
RAMP_P_000051466	R-HSA-5579013	reactome	NA	Defective CYP7B1 causes Spastic paraplegia 5A, autosomal recessive (SPG5A) and Congenital bile acid synthesis defect 3 (CBAS3)
RAMP_P_000051467	R-HSA-5579027	reactome	NA	Defective CYP2R1 causes Rickets vitamin D-dependent 1B (VDDR1B)
RAMP_P_000051468	R-HSA-5419276	reactome	NA	Mitochondrial translation termination
RAMP_P_000051469	R-HSA-3560782	reactome	NA	Diseases associated with glycosaminoglycan metabolism
RAMP_P_000051470	R-HSA-5579032	reactome	NA	Defective TBXAS1 causes Ghosal hematodiaphyseal dysplasia (GHDD)
RAMP_P_000051471	R-HSA-8878159	reactome	NA	Transcriptional regulation by RUNX3
RAMP_P_000051472	R-HSA-168268	reactome	NA	Virus Assembly and Release
RAMP_P_000051473	R-HSA-8985947	reactome	NA	Interleukin-9 signaling
RAMP_P_000051474	R-HSA-5603027	reactome	NA	IKBKG deficiency causes anhidrotic ectodermal dysplasia with immunodeficiency (EDA-ID) (via TLR)
RAMP_P_000051475	R-HSA-2024101	reactome	NA	CS/DS degradation
RAMP_P_000051476	R-HSA-8849932	reactome	NA	Synaptic adhesion-like molecules
RAMP_P_000051477	R-HSA-5654733	reactome	NA	Negative regulation of FGFR4 signaling
RAMP_P_000051478	R-HSA-2894862	reactome	NA	Constitutive Signaling by NOTCH1 HD+PEST Domain Mutants
RAMP_P_000051479	R-HSA-379397	reactome	NA	Enzymatic degradation of dopamine by COMT
RAMP_P_000051480	R-HSA-5619041	reactome	NA	Defective SLC36A2 causes iminoglycinuria (IG) and hyperglycinuria (HG)
RAMP_P_000051481	R-HSA-379401	reactome	NA	Dopamine clearance from the synaptic cleft
RAMP_P_000051482	R-HSA-5632927	reactome	NA	Defective Mismatch Repair Associated With MSH3
RAMP_P_000051483	R-HSA-5619083	reactome	NA	Defective SLC35A3 causes arthrogryposis, mental retardation, and seizures (AMRS)
RAMP_P_000051484	R-HSA-451306	reactome	NA	Ionotropic activity of kainate receptors
RAMP_P_000051485	R-HSA-418038	reactome	NA	Nucleotide-like (purinergic) receptors
RAMP_P_000051486	R-HSA-8942233	reactome	NA	Intestinal infectious diseases
RAMP_P_000051487	R-HSA-383280	reactome	NA	Nuclear Receptor transcription pathway
RAMP_P_000051488	R-HSA-192869	reactome	NA	cRNA Synthesis
RAMP_P_000051489	R-HSA-9013973	reactome	NA	TICAM1-dependent activation of IRF3/IRF7
RAMP_P_000051490	R-HSA-8873719	reactome	NA	RAB geranylgeranylation
RAMP_P_000051491	R-HSA-2514856	reactome	NA	The phototransduction cascade
RAMP_P_000051492	R-HSA-428157	reactome	NA	Sphingolipid metabolism
RAMP_P_000051493	R-HSA-445355	reactome	NA	Smooth Muscle Contraction
RAMP_P_000051494	R-HSA-1296061	reactome	NA	HCN channels
RAMP_P_000051495	R-HSA-5693565	reactome	NA	Recruitment and ATM-mediated phosphorylation of repair and signaling proteins at DNA double strand breaks
RAMP_P_000051496	R-HSA-8956319	reactome	NA	Nucleobase catabolism
RAMP_P_000051497	R-HSA-8963899	reactome	NA	Plasma lipoprotein remodeling
RAMP_P_000051498	R-HSA-447041	reactome	NA	CHL1 interactions
RAMP_P_000051499	R-HSA-73942	reactome	NA	DNA Damage Reversal
RAMP_P_000051500	R-HSA-8849474	reactome	NA	PTK6 Activates STAT3
RAMP_P_000051501	R-HSA-9022534	reactome	NA	Loss of MECP2 binding ability to 5hmC-DNA
RAMP_P_000051502	R-HSA-3359457	reactome	NA	Defective GIF causes intrinsic factor deficiency
RAMP_P_000051503	R-HSA-156581	reactome	NA	Methylation
RAMP_P_000051504	R-HSA-8943723	reactome	NA	Regulation of PTEN mRNA translation
RAMP_P_000051505	R-HSA-199992	reactome	NA	trans-Golgi Network Vesicle Budding
RAMP_P_000051506	R-HSA-6807047	reactome	NA	Cholesterol biosynthesis via desmosterol
RAMP_P_000051507	R-HSA-75067	reactome	NA	Processing of Capped Intronless Pre-mRNA
RAMP_P_000051508	R-HSA-70350	reactome	NA	Fructose catabolism
RAMP_P_000051509	R-HSA-8851907	reactome	NA	MET activates PI3K/AKT signaling
RAMP_P_000051510	R-HSA-168270	reactome	NA	Fusion and Uncoating of the Influenza Virion
RAMP_P_000051511	R-HSA-3248023	reactome	NA	Regulation by TREX1
RAMP_P_000051512	R-HSA-964739	reactome	NA	N-glycan trimming and elongation in the cis-Golgi
RAMP_P_000051513	R-HSA-422475	reactome	NA	Axon guidance
RAMP_P_000051514	R-HSA-212436	reactome	NA	Generic Transcription Pathway
RAMP_P_000051515	R-HSA-111459	reactome	NA	Activation of caspases through apoptosome-mediated cleavage
RAMP_P_000051516	R-HSA-375165	reactome	NA	NCAM signaling for neurite out-growth
RAMP_P_000051517	R-HSA-5609977	reactome	NA	Defective GALE can cause Epimerase-deficiency galactosemia (EDG)
RAMP_P_000051518	R-HSA-8849470	reactome	NA	PTK6 Regulates Cell Cycle
RAMP_P_000051519	R-HSA-8868773	reactome	NA	rRNA processing in the nucleus and cytosol
RAMP_P_000051520	R-HSA-5656364	reactome	NA	Defective SLC5A1 causes congenital glucose/galactose malabsorption (GGM)
RAMP_P_000051521	R-HSA-427359	reactome	NA	SIRT1 negatively regulates rRNA expression
RAMP_P_000051522	R-HSA-6804114	reactome	NA	TP53 Regulates Transcription of Genes Involved in G2 Cell Cycle Arrest
RAMP_P_000051523	R-HSA-5655862	reactome	NA	Translesion synthesis by POLK
RAMP_P_000051524	R-HSA-162699	reactome	NA	Synthesis of dolichyl-phosphate mannose
RAMP_P_000051525	R-HSA-3000157	reactome	NA	Laminin interactions
RAMP_P_000051526	R-HSA-5689880	reactome	NA	Ub-specific processing proteases
RAMP_P_000051527	R-HSA-3108214	reactome	NA	SUMOylation of DNA damage response and repair proteins
RAMP_P_000051528	R-HSA-9034013	reactome	NA	NTF3 activates NTRK3 signaling
RAMP_P_000051529	R-HSA-139910	reactome	NA	Activation of BMF and translocation to mitochondria
RAMP_P_000051530	R-HSA-77350	reactome	NA	Beta oxidation of hexanoyl-CoA to butanoyl-CoA
RAMP_P_000051531	R-HSA-156842	reactome	NA	Eukaryotic Translation Elongation
RAMP_P_000051532	R-HSA-114452	reactome	NA	Activation of BH3-only proteins
RAMP_P_000051533	R-HSA-6788467	reactome	NA	IL-6-type cytokine receptor ligand interactions
RAMP_P_000051534	R-HSA-8866907	reactome	NA	Activation of the TFAP2 (AP-2) family of transcription factors
RAMP_P_000051535	R-HSA-110373	reactome	NA	Resolution of AP sites via the multiple-nucleotide patch replacement pathway
RAMP_P_000051536	R-HSA-977441	reactome	NA	GABA A receptor activation
RAMP_P_000051537	R-HSA-110357	reactome	NA	Displacement of DNA glycosylase by APEX1
RAMP_P_000051538	R-HSA-5619063	reactome	NA	Defective SLC29A3 causes histiocytosis-lymphadenopathy plus syndrome (HLAS)
RAMP_P_000051539	R-HSA-3065678	reactome	NA	SUMO is transferred from E1 to E2 (UBE2I, UBC9)
RAMP_P_000051540	R-HSA-167287	reactome	NA	HIV elongation arrest and recovery
RAMP_P_000051541	R-HSA-5579028	reactome	NA	Defective CYP17A1 causes Adrenal hyperplasia 5 (AH5)
RAMP_P_000051542	R-HSA-69273	reactome	NA	Cyclin A/B1/B2 associated events during G2/M transition
RAMP_P_000051543	R-HSA-5658623	reactome	NA	FGFRL1 modulation of FGFR1 signaling
RAMP_P_000051544	R-HSA-8956320	reactome	NA	Nucleobase biosynthesis
RAMP_P_000051545	R-HSA-156590	reactome	NA	Glutathione conjugation
RAMP_P_000051546	R-HSA-450520	reactome	NA	HuR (ELAVL1) binds and stabilizes mRNA
RAMP_P_000051547	R-HSA-1299503	reactome	NA	TWIK related potassium channel (TREK)
RAMP_P_000051548	R-HSA-70221	reactome	NA	Glycogen breakdown (glycogenolysis)
RAMP_P_000051549	R-HSA-629587	reactome	NA	Highly sodium permeable acetylcholine nicotinic receptors
RAMP_P_000051550	R-HSA-977443	reactome	NA	GABA receptor activation
RAMP_P_000051551	R-HSA-72200	reactome	NA	mRNA Editing: C to U Conversion
RAMP_P_000051552	R-HSA-1855204	reactome	NA	Synthesis of IP3 and IP4 in the cytosol
RAMP_P_000051553	R-HSA-5675221	reactome	NA	Negative regulation of MAPK pathway
RAMP_P_000051554	R-HSA-69620	reactome	NA	Cell Cycle Checkpoints
RAMP_P_000051555	R-HSA-5619056	reactome	NA	Defective HK1 causes hexokinase deficiency (HK deficiency)
RAMP_P_000051556	R-HSA-71182	reactome	NA	Phenylalanine and tyrosine catabolism
RAMP_P_000051557	R-HSA-1660537	reactome	NA	PIPs transport between early endosome and Golgi membranes
RAMP_P_000051558	R-HSA-5637812	reactome	NA	Signaling by EGFRvIII in Cancer
RAMP_P_000051559	R-HSA-5358351	reactome	NA	Signaling by Hedgehog
RAMP_P_000051560	R-HSA-8939211	reactome	NA	ESR-mediated signaling
RAMP_P_000051561	R-HSA-2995383	reactome	NA	Initiation of Nuclear Envelope Reformation
RAMP_P_000051562	R-HSA-202131	reactome	NA	Metabolism of nitric oxide
RAMP_P_000051563	R-HSA-2206305	reactome	NA	MPS IIID - Sanfilippo syndrome D
RAMP_P_000051564	R-HSA-420092	reactome	NA	Glucagon-type ligand receptors
RAMP_P_000051565	R-HSA-2168880	reactome	NA	Scavenging of heme from plasma
RAMP_P_000051566	R-HSA-1296052	reactome	NA	Ca2+ activated K+ channels
RAMP_P_000051567	R-HSA-8849468	reactome	NA	PTK6 Regulates Proteins Involved in RNA Processing
RAMP_P_000051568	R-HSA-8985801	reactome	NA	Regulation of cortical dendrite branching
RAMP_P_000051569	R-HSA-196807	reactome	NA	Nicotinate metabolism
RAMP_P_000051570	R-HSA-2160456	reactome	NA	Phenylketonuria
RAMP_P_000051571	R-HSA-5357801	reactome	NA	Programmed Cell Death
RAMP_P_000051572	R-HSA-75035	reactome	NA	Chk1/Chk2(Cds1) mediated inactivation of Cyclin B:Cdk1 complex
RAMP_P_000051573	R-HSA-1268020	reactome	NA	Mitochondrial protein import
RAMP_P_000051574	R-HSA-3781865	reactome	NA	Diseases of glycosylation
RAMP_P_000051575	R-HSA-9604323	reactome	NA	Negative regulation of NOTCH4 signaling
RAMP_P_000051576	R-HSA-166166	reactome	NA	MyD88-independent TLR4 cascade 
RAMP_P_000051577	R-HSA-399721	reactome	NA	Glutamate binding, activation of AMPA receptors and synaptic plasticity
RAMP_P_000051578	R-HSA-196783	reactome	NA	Coenzyme A biosynthesis
RAMP_P_000051579	R-HSA-446652	reactome	NA	Interleukin-1 family signaling
RAMP_P_000051580	R-HSA-8875513	reactome	NA	MET interacts with TNS proteins
RAMP_P_000051581	R-HSA-1300644	reactome	NA	Interaction With The Zona Pellucida
RAMP_P_000051582	R-HSA-112122	reactome	NA	ALKBH2 mediated reversal of alkylation damage
RAMP_P_000051583	R-HSA-2978092	reactome	NA	Abnormal conversion of 2-oxoglutarate to 2-hydroxyglutarate
RAMP_P_000051584	R-HSA-73854	reactome	NA	RNA Polymerase I Promoter Clearance
RAMP_P_000051585	R-HSA-4341670	reactome	NA	Defective NEU1 causes sialidosis
RAMP_P_000051586	R-HSA-189451	reactome	NA	Heme biosynthesis
RAMP_P_000051587	R-HSA-380284	reactome	NA	Loss of proteins required for interphase microtubule organization from the centrosome
RAMP_P_000051588	R-HSA-2559583	reactome	NA	Cellular Senescence
RAMP_P_000051589	R-HSA-6791465	reactome	NA	Pentose phosphate pathway disease
RAMP_P_000051590	R-HSA-5619043	reactome	NA	Defective SLC2A1 causes GLUT1 deficiency syndrome 1 (GLUT1DS1)
RAMP_P_000051591	R-HSA-196108	reactome	NA	Pregnenolone biosynthesis
RAMP_P_000051592	R-HSA-450341	reactome	NA	Activation of the AP-1 family of transcription factors
RAMP_P_000051593	R-HSA-912694	reactome	NA	Regulation of IFNA signaling
RAMP_P_000051594	R-HSA-380612	reactome	NA	Metabolism of serotonin
RAMP_P_000051595	R-HSA-4420097	reactome	NA	VEGFA-VEGFR2 Pathway
RAMP_P_000051596	R-HSA-2871809	reactome	NA	FCERI mediated Ca+2 mobilization
RAMP_P_000051597	R-HSA-2682334	reactome	NA	EPH-Ephrin signaling
RAMP_P_000051598	R-HSA-4720489	reactome	NA	Defective ALG12 causes ALG12-CDG (CDG-1g)
RAMP_P_000051599	R-HSA-112308	reactome	NA	Presynaptic depolarization and calcium channel opening
RAMP_P_000051600	R-HSA-74751	reactome	NA	Insulin receptor signalling cascade
RAMP_P_000051601	R-HSA-5607763	reactome	NA	CLEC7A (Dectin-1) induces NFAT activation
RAMP_P_000051602	R-HSA-5654716	reactome	NA	Downstream signaling of activated FGFR4
RAMP_P_000051603	R-HSA-210747	reactome	NA	Regulation of gene expression in early pancreatic precursor cells
RAMP_P_000051604	R-HSA-5638303	reactome	NA	Inhibition of Signaling by Overexpressed EGFR
RAMP_P_000051605	R-HSA-111447	reactome	NA	Activation of BAD and translocation to mitochondria 
RAMP_P_000051606	R-HSA-8876198	reactome	NA	RAB GEFs exchange GTP for GDP on RABs
RAMP_P_000051607	R-HSA-141405	reactome	NA	Inhibition of the proteolytic activity of APC/C required for the onset of anaphase by mitotic spindle checkpoint components
RAMP_P_000051608	R-HSA-442660	reactome	NA	Na+/Cl- dependent neurotransmitter transporters
RAMP_P_000051609	R-HSA-428559	reactome	NA	Proton-coupled neutral amino acid transporters
RAMP_P_000051610	R-HSA-8956321	reactome	NA	Nucleotide salvage
RAMP_P_000051611	R-HSA-2474795	reactome	NA	Diseases associated with visual transduction
RAMP_P_000051612	R-HSA-392023	reactome	NA	Adrenaline signalling through Alpha-2 adrenergic receptor
RAMP_P_000051613	R-HSA-2404192	reactome	NA	Signaling by Type 1 Insulin-like Growth Factor 1 Receptor (IGF1R)
RAMP_P_000051614	R-HSA-72306	reactome	NA	tRNA processing
RAMP_P_000051615	R-HSA-71291	reactome	NA	Metabolism of amino acids and derivatives
RAMP_P_000051616	R-HSA-5661182	reactome	NA	Defective SLCO1B1 causes hyperbilirubinemia, Rotor type (HBLRR)
RAMP_P_000051617	R-HSA-3214842	reactome	NA	HDMs demethylate histones
RAMP_P_000051618	R-HSA-5083628	reactome	NA	Defective POMGNT1 causes MDDGA3, MDDGB3 and MDDGC3
RAMP_P_000051619	R-HSA-5654738	reactome	NA	Signaling by FGFR2
RAMP_P_000051620	R-HSA-9022692	reactome	NA	Regulation of MECP2 expression and activity
RAMP_P_000051621	R-HSA-111933	reactome	NA	Calmodulin induced events
RAMP_P_000051622	R-HSA-8951936	reactome	NA	RUNX3 regulates p14-ARF
RAMP_P_000051623	R-HSA-9034864	reactome	NA	Activated NTRK3 signals through RAS
RAMP_P_000051624	R-HSA-5656121	reactome	NA	Translesion synthesis by POLI
RAMP_P_000051625	R-HSA-4086400	reactome	NA	PCP/CE pathway
RAMP_P_000051626	R-HSA-4085001	reactome	NA	Sialic acid metabolism
RAMP_P_000051627	R-HSA-5576892	reactome	NA	Phase 0 - rapid depolarisation
RAMP_P_000051628	R-HSA-190370	reactome	NA	FGFR1b ligand binding and activation
RAMP_P_000051629	R-HSA-1606322	reactome	NA	ZBP1(DAI) mediated induction of type I IFNs
RAMP_P_000051630	R-HSA-373755	reactome	NA	Semaphorin interactions
RAMP_P_000051631	R-HSA-8853338	reactome	NA	Signaling by FGFR3 point mutants in cancer
RAMP_P_000051632	R-HSA-190377	reactome	NA	FGFR2b ligand binding and activation
RAMP_P_000051633	R-HSA-1362409	reactome	NA	Mitochondrial iron-sulfur cluster biogenesis
RAMP_P_000051634	R-HSA-380259	reactome	NA	Loss of Nlp from mitotic centrosomes
RAMP_P_000051635	R-HSA-1855192	reactome	NA	IPs transport between nucleus and ER lumen
RAMP_P_000051636	R-HSA-72766	reactome	NA	Translation
RAMP_P_000051637	R-HSA-3232142	reactome	NA	SUMOylation of ubiquitinylation proteins
RAMP_P_000051638	R-HSA-71064	reactome	NA	Lysine catabolism
RAMP_P_000051639	R-HSA-5678520	reactome	NA	Defective ABCB11 causes progressive familial intrahepatic cholestasis 2 and benign recurrent intrahepatic cholestasis 2
RAMP_P_000051640	R-HSA-1483249	reactome	NA	Inositol phosphate metabolism
RAMP_P_000051641	R-HSA-1839124	reactome	NA	FGFR1 mutant receptor activation
RAMP_P_000051642	R-HSA-1475029	reactome	NA	Reversible hydration of carbon dioxide
RAMP_P_000051643	R-HSA-5674400	reactome	NA	Constitutive Signaling by AKT1 E17K in Cancer
RAMP_P_000051644	R-HSA-193639	reactome	NA	p75NTR signals via NF-kB
RAMP_P_000051645	R-HSA-1793185	reactome	NA	Chondroitin sulfate/dermatan sulfate metabolism
RAMP_P_000051646	R-HSA-429914	reactome	NA	Deadenylation-dependent mRNA decay
RAMP_P_000051647	R-HSA-9005895	reactome	NA	Pervasive developmental disorders
RAMP_P_000051648	R-HSA-68911	reactome	NA	G2 Phase
RAMP_P_000051649	R-HSA-167162	reactome	NA	RNA Polymerase II HIV Promoter Escape
RAMP_P_000051650	R-HSA-5619044	reactome	NA	Defective SLC6A19 causes Hartnup disorder (HND)
RAMP_P_000051651	R-HSA-3000170	reactome	NA	Syndecan interactions
RAMP_P_000051652	R-HSA-399710	reactome	NA	Activation of AMPA receptors
RAMP_P_000051653	R-HSA-73843	reactome	NA	5-Phosphoribose 1-diphosphate biosynthesis
RAMP_P_000051654	R-HSA-1299287	reactome	NA	Tandem pore domain halothane-inhibited K+ channel (THIK)
RAMP_P_000051655	R-HSA-5619070	reactome	NA	Defective SLC16A1 causes symptomatic deficiency in lactate transport (SDLT)
RAMP_P_000051656	R-HSA-8852405	reactome	NA	Signaling by MST1
RAMP_P_000051657	R-HSA-428890	reactome	NA	Role of ABL in ROBO-SLIT signaling
RAMP_P_000051658	R-HSA-83936	reactome	NA	Transport of nucleosides and free purine and pyrimidine bases across the plasma membrane
RAMP_P_000051659	R-HSA-9006927	reactome	NA	Signaling by Non-Receptor Tyrosine Kinases
RAMP_P_000051660	R-HSA-400451	reactome	NA	Free fatty acids regulate insulin secretion
RAMP_P_000051661	R-HSA-5336415	reactome	NA	Uptake and function of diphtheria toxin
RAMP_P_000051662	R-HSA-1250347	reactome	NA	SHC1 events in ERBB4 signaling
RAMP_P_000051663	R-HSA-1855231	reactome	NA	Synthesis of IPs in the ER lumen
RAMP_P_000051664	R-HSA-8981373	reactome	NA	Intestinal hexose absorption
RAMP_P_000051665	R-HSA-3065679	reactome	NA	SUMO is proteolytically processed
RAMP_P_000051666	R-HSA-1643685	reactome	NA	Disease
RAMP_P_000051667	R-HSA-211994	reactome	NA	Sterols are 12-hydroxylated by CYP8B1
RAMP_P_000051668	R-HSA-8939247	reactome	NA	RUNX1 regulates transcription of genes involved in interleukin signaling
RAMP_P_000051669	R-HSA-1632852	reactome	NA	Macroautophagy
RAMP_P_000051670	R-HSA-156584	reactome	NA	Cytosolic sulfonation of small molecules
RAMP_P_000051671	R-HSA-3785653	reactome	NA	Myoclonic epilepsy of Lafora
RAMP_P_000051672	R-HSA-912526	reactome	NA	Interleukin receptor SHC signaling
RAMP_P_000051673	R-HSA-6791312	reactome	NA	TP53 Regulates Transcription of Cell Cycle Genes
RAMP_P_000051674	R-HSA-111453	reactome	NA	BH3-only proteins associate with and inactivate anti-apoptotic BCL-2 members
RAMP_P_000051675	R-HSA-162588	reactome	NA	Budding and maturation of HIV virion
RAMP_P_000051676	R-HSA-450294	reactome	NA	MAP kinase activation
RAMP_P_000051677	R-HSA-389887	reactome	NA	Beta-oxidation of pristanoyl-CoA
RAMP_P_000051678	R-HSA-2730905	reactome	NA	Role of LAT2/NTAL/LAB on calcium mobilization
RAMP_P_000051679	R-HSA-190236	reactome	NA	Signaling by FGFR
RAMP_P_000051680	R-HSA-73933	reactome	NA	Resolution of Abasic Sites (AP sites)
RAMP_P_000051681	R-HSA-2160916	reactome	NA	Hyaluronan uptake and degradation
RAMP_P_000051682	R-HSA-1299361	reactome	NA	TWIK-related alkaline pH activated K+ channel (TALK)
RAMP_P_000051683	R-HSA-68949	reactome	NA	Orc1 removal from chromatin
RAMP_P_000051684	R-HSA-5688426	reactome	NA	Deubiquitination
RAMP_P_000051685	R-HSA-190373	reactome	NA	FGFR1c ligand binding and activation
RAMP_P_000051686	R-HSA-194441	reactome	NA	Metabolism of non-coding RNA
RAMP_P_000051687	R-HSA-8964058	reactome	NA	HDL remodeling
RAMP_P_000051688	R-HSA-3295583	reactome	NA	TRP channels
RAMP_P_000051689	R-HSA-114508	reactome	NA	Effects of PIP2 hydrolysis
RAMP_P_000051690	R-HSA-5678771	reactome	NA	Defective ABCB4 causes progressive familial intrahepatic cholestasis 3, intrahepatic cholestasis of pregnancy 3 and gallbladder disease 1
RAMP_P_000051691	R-HSA-1222556	reactome	NA	ROS, RNS production in phagocytes
RAMP_P_000051692	R-HSA-380994	reactome	NA	ATF4 activates genes
RAMP_P_000051693	R-HSA-198693	reactome	NA	AKT phosphorylates targets in the nucleus
RAMP_P_000051694	R-HSA-5250992	reactome	NA	Toxicity of botulinum toxin type E (BoNT/E)
RAMP_P_000051695	R-HSA-167169	reactome	NA	HIV Transcription Elongation
RAMP_P_000051696	R-HSA-1482883	reactome	NA	Acyl chain remodeling of DAG and TAG
RAMP_P_000051697	R-HSA-2206290	reactome	NA	MPS IV - Morquio syndrome A
RAMP_P_000051698	R-HSA-69239	reactome	NA	Synthesis of DNA
RAMP_P_000051699	R-HSA-110314	reactome	NA	Recognition of DNA damage by PCNA-containing replication complex
RAMP_P_000051700	R-HSA-4755510	reactome	NA	SUMOylation of immune response proteins
RAMP_P_000051701	R-HSA-6791462	reactome	NA	TALDO1 deficiency: failed conversion of  Fru(6)P, E4P to SH7P, GA3P
RAMP_P_000051702	R-HSA-5624958	reactome	NA	ARL13B-mediated ciliary trafficking of INPP5E
RAMP_P_000051703	R-HSA-167290	reactome	NA	Pausing and recovery of HIV elongation
RAMP_P_000051704	R-HSA-1855229	reactome	NA	IP6 and IP7 transport between cytosol and nucleus
RAMP_P_000051705	R-HSA-5358565	reactome	NA	Mismatch repair (MMR) directed by MSH2:MSH6 (MutSalpha)
RAMP_P_000051706	R-HSA-5657655	reactome	NA	MGMT-mediated DNA damage reversal
RAMP_P_000051707	R-HSA-163685	reactome	NA	Integration of energy metabolism
RAMP_P_000051708	R-HSA-5626467	reactome	NA	RHO GTPases activate IQGAPs
RAMP_P_000051709	R-HSA-9013508	reactome	NA	NOTCH3 Intracellular Domain Regulates Transcription
RAMP_P_000051710	R-HSA-2993913	reactome	NA	Clearance of Nuclear Envelope Membranes from Chromatin
RAMP_P_000051711	R-HSA-6811442	reactome	NA	Intra-Golgi and retrograde Golgi-to-ER traffic
RAMP_P_000051712	R-HSA-72165	reactome	NA	mRNA Splicing - Minor Pathway
RAMP_P_000051713	R-HSA-442380	reactome	NA	Zinc influx into cells by the SLC39 gene family
RAMP_P_000051714	R-HSA-114516	reactome	NA	Disinhibition of SNARE formation
RAMP_P_000051715	R-HSA-4615885	reactome	NA	SUMOylation of DNA replication proteins
RAMP_P_000051716	R-HSA-5357609	reactome	NA	Glycogen storage disease type II (GAA)
RAMP_P_000051717	R-HSA-4719377	reactome	NA	Defective DPM2 causes DPM2-CDG (CDG-1u)
RAMP_P_000051718	R-HSA-5628897	reactome	NA	TP53 Regulates Metabolic Genes
RAMP_P_000051719	R-HSA-174178	reactome	NA	APC/C:Cdh1 mediated degradation of Cdc20 and other APC/C:Cdh1 targeted proteins in late mitosis/early G1
RAMP_P_000051720	R-HSA-198323	reactome	NA	AKT phosphorylates targets in the cytosol
RAMP_P_000051721	R-HSA-3772470	reactome	NA	Negative regulation of TCF-dependent signaling by WNT ligand antagonists
RAMP_P_000051722	R-HSA-159236	reactome	NA	Transport of Mature mRNA derived from an Intron-Containing Transcript
RAMP_P_000051723	R-HSA-168253	reactome	NA	Host Interactions with Influenza Factors
RAMP_P_000051724	R-HSA-9028335	reactome	NA	Activated NTRK2 signals through PI3K
RAMP_P_000051725	R-HSA-205043	reactome	NA	NRIF signals cell death from the nucleus
RAMP_P_000051726	R-HSA-6809371	reactome	NA	Formation of the cornified envelope
RAMP_P_000051727	R-HSA-168315	reactome	NA	Inhibition of Host mRNA Processing and RNA Silencing
RAMP_P_000051728	R-HSA-8963889	reactome	NA	Assembly of active LPL and LIPC lipase complexes
RAMP_P_000051729	R-HSA-421837	reactome	NA	Clathrin derived vesicle budding
RAMP_P_000051730	R-HSA-399956	reactome	NA	CRMPs in Sema3A signaling
RAMP_P_000051731	R-HSA-8939245	reactome	NA	RUNX1 regulates transcription of genes involved in BCR signaling
RAMP_P_000051732	R-HSA-1280215	reactome	NA	Cytokine Signaling in Immune system
RAMP_P_000051733	R-HSA-3359474	reactome	NA	Defective MMACHC causes methylmalonic aciduria and homocystinuria type cblC
RAMP_P_000051734	R-HSA-975155	reactome	NA	MyD88 dependent cascade initiated on endosome
RAMP_P_000051735	R-HSA-73779	reactome	NA	RNA Polymerase II Transcription Pre-Initiation And Promoter Opening
RAMP_P_000051736	R-HSA-5654732	reactome	NA	Negative regulation of FGFR3 signaling
RAMP_P_000051737	R-HSA-844455	reactome	NA	The NLRP1 inflammasome
RAMP_P_000051738	R-HSA-917937	reactome	NA	Iron uptake and transport
RAMP_P_000051739	R-HSA-352238	reactome	NA	Breakdown of the nuclear lamina
RAMP_P_000051740	R-HSA-5602498	reactome	NA	MyD88 deficiency (TLR2/4)
RAMP_P_000051741	R-HSA-5696399	reactome	NA	Global Genome Nucleotide Excision Repair (GG-NER)
RAMP_P_000051742	R-HSA-3000484	reactome	NA	Scavenging by Class F Receptors
RAMP_P_000051743	R-HSA-77305	reactome	NA	Beta oxidation of palmitoyl-CoA to myristoyl-CoA
RAMP_P_000051744	R-HSA-5339562	reactome	NA	Uptake and actions of bacterial toxins
RAMP_P_000051745	R-HSA-69231	reactome	NA	Cyclin D associated events in G1
RAMP_P_000051746	R-HSA-380972	reactome	NA	Energy dependent regulation of mTOR by LKB1-AMPK
RAMP_P_000051747	R-HSA-180786	reactome	NA	Extension of Telomeres
RAMP_P_000051748	R-HSA-68616	reactome	NA	Assembly of the ORC complex at the origin of replication
RAMP_P_000051749	R-HSA-5205647	reactome	NA	Mitophagy
RAMP_P_000051750	R-HSA-5685939	reactome	NA	HDR through MMEJ (alt-NHEJ)
RAMP_P_000051751	R-HSA-210744	reactome	NA	Regulation of gene expression in late stage (branching morphogenesis) pancreatic bud precursor cells
RAMP_P_000051752	R-HSA-2453864	reactome	NA	Retinoid cycle disease events
RAMP_P_000051753	R-HSA-416482	reactome	NA	G alpha (12/13) signalling events
RAMP_P_000051754	R-HSA-190861	reactome	NA	Gap junction assembly
RAMP_P_000051755	R-HSA-159854	reactome	NA	Gamma-carboxylation, transport, and amino-terminal cleavage of proteins
RAMP_P_000051756	R-HSA-73777	reactome	NA	RNA Polymerase I Chain Elongation
RAMP_P_000051757	R-HSA-72695	reactome	NA	Formation of the ternary complex, and subsequently, the 43S complex
RAMP_P_000051758	R-HSA-111446	reactome	NA	Activation of BIM and translocation to mitochondria 
RAMP_P_000051759	R-HSA-3296482	reactome	NA	Defects in vitamin and cofactor metabolism
RAMP_P_000051760	R-HSA-354192	reactome	NA	Integrin alphaIIb beta3 signaling
RAMP_P_000051761	R-HSA-140877	reactome	NA	Formation of Fibrin Clot (Clotting Cascade)
RAMP_P_000051762	R-HSA-1296053	reactome	NA	Classical Kir channels
RAMP_P_000051763	R-HSA-5576891	reactome	NA	Cardiac conduction
RAMP_P_000051764	R-HSA-390918	reactome	NA	Peroxisomal lipid metabolism
RAMP_P_000051765	R-HSA-381033	reactome	NA	ATF6 (ATF6-alpha) activates chaperones
RAMP_P_000051766	R-HSA-192823	reactome	NA	Viral mRNA Translation
RAMP_P_000051767	R-HSA-3371497	reactome	NA	HSP90 chaperone cycle for steroid hormone receptors (SHR)
RAMP_P_000051768	R-HSA-196299	reactome	NA	Beta-catenin phosphorylation cascade
RAMP_P_000051769	R-HSA-6783589	reactome	NA	Interleukin-6 family signaling
RAMP_P_000051770	R-HSA-69052	reactome	NA	Switching of origins to a post-replicative state
RAMP_P_000051771	R-HSA-73728	reactome	NA	RNA Polymerase I Promoter Opening
RAMP_P_000051772	R-HSA-77352	reactome	NA	Beta oxidation of butanoyl-CoA to acetyl-CoA
RAMP_P_000051773	R-HSA-9008059	reactome	NA	Interleukin-37 signaling
RAMP_P_000051774	R-HSA-1307965	reactome	NA	betaKlotho-mediated ligand binding
RAMP_P_000051775	R-HSA-3656248	reactome	NA	Defective HEXB causes GM2G2
RAMP_P_000051776	R-HSA-556833	reactome	NA	Metabolism of lipids
RAMP_P_000051777	R-HSA-8866427	reactome	NA	VLDLR internalisation and degradation
RAMP_P_000051778	R-HSA-211935	reactome	NA	Fatty acids
RAMP_P_000051779	R-HSA-8963896	reactome	NA	HDL assembly
RAMP_P_000051780	R-HSA-5218921	reactome	NA	VEGFR2 mediated cell proliferation
RAMP_P_000051781	R-HSA-1963640	reactome	NA	GRB2 events in ERBB2 signaling
RAMP_P_000051782	R-HSA-6806667	reactome	NA	Metabolism of fat-soluble vitamins
RAMP_P_000051783	R-HSA-174154	reactome	NA	APC/C:Cdc20 mediated degradation of Securin
RAMP_P_000051784	R-HSA-71737	reactome	NA	Pyrophosphate hydrolysis
RAMP_P_000051785	R-HSA-5696400	reactome	NA	Dual Incision in GG-NER
RAMP_P_000051786	R-HSA-205025	reactome	NA	NADE modulates death signalling
RAMP_P_000051787	R-HSA-1236973	reactome	NA	Cross-presentation of particulate exogenous antigens (phagosomes)
RAMP_P_000051788	R-HSA-420597	reactome	NA	Nectin/Necl  trans heterodimerization
RAMP_P_000051789	R-HSA-5578995	reactome	NA	Defective TPMT causes Thiopurine S-methyltransferase deficiency (TPMT deficiency)
RAMP_P_000051790	R-HSA-167242	reactome	NA	Abortive elongation of HIV-1 transcript in the absence of Tat
RAMP_P_000051791	R-HSA-264870	reactome	NA	Caspase-mediated cleavage of cytoskeletal proteins
RAMP_P_000051792	R-HSA-5654704	reactome	NA	SHC-mediated cascade:FGFR3
RAMP_P_000051793	R-HSA-392517	reactome	NA	Rap1 signalling
RAMP_P_000051794	R-HSA-163765	reactome	NA	ChREBP activates metabolic gene expression
RAMP_P_000051795	R-HSA-421270	reactome	NA	Cell-cell junction organization
RAMP_P_000051796	R-HSA-5683177	reactome	NA	Defective ABCC8 can cause hypoglycemias and hyperglycemias
RAMP_P_000051797	R-HSA-141430	reactome	NA	Inactivation of APC/C via direct inhibition of the APC/C complex
RAMP_P_000051798	R-HSA-5655253	reactome	NA	Signaling by FGFR2 in disease
RAMP_P_000051799	R-HSA-4724289	reactome	NA	Defective ALG6 causes ALG6-CDG (CDG-1c)
RAMP_P_000051800	R-HSA-168638	reactome	NA	NOD1/2 Signaling Pathway
RAMP_P_000051801	R-HSA-175567	reactome	NA	Integration of viral DNA into host genomic DNA
RAMP_P_000051802	R-HSA-5603041	reactome	NA	IRAK4 deficiency (TLR2/4)
RAMP_P_000051803	R-HSA-5218859	reactome	NA	Regulated Necrosis
RAMP_P_000051804	R-HSA-5387390	reactome	NA	Hh mutants abrogate ligand secretion
RAMP_P_000051805	R-HSA-5619071	reactome	NA	Defective SLC22A12 causes renal hypouricemia 1 (RHUC1)
RAMP_P_000051806	R-HSA-8931987	reactome	NA	RUNX1 regulates estrogen receptor mediated transcription
RAMP_P_000051807	R-HSA-75105	reactome	NA	Fatty acyl-CoA biosynthesis
RAMP_P_000051808	R-HSA-9032500	reactome	NA	Activated NTRK2 signals through FYN
RAMP_P_000051809	R-HSA-3595177	reactome	NA	Defective CHSY1 causes TPBS
RAMP_P_000051810	R-HSA-209968	reactome	NA	Thyroxine biosynthesis
RAMP_P_000051811	R-HSA-110328	reactome	NA	Recognition and association of DNA glycosylase with site containing an affected pyrimidine
RAMP_P_000051812	R-HSA-3359463	reactome	NA	Defective CUBN causes hereditary megaloblastic anemia 1
RAMP_P_000051813	R-HSA-5659729	reactome	NA	Defective SLC6A18 may confer susceptibility to iminoglycinuria and/or hyperglycinuria
RAMP_P_000051814	R-HSA-70635	reactome	NA	Urea cycle
RAMP_P_000051815	R-HSA-5610783	reactome	NA	Degradation of GLI2 by the proteasome
RAMP_P_000051816	R-HSA-1839130	reactome	NA	Signaling by activated point mutants of FGFR3
RAMP_P_000051817	R-HSA-428359	reactome	NA	Insulin-like Growth Factor-2 mRNA Binding Proteins (IGF2BPs/IMPs/VICKZs) bind RNA
RAMP_P_000051818	R-HSA-2033519	reactome	NA	Activated point mutants of FGFR2
RAMP_P_000051819	R-HSA-2660826	reactome	NA	Constitutive Signaling by NOTCH1 t(7;9)(NOTCH1:M1580_K2555) Translocation Mutant
RAMP_P_000051820	R-HSA-9033241	reactome	NA	Peroxisomal protein import
RAMP_P_000051821	R-HSA-933543	reactome	NA	NF-kB activation through FADD/RIP-1 pathway mediated by caspase-8 and -10
RAMP_P_000051822	R-HSA-168316	reactome	NA	Assembly of Viral Components at the Budding Site
RAMP_P_000051823	R-HSA-176408	reactome	NA	Regulation of APC/C activators between G1/S and early anaphase
RAMP_P_000051824	R-HSA-203641	reactome	NA	NOSTRIN mediated eNOS trafficking
RAMP_P_000051825	R-HSA-168255	reactome	NA	Influenza Life Cycle
RAMP_P_000051826	R-HSA-174490	reactome	NA	Membrane binding and targetting of GAG proteins
RAMP_P_000051827	R-HSA-8941284	reactome	NA	RUNX2 regulates chondrocyte maturation
RAMP_P_000051828	R-HSA-5621480	reactome	NA	Dectin-2 family
RAMP_P_000051829	R-HSA-4419969	reactome	NA	Depolymerisation of the Nuclear Lamina
RAMP_P_000051830	R-HSA-5619047	reactome	NA	Defective SLC2A9 causes hypouricemia renal 2 (RHUC2)
RAMP_P_000051831	R-HSA-5619085	reactome	NA	Defective SLC26A3 causes congenital secretory chloride diarrhea 1 (DIAR1)
RAMP_P_000051832	R-HSA-75896	reactome	NA	Plasmalogen biosynthesis
RAMP_P_000051833	R-HSA-8935690	reactome	NA	Digestion
RAMP_P_000051834	R-HSA-77285	reactome	NA	Beta oxidation of myristoyl-CoA to lauroyl-CoA
RAMP_P_000051835	R-HSA-1237112	reactome	NA	Methionine salvage pathway
RAMP_P_000051836	R-HSA-5684264	reactome	NA	MAP3K8 (TPL2)-dependent MAPK1/3 activation
RAMP_P_000051837	R-HSA-6794362	reactome	NA	Protein-protein interactions at synapses
RAMP_P_000051838	R-HSA-2046104	reactome	NA	alpha-linolenic (omega3) and linoleic (omega6) acid metabolism
RAMP_P_000051839	R-HSA-8963901	reactome	NA	Chylomicron remodeling
RAMP_P_000051840	R-HSA-442742	reactome	NA	CREB1 phosphorylation through NMDA receptor-mediated activation of RAS signaling
RAMP_P_000051841	R-HSA-5654219	reactome	NA	Phospholipase C-mediated cascade: FGFR1
RAMP_P_000051842	R-HSA-163125	reactome	NA	Post-translational modification: synthesis of GPI-anchored proteins
RAMP_P_000051843	R-HSA-6802953	reactome	NA	RAS signaling downstream of NF1 loss-of-function variants
RAMP_P_000051844	R-HSA-5662853	reactome	NA	Essential pentosuria
RAMP_P_000051845	R-HSA-606279	reactome	NA	Deposition of new CENPA-containing nucleosomes at the centromere
RAMP_P_000051846	R-HSA-1980145	reactome	NA	Signaling by NOTCH2
RAMP_P_000051847	R-HSA-110313	reactome	NA	Translesion synthesis by Y family DNA polymerases bypasses lesions on DNA template
RAMP_P_000051848	R-HSA-5619067	reactome	NA	Defective SLC1A1 is implicated in schizophrenia 18 (SCZD18) and dicarboxylic aminoaciduria (DCBXA)
RAMP_P_000051849	R-HSA-211859	reactome	NA	Biological oxidations
RAMP_P_000051850	R-HSA-3371453	reactome	NA	Regulation of HSF1-mediated heat shock response
RAMP_P_000051851	R-HSA-69563	reactome	NA	p53-Dependent G1 DNA Damage Response
RAMP_P_000051852	R-HSA-168799	reactome	NA	Neurotoxicity of clostridium toxins
RAMP_P_000051853	R-HSA-350864	reactome	NA	Regulation of thyroid hormone activity
RAMP_P_000051854	R-HSA-933542	reactome	NA	TRAF6 mediated NF-kB activation
RAMP_P_000051855	R-HSA-975957	reactome	NA	Nonsense Mediated Decay (NMD) enhanced by the Exon Junction Complex (EJC)
RAMP_P_000051856	R-HSA-5627123	reactome	NA	RHO GTPases activate PAKs
RAMP_P_000051857	R-HSA-3371511	reactome	NA	HSF1 activation
RAMP_P_000051858	R-HSA-2129379	reactome	NA	Molecules associated with elastic fibres
RAMP_P_000051859	R-HSA-112307	reactome	NA	Transmission across Electrical Synapses 
RAMP_P_000051860	R-HSA-9627069	reactome	NA	Regulation of the apoptosome activity
RAMP_P_000051861	R-HSA-167246	reactome	NA	Tat-mediated elongation of the HIV-1 transcript
RAMP_P_000051862	R-HSA-2142753	reactome	NA	Arachidonic acid metabolism
RAMP_P_000051863	R-HSA-2142850	reactome	NA	Hyaluronan biosynthesis and export
RAMP_P_000051864	R-HSA-191273	reactome	NA	Cholesterol biosynthesis
RAMP_P_000051865	R-HSA-8964315	reactome	NA	G beta:gamma signalling through BTK
RAMP_P_000051866	R-HSA-193775	reactome	NA	Synthesis of bile acids and bile salts via 24-hydroxycholesterol
RAMP_P_000051867	R-HSA-2187335	reactome	NA	The retinoid cycle in cones (daylight vision)
RAMP_P_000051868	R-HSA-5576890	reactome	NA	Phase 3 - rapid repolarisation
RAMP_P_000051869	R-HSA-622323	reactome	NA	Presynaptic nicotinic acetylcholine receptors
RAMP_P_000051870	R-HSA-2453902	reactome	NA	The canonical retinoid cycle in rods (twilight vision)
RAMP_P_000051871	R-HSA-196757	reactome	NA	Metabolism of folate and pterines
RAMP_P_000051872	R-HSA-109581	reactome	NA	Apoptosis
RAMP_P_000051873	R-HSA-5688399	reactome	NA	Defective ABCA3 causes pulmonary surfactant metabolism dysfunction 3 (SMDP3)
RAMP_P_000051874	R-HSA-8847453	reactome	NA	Synthesis of PIPs in the nucleus
RAMP_P_000051875	R-HSA-174414	reactome	NA	Processive synthesis on the C-strand of the telomere
RAMP_P_000051876	R-HSA-434316	reactome	NA	Fatty Acids bound to GPR40 (FFAR1) regulate insulin secretion
RAMP_P_000051877	R-HSA-210745	reactome	NA	Regulation of gene expression in beta cells
RAMP_P_000051878	R-HSA-1266738	reactome	NA	Developmental Biology
RAMP_P_000051879	R-HSA-1430728	reactome	NA	Metabolism
RAMP_P_000051880	R-HSA-75158	reactome	NA	TRAIL  signaling
RAMP_P_000051881	R-HSA-5619049	reactome	NA	Defective SLC40A1 causes hemochromatosis 4 (HFE4) (macrophages)
RAMP_P_000051882	R-HSA-1295596	reactome	NA	Spry regulation of FGF signaling
RAMP_P_000051883	R-HSA-8876384	reactome	NA	Listeria monocytogenes entry into host cells
RAMP_P_000051884	R-HSA-983170	reactome	NA	Antigen Presentation: Folding, assembly and peptide loading of class I MHC
RAMP_P_000051885	R-HSA-189200	reactome	NA	Cellular hexose transport
RAMP_P_000051886	R-HSA-3928664	reactome	NA	Ephrin signaling
RAMP_P_000051887	R-HSA-6802946	reactome	NA	Signaling by moderate kinase activity BRAF mutants
RAMP_P_000051888	R-HSA-2644607	reactome	NA	Loss of Function of FBXW7 in Cancer and NOTCH1 Signaling
RAMP_P_000051889	R-HSA-380270	reactome	NA	Recruitment of mitotic centrosome proteins and complexes
RAMP_P_000051890	R-HSA-8984722	reactome	NA	Interleukin-35 Signalling
RAMP_P_000051891	R-HSA-3656237	reactome	NA	Defective EXT2 causes exostoses 2
RAMP_P_000051892	R-HSA-167827	reactome	NA	The proton buffering model
RAMP_P_000051893	R-HSA-1483255	reactome	NA	PI Metabolism
RAMP_P_000051894	R-HSA-5683329	reactome	NA	Defective ABCD4 causes methylmalonic aciduria and homocystinuria, cblj type (MAHCJ)
RAMP_P_000051895	R-HSA-111457	reactome	NA	Release of apoptotic factors from the mitochondria
RAMP_P_000051896	R-HSA-75109	reactome	NA	Triglyceride biosynthesis
RAMP_P_000051897	R-HSA-4839726	reactome	NA	Chromatin organization
RAMP_P_000051898	R-HSA-5654689	reactome	NA	PI-3K cascade:FGFR1
RAMP_P_000051899	R-HSA-168274	reactome	NA	Export of Viral Ribonucleoproteins from Nucleus
RAMP_P_000051900	R-HSA-171306	reactome	NA	Packaging Of Telomere Ends
RAMP_P_000051901	R-HSA-381183	reactome	NA	ATF6 (ATF6-alpha) activates chaperone genes
RAMP_P_000051902	R-HSA-1474165	reactome	NA	Reproduction
RAMP_P_000051903	R-HSA-168298	reactome	NA	Release
RAMP_P_000051904	R-HSA-193368	reactome	NA	Synthesis of bile acids and bile salts via 7alpha-hydroxycholesterol
RAMP_P_000051905	R-HSA-69002	reactome	NA	DNA Replication Pre-Initiation
RAMP_P_000051906	R-HSA-77286	reactome	NA	mitochondrial fatty acid beta-oxidation of saturated fatty acids
RAMP_P_000051907	R-HSA-174437	reactome	NA	Removal of the Flap Intermediate from the C-strand
RAMP_P_000051908	R-HSA-1660662	reactome	NA	Glycosphingolipid metabolism
RAMP_P_000051909	R-HSA-73817	reactome	NA	Purine ribonucleoside monophosphate biosynthesis
RAMP_P_000051910	R-HSA-211733	reactome	NA	Regulation of activated PAK-2p34 by proteasome mediated degradation
