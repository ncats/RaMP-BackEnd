RAMP_P_000048682	WP1917	wiki	NA	Signaling by Rho GTPases
RAMP_P_000048683	WP3680	wiki	NA	Association Between Physico-Chemical Features and Toxicity Associated Pathways
RAMP_P_000048684	WP2741	wiki	NA	Inositol phosphate metabolism
RAMP_P_000048685	WP4008	wiki	NA	NO/cGMP/PKG mediated Neuroprotection
RAMP_P_000048686	WP428	wiki	NA	Wnt Signaling
RAMP_P_000048687	WP1941	wiki	NA	Peroxisomal beta-oxidation of tetracosanoyl-CoA
RAMP_P_000048688	WP4049	wiki	NA	Neutrophil degranulation
RAMP_P_000048689	WP3548	wiki	NA	Amine-derived hormones
RAMP_P_000048690	WP2727	wiki	NA	Regulation of Hypoxia-inducible Factor (HIF) by oxygen
RAMP_P_000048691	WP106	wiki	NA	Alanine and aspartate metabolism
RAMP_P_000048692	WP4298	wiki	NA	Viral Acute Myocarditis
RAMP_P_000048693	WP3338	wiki	NA	Signaling by FGFR2
RAMP_P_000048694	WP3552	wiki	NA	tRNA processing in the nucleus
RAMP_P_000048695	WP2754	wiki	NA	Neurotransmitter receptors and postsynaptic signal transmission
RAMP_P_000048696	WP1870	wiki	NA	Neurotransmitter clearance
RAMP_P_000048697	WP4099	wiki	NA	rRNA modification in the mitochondrion
RAMP_P_000048698	WP4320	wiki	NA	The effect of progerin on the involved genes in Hutchinson-Gilford Progeria Syndrome
RAMP_P_000048699	WP4071	wiki	NA	RAB geranylgeranylation
RAMP_P_000048700	WP2685	wiki	NA	GABA synthesis, release, reuptake and degradation
RAMP_P_000048701	WP2034	wiki	NA	Leptin signaling pathway
RAMP_P_000048702	WP2032	wiki	NA	Human Thyroid Stimulating Hormone (TSH) signaling pathway
RAMP_P_000048703	WP3666	wiki	NA	Metabolism of Dichloroethylene by CYP450
RAMP_P_000048704	WP3560	wiki	NA	Cargo concentration in the ER
RAMP_P_000048705	WP1438	wiki	NA	Influenza A virus infection
RAMP_P_000048706	WP3644	wiki	NA	NAD+ metabolism
RAMP_P_000048707	WP383	wiki	NA	Striated Muscle Contraction Pathway
RAMP_P_000048708	WP1449	wiki	NA	Regulation of toll-like receptor signaling pathway
RAMP_P_000048709	WP2113	wiki	NA	Type III interferon signaling
RAMP_P_000048710	WP1992	wiki	NA	Genes targeted by miRNAs in adipocytes
RAMP_P_000048711	WP2597	wiki	NA	Secretion of Hydrochloric Acid in Parietal Cells
RAMP_P_000048712	WP2491	wiki	NA	Diclofenac Metabolic Pathway
RAMP_P_000048713	WP4396	wiki	NA	Nonalcoholic fatty liver disease
RAMP_P_000048714	WP3657	wiki	NA	Hematopoietic Stem Cell Gene Regulation by GABP alpha/beta Complex
RAMP_P_000048715	WP185	wiki	NA	Integrin-mediated Cell Adhesion
RAMP_P_000048716	WP4413	wiki	NA	Transcriptional Regulation by E2F6
RAMP_P_000048717	WP229	wiki	NA	Irinotecan Pathway
RAMP_P_000048718	WP4115	wiki	NA	Deregulated CDK5 triggers multiple neurodegenerative pathways in Alzheimer's disease models
RAMP_P_000048719	WP3573	wiki	NA	Histidine, lysine, phenylalanine, tyrosine, proline and tryptophan catabolism
RAMP_P_000048720	WP2768	wiki	NA	MyD88 dependent cascade initiated on endosome
RAMP_P_000048721	WP2708	wiki	NA	Collagen degradation
RAMP_P_000048722	WP1772	wiki	NA	Apoptosis Modulation and Signaling
RAMP_P_000048723	WP3878	wiki	NA	ATM Signaling Network in Development and Disease 
RAMP_P_000048724	WP53	wiki	NA	ID signaling pathway
RAMP_P_000048725	WP4124	wiki	NA	Cilium Assembly
RAMP_P_000048726	WP272	wiki	NA	Blood Clotting Cascade
RAMP_P_000048727	WP3670	wiki	NA	Simplified Interaction Map Between LOXL4 and Oxidative Stress Pathway
RAMP_P_000048728	WP1878	wiki	NA	Peroxisomal lipid metabolism
RAMP_P_000048729	WP80	wiki	NA	Nucleotide GPCRs
RAMP_P_000048730	WP2645	wiki	NA	Heroin metabolism
RAMP_P_000048731	WP2485	wiki	NA	NAD Biosynthesis II (from tryptophan)
RAMP_P_000048732	WP4174	wiki	NA	Metabolism of Tetrahydrocannabinol (THC)
RAMP_P_000048733	WP3354	wiki	NA	C-type lectin receptors (CLRs)
RAMP_P_000048734	WP4424	wiki	NA	G alpha (q) signalling events
RAMP_P_000048735	WP4423	wiki	NA	G alpha (i) signalling events
RAMP_P_000048736	WP111	wiki	NA	Electron Transport Chain (OXPHOS system in mitochondria)
RAMP_P_000048737	WP3309	wiki	NA	EPH-Ephrin signaling
RAMP_P_000048738	WP524	wiki	NA	G13 Signaling Pathway
RAMP_P_000048739	WP1784	wiki	NA	Apoptotic execution phase
RAMP_P_000048740	WP2848	wiki	NA	Differentiation Pathway
RAMP_P_000048741	WP3545	wiki	NA	NIK-->noncanonical NF-kB signaling
RAMP_P_000048742	WP3565	wiki	NA	DNA Damage/Telomere Stress Induced Senescence
RAMP_P_000048743	WP186	wiki	NA	Homologous recombination
RAMP_P_000048744	WP4453	wiki	NA	Transcriptional Regulation by MECP2
RAMP_P_000048745	WP136	wiki	NA	Phase I biotransformations, non P450
RAMP_P_000048746	WP3550	wiki	NA	Nonhomologous End-Joining (NHEJ)
RAMP_P_000048747	WP2703	wiki	NA	Extracellular matrix organization
RAMP_P_000048748	WP4046	wiki	NA	Receptor-type tyrosine-protein phosphatases
RAMP_P_000048749	WP3379	wiki	NA	RHO GTPases Activate Formins
RAMP_P_000048750	WP3320	wiki	NA	Miscellaneous transport and binding events
RAMP_P_000048751	WP3668	wiki	NA	Hypothesized Pathways in Pathogenesis of Cardiovascular Disease
RAMP_P_000048752	WP2792	wiki	NA	MAP kinase activation
RAMP_P_000048753	WP2371	wiki	NA	Parkinsons Disease Pathway
RAMP_P_000048754	WP1929	wiki	NA	Thrombin signalling through proteinase activated receptors (PARs)
RAMP_P_000048755	WP1872	wiki	NA	Neurotransmitter uptake and metabolism In glial cells
RAMP_P_000048756	WP3327	wiki	NA	SUMOylation of DNA damage response and repair proteins
RAMP_P_000048757	WP314	wiki	NA	Fas Ligand (FasL) pathway and Stress induction of Heat Shock Proteins (HSP) regulation
RAMP_P_000048758	WP231	wiki	NA	TNF alpha Signaling Pathway
RAMP_P_000048759	WP4121	wiki	NA	Neddylation
RAMP_P_000048760	WP2291	wiki	NA	Deregulation of Rab and Rab Effector Genes in Bladder Cancer
RAMP_P_000048761	WP2662	wiki	NA	Vasopressin regulates renal water homeostasis via Aquaporins
RAMP_P_000048762	WP4418	wiki	NA	Class C/3 (Metabotropic glutamate/pheromone receptors)
RAMP_P_000048763	WP1861	wiki	NA	mRNA Capping
RAMP_P_000048764	WP3345	wiki	NA	Resolution of Abasic Sites (AP sites)
RAMP_P_000048765	WP4331	wiki	NA	Neovascularisation processes
RAMP_P_000048766	WP4442	wiki	NA	Peroxisomal protein import
RAMP_P_000048767	WP1823	wiki	NA	GP1b-IX-V activation signalling
RAMP_P_000048768	WP4069	wiki	NA	Regulation of TLR by endogenous ligand
RAMP_P_000048769	WP4421	wiki	NA	Signaling by Retinoic Acid
RAMP_P_000048770	WP2846	wiki	NA	Proprotein convertase subtilisin/kexin type 9 (PCSK9) mediated LDL receptor degradation
RAMP_P_000048771	WP4300	wiki	NA	Extracellular vesicles in the crosstalk of cardiac cells
RAMP_P_000048772	WP3817	wiki	NA	Interleukin-20 family signaling
RAMP_P_000048773	WP2366	wiki	NA	Butyrate-induced histone acetylation
RAMP_P_000048774	WP4068	wiki	NA	Formation of xylulose-5-phosphate
RAMP_P_000048775	WP4297	wiki	NA	Thiamine metabolic pathways
RAMP_P_000048776	WP4342	wiki	NA	Vitamins A and D - action mechanisms
RAMP_P_000048777	WP1873	wiki	NA	Signaling by NTRK1 (TRKA)
RAMP_P_000048778	WP3556	wiki	NA	Branched-chain amino acid catabolism
RAMP_P_000048779	WP2775	wiki	NA	Toll-like Receptor Cascades
RAMP_P_000048780	WP2677	wiki	NA	Signaling by Type 1 Insulin-like Growth Factor 1 Receptor (IGF1R)
RAMP_P_000048781	WP528	wiki	NA	Acetylcholine Synthesis
RAMP_P_000048782	WP61	wiki	NA	Notch Signaling Pathway
RAMP_P_000048783	WP3286	wiki	NA	Copper homeostasis
RAMP_P_000048784	WP4135	wiki	NA	RNA Polymerase III Transcription
RAMP_P_000048785	WP2828	wiki	NA	Bladder Cancer
RAMP_P_000048786	WP3678	wiki	NA	Amplification and Expansion of Oncogenic Pathways as Metastatic Traits
RAMP_P_000048787	WP2586	wiki	NA	Aryl Hydrocarbon Receptor
RAMP_P_000048788	WP1812	wiki	NA	Eukaryotic Translation Initiation
RAMP_P_000048789	WP1946	wiki	NA	Cori Cycle
RAMP_P_000048790	WP692	wiki	NA	Sulfation Biotransformation Reaction
RAMP_P_000048791	WP4429	wiki	NA	NGF processing
RAMP_P_000048792	WP4066	wiki	NA	Interleukin-4 and Interleukin-13 signaling
RAMP_P_000048793	WP3811	wiki	NA	Smooth Muscle Contraction
RAMP_P_000048794	WP4223	wiki	NA	Ras Signaling
RAMP_P_000048795	WP4481	wiki	NA	Resistin as a regulator of inflammation
RAMP_P_000048796	WP4459	wiki	NA	Glutamate binding, activation of AMPA receptors and synaptic plasticity
RAMP_P_000048797	WP1829	wiki	NA	Immunoregulatory interactions between a Lymphoid and a non-Lymphoid cell
RAMP_P_000048798	WP4103	wiki	NA	Intestinal infectious diseases
RAMP_P_000048799	WP3822	wiki	NA	Metabolism of vitamin K
RAMP_P_000048800	WP3874	wiki	NA	Canonical and Non-Canonical TGF-B signaling
RAMP_P_000048801	WP3805	wiki	NA	SUMOylation of DNA replication proteins
RAMP_P_000048802	WP3658	wiki	NA	Wnt/beta-catenin Signaling Pathway in Leukemia
RAMP_P_000048803	WP4039	wiki	NA	Fructose metabolism
RAMP_P_000048804	WP734	wiki	NA	Serotonin Receptor 4/6/7 and NR3C Signaling
RAMP_P_000048805	WP4479	wiki	NA	Supression of HMGB1 mediated inflammation by THBD
RAMP_P_000048806	WP2720	wiki	NA	Signaling by NOTCH1
RAMP_P_000048807	WP3829	wiki	NA	rRNA processing
RAMP_P_000048808	WP2849	wiki	NA	Hematopoietic Stem Cell Differentiation
RAMP_P_000048809	WP1926	wiki	NA	Transport of glycerol from adipocytes to the liver by Aquaporins
RAMP_P_000048810	WP3839	wiki	NA	Retinoid metabolism and transport
RAMP_P_000048811	WP363	wiki	NA	Wnt Signaling Pathway
RAMP_P_000048812	WP3555	wiki	NA	Metabolism of polyamines
RAMP_P_000048813	WP1803	wiki	NA	DNA Damage Bypass
RAMP_P_000048814	WP2763	wiki	NA	Nucleotide-binding domain, leucine rich repeat containing receptor (NLR) signaling pathways
RAMP_P_000048815	WP545	wiki	NA	Complement Activation
RAMP_P_000048816	WP4436	wiki	NA	Signaling by NTRK2 (TRKB)
RAMP_P_000048817	WP1424	wiki	NA	Globo Sphingolipid Metabolism
RAMP_P_000048818	WP4425	wiki	NA	Tetrahydrobiopterin (BH4) synthesis, recycling, salvage and regulation
RAMP_P_000048819	WP3958	wiki	NA	GPR40 Pathway
RAMP_P_000048820	WP561	wiki	NA	Heme Biosynthesis
RAMP_P_000048821	WP3645	wiki	NA	NAD+ biosynthetic pathways
RAMP_P_000048822	WP1887	wiki	NA	Post-translational modification: synthesis of GPI-anchored proteins
RAMP_P_000048823	WP289	wiki	NA	Myometrial Relaxation and Contraction Pathways
RAMP_P_000048824	WP2821	wiki	NA	Transcriptional regulation of pluripotent stem cells
RAMP_P_000048825	WP4211	wiki	NA	Transcriptional cascade regulating adipogenesis
RAMP_P_000048826	WP1833	wiki	NA	Integrin cell surface interactions
RAMP_P_000048827	WP4451	wiki	NA	SUMOylation of SUMOylation proteins
RAMP_P_000048828	WP2203	wiki	NA	Thymic Stromal LymphoPoietin (TSLP) Signaling Pathway
RAMP_P_000048829	WP3380	wiki	NA	TNF signaling
RAMP_P_000048830	WP1939	wiki	NA	Unfolded Protein Response (UPR)
RAMP_P_000048831	WP465	wiki	NA	Tryptophan metabolism
RAMP_P_000048832	WP3399	wiki	NA	Base-Excision Repair, AP Site Formation
RAMP_P_000048833	WP2772	wiki	NA	S Phase
RAMP_P_000048834	WP2453	wiki	NA	TCA Cycle and Deficiency of Pyruvate Dehydrogenase complex (PDHc)
RAMP_P_000048835	WP4055	wiki	NA	E3 ubiquitin ligases ubiquitinate target proteins
RAMP_P_000048836	WP4134	wiki	NA	Processing of SMDT1
RAMP_P_000048837	WP1936	wiki	NA	Transport of inorganic cations/anions and amino acids/oligopeptides
RAMP_P_000048838	WP2943	wiki	NA	Hypoxia-mediated EMT and Stemness
RAMP_P_000048839	WP4082	wiki	NA	Nucleotide salvage
RAMP_P_000048840	WP4452	wiki	NA	Signaling by NTRK3 (TRKC)
RAMP_P_000048841	WP170	wiki	NA	Nuclear Receptors
RAMP_P_000048842	WP4506	wiki	NA	Tyrosine Metabolism
RAMP_P_000048843	WP2267	wiki	NA	Synaptic Vesicle Pathway
RAMP_P_000048844	WP4113	wiki	NA	Ketone body metabolism
RAMP_P_000048845	WP4228	wiki	NA	Vitamin B6-dependent and responsive disorders
RAMP_P_000048846	WP4088	wiki	NA	Mitochondrial calcium ion transport
RAMP_P_000048847	WP4089	wiki	NA	Plasmalogen biosynthesis
RAMP_P_000048848	WP3382	wiki	NA	POU5F1 (OCT4), SOX2, NANOG repress genes related to differentiation
RAMP_P_000048849	WP4292	wiki	NA	Methionine metabolism leading to Sulphur Amino Acids and related disorders
RAMP_P_000048850	WP4224	wiki	NA	Purine metabolism
RAMP_P_000048851	WP4094	wiki	NA	Collagen chain trimerization
RAMP_P_000048852	WP4041	wiki	NA	Other interleukin signaling
RAMP_P_000048853	WP357	wiki	NA	Fatty Acid Biosynthesis
RAMP_P_000048854	WP2721	wiki	NA	Signaling by NOTCH4
RAMP_P_000048855	WP3364	wiki	NA	SIRT1 negatively regulates rRNA expression
RAMP_P_000048856	WP2690	wiki	NA	Cytosolic iron-sulfur cluster assembly
RAMP_P_000048857	WP1871	wiki	NA	Neurotransmitter release cycle
RAMP_P_000048858	WP4072	wiki	NA	Glycogen metabolism
RAMP_P_000048859	WP2035	wiki	NA	Follicle Stimulating Hormone (FSH) signaling pathway
RAMP_P_000048860	WP3580	wiki	NA	Methionine De Novo and Salvage Pathway
RAMP_P_000048861	WP4222	wiki	NA	Phosphodiesterases in neuronal function
RAMP_P_000048862	WP3337	wiki	NA	RHO GTPases activate KTN1
RAMP_P_000048863	WP2817	wiki	NA	Mammary gland development pathway - Pregnancy and lactation (Stage 3 of 4)
RAMP_P_000048864	WP4299	wiki	NA	Lamin A-processing pathway
RAMP_P_000048865	WP732	wiki	NA	Serotonin Receptor 2 and ELK-SRF/GATA4 signaling
RAMP_P_000048866	WP1913	wiki	NA	Signaling by Insulin receptor
RAMP_P_000048867	WP1838	wiki	NA	Interleukin-1 processing
RAMP_P_000048868	WP2526	wiki	NA	PDGF Pathway
RAMP_P_000048869	WP3306	wiki	NA	Aflatoxin activation and detoxification
RAMP_P_000048870	WP2761	wiki	NA	MyD88:MAL(TIRAP) cascade initiated on plasma membrane
RAMP_P_000048871	WP3838	wiki	NA	Regulation of TP53 Activity through Phosphorylation
RAMP_P_000048872	WP4321	wiki	NA	Thermogenesis
RAMP_P_000048873	WP3793	wiki	NA	Lysosomal oligosaccharide catabolism
RAMP_P_000048874	WP2363	wiki	NA	Gastric Cancer Network 2
RAMP_P_000048875	WP2684	wiki	NA	Host Interactions of HIV factors
RAMP_P_000048876	WP4018	wiki	NA	Pathways in clear cell renal cell carcinoma
RAMP_P_000048877	WP4454	wiki	NA	Acetylcholine binding and downstream events
RAMP_P_000048878	WP410	wiki	NA	Exercise-induced Circadian Regulation
RAMP_P_000048879	WP2657	wiki	NA	Growth hormone receptor signaling
RAMP_P_000048880	WP3486	wiki	NA	Abnormal conversion of 2-oxoglutarate to 2-hydroxyglutarate
RAMP_P_000048881	WP4430	wiki	NA	COPII-mediated vesicle transport
RAMP_P_000048882	WP3814	wiki	NA	Metallothioneins bind metals
RAMP_P_000048883	WP4304	wiki	NA	Oligodendrocyte Specification and differentiation(including remyelination), leading to Myelin Components for CNS
RAMP_P_000048884	WP47	wiki	NA	Hedgehog Signaling Pathway
RAMP_P_000048885	WP1984	wiki	NA	Integrated Breast Cancer Pathway
RAMP_P_000048886	WP405	wiki	NA	Eukaryotic Transcription Initiation
RAMP_P_000048887	WP49	wiki	NA	IL-2 Signaling Pathway
RAMP_P_000048888	WP241	wiki	NA	One Carbon Metabolism
RAMP_P_000048889	WP75	wiki	NA	Toll-like Receptor Signaling Pathway
RAMP_P_000048890	WP2882	wiki	NA	Nuclear Receptors Meta-Pathway
RAMP_P_000048891	WP1836	wiki	NA	Interferon gamma signaling
RAMP_P_000048892	WP4422	wiki	NA	G alpha (z) signalling events
RAMP_P_000048893	WP2801	wiki	NA	MyD88 cascade initiated on plasma membrane
RAMP_P_000048894	WP2637	wiki	NA	Structural Pathway of Interleukin 1 (IL-1)
RAMP_P_000048895	WP4460	wiki	NA	OAS antiviral response
RAMP_P_000048896	WP4447	wiki	NA	SUMOylation of intracellular receptors
RAMP_P_000048897	WP4433	wiki	NA	TYSND1 cleaves peroxisomal proteins
RAMP_P_000048898	WP4063	wiki	NA	Interleukin-10 signaling
RAMP_P_000048899	WP2781	wiki	NA	Signaling by ERBB4
RAMP_P_000048900	WP2018	wiki	NA	RANKL/RANK (Receptor activator of NFKB (ligand)) Signaling Pathway
RAMP_P_000048901	WP4399	wiki	NA	MicroRNA network associated with chronic lymphocytic leukemia
RAMP_P_000048902	WP2038	wiki	NA	Regulation of Microtubule Cytoskeleton
RAMP_P_000048903	WP3802	wiki	NA	TP53 Regulates Transcription of Cell Death Genes
RAMP_P_000048904	WP3335	wiki	NA	Signaling by FGFR1
RAMP_P_000048905	WP2797	wiki	NA	Regulation of lipid metabolism by Peroxisome proliferator-activated receptor alpha (PPARalpha)
RAMP_P_000048906	WP3397	wiki	NA	Activated PKN1 stimulates transcription of AR (androgen receptor) regulated genes KLK2 and KLK3
RAMP_P_000048907	WP4190	wiki	NA	Mevalonate arm of cholesterol biosynthesis pathway
RAMP_P_000048908	WP4132	wiki	NA	RUNX1 regulates genes involved in megakaryocyte differentiation and platelet function
RAMP_P_000048909	WP3384	wiki	NA	RHO GTPases Activate Rhotekin and Rhophilins
RAMP_P_000048910	WP4101	wiki	NA	Antimicrobial peptides
RAMP_P_000048911	WP2855	wiki	NA	Dopaminergic Neurogenesis
RAMP_P_000048912	WP3577	wiki	NA	Class I MHC mediated antigen processing & presentation
RAMP_P_000048913	WP1908	wiki	NA	Signal amplification
RAMP_P_000048914	WP2868	wiki	NA	TCA Cycle Nutrient Utilization and Invasiveness of Ovarian Cancer
RAMP_P_000048915	WP3558	wiki	NA	Beta-catenin independent WNT signaling
RAMP_P_000048916	WP3287	wiki	NA	Overview of nanoparticle effects
RAMP_P_000048917	WP3336	wiki	NA	Signaling by FGFR3
RAMP_P_000048918	WP3297	wiki	NA	EV release from cardiac cells and their functional effects
RAMP_P_000048919	WP3547	wiki	NA	Amyloid fiber formation
RAMP_P_000048920	WP2272	wiki	NA	Pathogenic Escherichia coli infection
RAMP_P_000048921	WP2771	wiki	NA	Host Interactions with Influenza Factors
RAMP_P_000048922	WP3562	wiki	NA	Glyoxylate metabolism and glycine degradation
RAMP_P_000048923	WP4030	wiki	NA	SCFA and skeletal muscle substrate metabolism
RAMP_P_000048924	WP3	wiki	NA	Phytochemical activity on NRF2 transcriptional activation
RAMP_P_000048925	WP2328	wiki	NA	Allograft Rejection
RAMP_P_000048926	WP585	wiki	NA	Interferon type I signaling pathways
RAMP_P_000048927	WP496	wiki	NA	Steroid Biosynthesis
RAMP_P_000048928	WP4262	wiki	NA	Breast cancer pathway
RAMP_P_000048929	WP1541	wiki	NA	Energy Metabolism
RAMP_P_000048930	WP1868	wiki	NA	Netrin-1 signaling
RAMP_P_000048931	WP3934	wiki	NA	Leptin and adiponectin
RAMP_P_000048932	WP3634	wiki	NA	Insulin signalling in human adipocytes (normal condition)
RAMP_P_000048933	WP3807	wiki	NA	Regulation of TP53 Expression and Degradation
RAMP_P_000048934	WP382	wiki	NA	MAPK Signaling Pathway
RAMP_P_000048935	WP1892	wiki	NA	Protein folding
RAMP_P_000048936	WP2332	wiki	NA	Interleukin-11 Signaling Pathway
RAMP_P_000048937	WP4035	wiki	NA	Intestinal absorption
RAMP_P_000048938	WP3398	wiki	NA	TNFR2 non-canonical NF-kB pathway
RAMP_P_000048939	WP2669	wiki	NA	Potassium Channels
RAMP_P_000048940	WP3850	wiki	NA	Factors and pathways affecting insulin-like growth factor (IGF1)-Akt signaling
RAMP_P_000048941	WP35	wiki	NA	G Protein Signaling Pathways
RAMP_P_000048942	WP4058	wiki	NA	HSP90 chaperone cycle for steroid hormone receptors (SHR)
RAMP_P_000048943	WP306	wiki	NA	Focal Adhesion
RAMP_P_000048944	WP3845	wiki	NA	Canonical  and Non-canonical Notch signaling
RAMP_P_000048945	WP3828	wiki	NA	rRNA modification in the nucleus and cytosol
RAMP_P_000048946	WP4439	wiki	NA	Biosynthesis of DHA-derived SPMs
RAMP_P_000048947	WP3943	wiki	NA	Robo4 and VEGF Signaling Pathways Crosstalk
RAMP_P_000048948	WP3376	wiki	NA	RHO GTPases activate CIT
RAMP_P_000048949	WP4043	wiki	NA	Cellular hexose transport
RAMP_P_000048950	WP4073	wiki	NA	Protein methylation
RAMP_P_000048951	WP4456	wiki	NA	Activation of kainate receptors upon glutamate binding
RAMP_P_000048952	WP2858	wiki	NA	Ectoderm Differentiation
RAMP_P_000048953	WP2874	wiki	NA	Liver X Receptor Pathway
RAMP_P_000048954	WP1858	wiki	NA	Mitotic G1-G1/S phases
RAMP_P_000048955	WP3303	wiki	NA	RAC1/PAK1/p38/MMP2 Pathway
RAMP_P_000048956	WP4432	wiki	NA	ESR-mediated signaling
RAMP_P_000048957	WP691	wiki	NA	Tamoxifen metabolism
RAMP_P_000048958	WP3472	wiki	NA	XBP1(S) activates chaperone genes
RAMP_P_000048959	WP34	wiki	NA	Ovarian Infertility Genes
RAMP_P_000048960	WP3849	wiki	NA	MAPK  and NFkB Signalling Pathways Inhibited by Yersinia YopJ
RAMP_P_000048961	WP368	wiki	NA	Mitochondrial LC-Fatty Acid Beta-Oxidation
RAMP_P_000048962	WP704	wiki	NA	Methylation Pathways
RAMP_P_000048963	WP3302	wiki	NA	eIF5A regulation in response to inhibition of the nuclear export system
RAMP_P_000048964	WP4446	wiki	NA	SUMOylation of DNA methylation proteins
RAMP_P_000048965	WP3795	wiki	NA	Striated Muscle Contraction
RAMP_P_000048966	WP4420	wiki	NA	Class B/2 (Secretin family receptors)
RAMP_P_000048967	WP727	wiki	NA	Monoamine Transport
RAMP_P_000048968	WP4461	wiki	NA	DNA Replication Pre-Initiation
RAMP_P_000048969	WP98	wiki	NA	Prostaglandin Synthesis and Regulation
RAMP_P_000048970	WP4434	wiki	NA	Synthesis of Lipoxins (LX)
RAMP_P_000048971	WP2765	wiki	NA	Mitotic Telophase/Cytokinesis
RAMP_P_000048972	WP4195	wiki	NA	Phosphatidylcholine catabolism
RAMP_P_000048973	WP2361	wiki	NA	Gastric Cancer Network 1
RAMP_P_000048974	WP3359	wiki	NA	DNA methylation
RAMP_P_000048975	WP4444	wiki	NA	Biosynthesis of electrophilic ?-3 PUFA oxo-derivatives
RAMP_P_000048976	WP2826	wiki	NA	Cocaine metabolism
RAMP_P_000048977	WP4236	wiki	NA	Disorders of the Krebs cycle
RAMP_P_000048978	WP1865	wiki	NA	Myogenesis
RAMP_P_000048979	WP3584	wiki	NA	MECP2 and Associated Rett Syndrome
RAMP_P_000048980	WP1600	wiki	NA	Nicotine Metabolism
RAMP_P_000048981	WP3407	wiki	NA	FTO Obesity Variant Mechanism
RAMP_P_000048982	WP411	wiki	NA	mRNA Processing
RAMP_P_000048983	WP3401	wiki	NA	Hedgehog ligand biogenesis
RAMP_P_000048984	WP236	wiki	NA	Adipogenesis
RAMP_P_000048985	WP3859	wiki	NA	TGF-B Signaling in Thyroid Cells for Epithelial-Mesenchymal Transition
RAMP_P_000048986	WP3813	wiki	NA	Activation of anterior HOX genes in hindbrain development during early embryogenesis
RAMP_P_000048987	WP3799	wiki	NA	SUMOylation of chromatin organization proteins
RAMP_P_000048988	WP4189	wiki	NA	Mevalonate arm of cholesterol biosynthesis pathway with inhibitors
RAMP_P_000048989	WP3404	wiki	NA	Oxidative Stress Induced Senescence
RAMP_P_000048990	WP2798	wiki	NA	Assembly of collagen fibrils and other multimeric structures
RAMP_P_000048991	WP1780	wiki	NA	ABC-family proteins mediated transport
RAMP_P_000048992	WP3872	wiki	NA	Regulation of Apoptosis by Parathyroid Hormone-related Protein
RAMP_P_000048993	WP3915	wiki	NA	Angiopoietin Like Protein 8 Regulatory Pathway
RAMP_P_000048994	WP623	wiki	NA	Oxidative phosphorylation
RAMP_P_000048995	WP2879	wiki	NA	Farnesoid X Receptor  Pathway
RAMP_P_000048996	WP1798	wiki	NA	Complement cascade
RAMP_P_000048997	WP2679	wiki	NA	MHC class II antigen presentation
RAMP_P_000048998	WP4110	wiki	NA	Post-translational protein phosphorylation
RAMP_P_000048999	WP2778	wiki	NA	SUMOylation
RAMP_P_000049000	WP1815	wiki	NA	Factors involved in megakaryocyte development and platelet production
RAMP_P_000049001	WP2406	wiki	NA	Cardiac Progenitor Differentiation
RAMP_P_000049002	WP3358	wiki	NA	Caspase activation via Death Receptors in the presence of ligand
RAMP_P_000049003	WP2036	wiki	NA	TNF related weak inducer of apoptosis (TWEAK) Signaling Pathway
RAMP_P_000049004	WP3892	wiki	NA	Development of pulmonary dendritic cells and macrophage subsets
RAMP_P_000049005	WP4240	wiki	NA	Regulation of sister chromatid separation at the metaphase-anaphase transition
RAMP_P_000049006	WP3891	wiki	NA	Benzene metabolism
RAMP_P_000049007	WP4079	wiki	NA	RUNX1 and FOXP3 control the development of regulatory T lymphocytes (Tregs)
RAMP_P_000049008	WP497	wiki	NA	Urea cycle and metabolism of amino groups
RAMP_P_000049009	WP2813	wiki	NA	Mammary gland development pathway - Embryonic development (Stage 1 of 4)
RAMP_P_000049010	WP206	wiki	NA	Fatty Acid Omega Oxidation
RAMP_P_000049011	WP2029	wiki	NA	Cell Differentiation - Index
RAMP_P_000049012	WP1742	wiki	NA	TP53 Network
RAMP_P_000049013	WP615	wiki	NA	Senescence and Autophagy in Cancer
RAMP_P_000049014	WP4357	wiki	NA	NRF2-ARE regulation
RAMP_P_000049015	WP466	wiki	NA	DNA Replication
RAMP_P_000049016	WP134	wiki	NA	Pentose Phosphate Metabolism
RAMP_P_000049017	WP2840	wiki	NA	Hair Follicle Development: Cytodifferentiation (Part 3 of 3)
RAMP_P_000049018	WP733	wiki	NA	Serotonin Receptor 2 and STAT3 Signaling
RAMP_P_000049019	WP2654	wiki	NA	Mitotic Prophase
RAMP_P_000049020	WP3927	wiki	NA	BMP Signaling Pathway in Eyelid Development
RAMP_P_000049021	WP43	wiki	NA	Oxidation by Cytochrome P450
RAMP_P_000049022	WP3858	wiki	NA	Toll-like Receptor Signaling
RAMP_P_000049023	WP3969	wiki	NA	H19 action Rb-E2F1 signaling and CDK-Beta-catenin activity
RAMP_P_000049024	WP3549	wiki	NA	Mitophagy
RAMP_P_000049025	WP3305	wiki	NA	NoRC negatively regulates rRNA expression
RAMP_P_000049026	WP2876	wiki	NA	Pregnane X Receptor pathway
RAMP_P_000049027	WP2747	wiki	NA	PI Metabolism
RAMP_P_000049028	WP1937	wiki	NA	Transport of vitamins, nucleosides, and related molecules
RAMP_P_000049029	WP4119	wiki	NA	Listeria monocytogenes entry into host cells
RAMP_P_000049030	WP4249	wiki	NA	Hedgehog Signaling Pathway
RAMP_P_000049031	WP2714	wiki	NA	Signaling by Hippo
RAMP_P_000049032	WP2744	wiki	NA	Erythrocytes take up carbon dioxide and release oxygen
RAMP_P_000049033	WP3363	wiki	NA	Sialic acid metabolism
RAMP_P_000049034	WP1530	wiki	NA	miRNA Regulation of DNA Damage Response
RAMP_P_000049035	WP4504	wiki	NA	Cysteine and methionine catabolism
RAMP_P_000049036	WP366	wiki	NA	TGF-beta Signaling Pathway
RAMP_P_000049037	WP4102	wiki	NA	Deubiquitination
RAMP_P_000049038	WP2866	wiki	NA	mir34a and TGIF2 in osteoclastogenesis
RAMP_P_000049039	WP1793	wiki	NA	Cell junction organization
RAMP_P_000049040	WP2881	wiki	NA	Estrogen Receptor Pathway
RAMP_P_000049041	WP2700	wiki	NA	Latent infection of Homo sapiens with Mycobacterium tuberculosis
RAMP_P_000049042	WP3967	wiki	NA	miR-509-3p alteration of YAP1/ECM axis
RAMP_P_000049043	WP4153	wiki	NA	Degradation pathway of sphingolipids, including diseases
RAMP_P_000049044	WP2746	wiki	NA	Signaling by the B Cell Receptor (BCR)
RAMP_P_000049045	WP1841	wiki	NA	Intrinsic Pathway for Apoptosis
RAMP_P_000049046	WP2456	wiki	NA	HIF1A and PPARG regulation of glycolysis
RAMP_P_000049047	WP3318	wiki	NA	mTOR signalling
RAMP_P_000049048	WP4090	wiki	NA	Choline catabolism
RAMP_P_000049049	WP3806	wiki	NA	Metabolism of folate and pterines
RAMP_P_000049050	WP2536	wiki	NA	Colchicine Metabolic Pathway
RAMP_P_000049051	WP2249	wiki	NA	Metastatic brain tumor
RAMP_P_000049052	WP2664	wiki	NA	Gastrin-CREB signalling pathway via PKC and MAPK
RAMP_P_000049053	WP2697	wiki	NA	Fertilization
RAMP_P_000049054	WP1980	wiki	NA	Nucleotide Excision Repair
RAMP_P_000049055	WP3679	wiki	NA	Cell-type Dependent Selectivity of CCK2R Signaling
RAMP_P_000049056	WP3925	wiki	NA	Amino Acid metabolism
RAMP_P_000049057	WP2333	wiki	NA	Trans-sulfuration pathway
RAMP_P_000049058	WP3877	wiki	NA	Simplified Depiction of MYD88 Distinct Input-Output Pathway
RAMP_P_000049059	WP4126	wiki	NA	Galactose catabolism
RAMP_P_000049060	WP4100	wiki	NA	Gene and protein expression by JAK-STAT signaling after Interleukin-12 stimulation
RAMP_P_000049061	WP4197	wiki	NA	The human immune response to tuberculosis
RAMP_P_000049062	WP661	wiki	NA	Glucose Homeostasis
RAMP_P_000049063	WP2734	wiki	NA	Ubiquinol biosynthesis
RAMP_P_000049064	WP715	wiki	NA	Amino acid conjugation
RAMP_P_000049065	WP3865	wiki	NA	RIG-I-like Receptor Signaling
RAMP_P_000049066	WP3551	wiki	NA	ROS, RNS production in phagocytes
RAMP_P_000049067	WP2785	wiki	NA	M/G1 Transition
RAMP_P_000049068	WP702	wiki	NA	Metapathway biotransformation Phase I and II
RAMP_P_000049069	WP3875	wiki	NA	ATR Signaling
RAMP_P_000049070	WP4107	wiki	NA	Transcriptional regulation by RUNX3
RAMP_P_000049071	WP3791	wiki	NA	Selenoamino acid metabolism
RAMP_P_000049072	WP4034	wiki	NA	Mitochondrial Fatty Acid Beta-Oxidation
RAMP_P_000049073	WP4087	wiki	NA	Keratinization
RAMP_P_000049074	WP2816	wiki	NA	Felbamate Metabolism
RAMP_P_000049075	WP4186	wiki	NA	Somatroph axis (GH) and its relationship to dietary restriction and aging
RAMP_P_000049076	WP3349	wiki	NA	TP53 Regulates Metabolic Genes
RAMP_P_000049077	WP1910	wiki	NA	Signaling by EGFR
RAMP_P_000049078	WP304	wiki	NA	Kit receptor signaling pathway
RAMP_P_000049079	WP3310	wiki	NA	Mitochondrial translation
RAMP_P_000049080	WP2729	wiki	NA	Metabolism of Angiotensinogen to Angiotensins
RAMP_P_000049081	WP1528	wiki	NA	Physiological and Pathological Hypertrophy  of the Heart
RAMP_P_000049082	WP2659	wiki	NA	Deadenylation-dependent mRNA decay
RAMP_P_000049083	WP1797	wiki	NA	Circadian Clock
RAMP_P_000049084	WP325	wiki	NA	Triacylglyceride Synthesis
RAMP_P_000049085	WP4131	wiki	NA	Triglyceride metabolism
RAMP_P_000049086	WP2672	wiki	NA	ISG15 antiviral mechanism
RAMP_P_000049087	WP4480	wiki	NA	Role Altered Glycolysation of MUC1 in Tumour Microenvironment
RAMP_P_000049088	WP3317	wiki	NA	Caspase activation via Dependence Receptors in the absence of ligand
RAMP_P_000049089	WP195	wiki	NA	IL-1 signaling pathway
RAMP_P_000049090	WP4445	wiki	NA	SUMOylation of transcription cofactors
RAMP_P_000049091	WP4449	wiki	NA	SUMOylation of immune response proteins
RAMP_P_000049092	WP3351	wiki	NA	RHO GTPases activate PAKs
RAMP_P_000049093	WP3816	wiki	NA	Regulation of TP53 Activity through Acetylation
RAMP_P_000049094	WP2799	wiki	NA	Regulation of Insulin-like Growth Factor (IGF) transport and uptake by Insulin-like Growth Factor Binding Proteins (IGFBPs)
RAMP_P_000049095	WP404	wiki	NA	Nucleotide Metabolism
RAMP_P_000049096	WP2736	wiki	NA	Insulin processing
RAMP_P_000049097	WP2749	wiki	NA	Metabolism of steroid hormones
RAMP_P_000049098	WP4106	wiki	NA	Cristae formation
RAMP_P_000049099	WP2380	wiki	NA	Brain-Derived Neurotrophic Factor (BDNF) signaling pathway
RAMP_P_000049100	WP3888	wiki	NA	VEGFA-VEGFR2 Signaling Pathway
RAMP_P_000049101	WP554	wiki	NA	ACE Inhibitor Pathway
RAMP_P_000049102	WP4397	wiki	NA	Model for regulation of MSMP expression in cancer cells and its proangiogenic role in ovarian tumors
RAMP_P_000049103	WP696	wiki	NA	Benzo(a)pyrene metabolism
RAMP_P_000049104	WP1781	wiki	NA	Advanced glycosylation endproduct receptor signaling
RAMP_P_000049105	WP3933	wiki	NA	Kennedy pathway from Sphingolipids
RAMP_P_000049106	WP4336	wiki	NA	ncRNAs involved in Wnt signaling in hepatocellular carcinoma
RAMP_P_000049107	WP3640	wiki	NA	Imatinib and Chronic Myeloid Leukemia
RAMP_P_000049108	WP3414	wiki	NA	Initiation of transcription and translation elongation at the HIV-1 LTR
RAMP_P_000049109	WP4462	wiki	NA	Platelet-mediated interactions with vascular and circulating cells
RAMP_P_000049110	WP2646	wiki	NA	Lidocaine metabolism
RAMP_P_000049111	WP3863	wiki	NA	T-Cell antigen Receptor (TCR) pathway during Staphylococcus aureus infection
RAMP_P_000049112	WP117	wiki	NA	GPCRs, Other
RAMP_P_000049113	WP3938	wiki	NA	miR-222 in Exercise-Induced Cardiac Growth
RAMP_P_000049114	WP4065	wiki	NA	Clathrin-mediated endocytosis
RAMP_P_000049115	WP1840	wiki	NA	Interleukin-3, Interleukin-5 and GM-CSF signaling
RAMP_P_000049116	WP237	wiki	NA	Glucocorticoid and Mineralcorticoid Metabolism
RAMP_P_000049117	WP1874	wiki	NA	Nucleosome assembly
RAMP_P_000049118	WP26	wiki	NA	Signal Transduction of S1P Receptor
RAMP_P_000049119	WP3571	wiki	NA	Gene Silencing by RNA
RAMP_P_000049120	WP2516	wiki	NA	ATM Signaling Pathway
RAMP_P_000049121	WP1471	wiki	NA	Target Of Rapamycin (TOR) Signaling
RAMP_P_000049122	WP4042	wiki	NA	Nucleobase catabolism
RAMP_P_000049123	WP51	wiki	NA	Regulation of Actin Cytoskeleton
RAMP_P_000049124	WP4064	wiki	NA	Intracellular oxygen transport
RAMP_P_000049125	WP2112	wiki	NA	IL17 signaling pathway
RAMP_P_000049126	WP4053	wiki	NA	TBC/RABGAPs
RAMP_P_000049127	WP2509	wiki	NA	Nanoparticle triggered autophagic cell death
RAMP_P_000049128	WP3929	wiki	NA	Chemokine signaling pathway
RAMP_P_000049129	WP3937	wiki	NA	Microglia Pathogen Phagocytosis Pathway
RAMP_P_000049130	WP707	wiki	NA	DNA Damage Response
RAMP_P_000049131	WP3809	wiki	NA	tRNA processing in the mitochondrion
RAMP_P_000049132	WP3612	wiki	NA	Photodynamic therapy-induced NFE2L2 (NRF2) survival signaling
RAMP_P_000049133	WP2369	wiki	NA	Histone Modifications
RAMP_P_000049134	WP1584	wiki	NA	Type II diabetes mellitus
RAMP_P_000049135	WP4083	wiki	NA	Reelin signalling pathway
RAMP_P_000049136	WP2814	wiki	NA	Mammary gland development pathway - Puberty (Stage 2 of 4)
RAMP_P_000049137	WP4400	wiki	NA	FABP4 in ovarian cancer
RAMP_P_000049138	WP1591	wiki	NA	Heart Development
RAMP_P_000049139	WP3627	wiki	NA	Gut-Liver Indole Metabolism 
RAMP_P_000049140	WP2289	wiki	NA	Drug Induction of Bile Acid Pathway
RAMP_P_000049141	WP4486	wiki	NA	Carnosine's role in mucle contraction
RAMP_P_000049142	WP4120	wiki	NA	Signaling by MET
RAMP_P_000049143	WP3413	wiki	NA	NOTCH1 regulation of human endothelial cell calcification
RAMP_P_000049144	WP2794	wiki	NA	Cytosolic sensors of pathogen-associated DNA 
RAMP_P_000049145	WP69	wiki	NA	T-Cell antigen Receptor (TCR)  Signaling Pathway
RAMP_P_000049146	WP4206	wiki	NA	Hereditary leiomyomatosis and renal cell carcinoma pathway
RAMP_P_000049147	WP3996	wiki	NA	Ethanol effects on histone modifications
RAMP_P_000049148	WP2815	wiki	NA	Mammary gland development pathway - Involution (Stage 4 of 4)
RAMP_P_000049149	WP1604	wiki	NA	Codeine and Morphine Metabolism
RAMP_P_000049150	WP3944	wiki	NA	Serotonin and anxiety-related events
RAMP_P_000049151	WP3676	wiki	NA	BDNF-TrkB Signaling
RAMP_P_000049152	WP3370	wiki	NA	RORA activates gene expression
RAMP_P_000049153	WP1795	wiki	NA	Cholesterol biosynthesis
RAMP_P_000049154	WP4047	wiki	NA	PTEN Regulation
RAMP_P_000049155	WP3567	wiki	NA	HDR through Homologous Recombination (HRR) or Single Strand Annealing (SSA)
RAMP_P_000049156	WP3931	wiki	NA	ESC Pluripotency Pathways
RAMP_P_000049157	WP78	wiki	NA	TCA Cycle (aka Krebs or citric acid cycle)
RAMP_P_000049158	WP3591	wiki	NA	Sleep regulation
RAMP_P_000049159	WP2261	wiki	NA	Signaling Pathways in Glioblastoma
RAMP_P_000049160	WP2197	wiki	NA	Endothelin Pathways
RAMP_P_000049161	WP4337	wiki	NA	ncRNAs involved in STAT3 signaling in hepatocellular carcinoma
RAMP_P_000049162	WP501	wiki	NA	GPCRs, Class C Metabotropic glutamate, pheromone
RAMP_P_000049163	WP4061	wiki	NA	Import of palmitoyl-CoA into the mitochondrial matrix
RAMP_P_000049164	WP4159	wiki	NA	GABA receptor Signaling
RAMP_P_000049165	WP1991	wiki	NA	SRF and miRs in Smooth Muscle Differentiation and Proliferation
RAMP_P_000049166	WP3790	wiki	NA	Wax biosynthesis
RAMP_P_000049167	WP4485	wiki	NA	Modified nucleosides derived from t-RNA as urinary cancer markers
RAMP_P_000049168	WP3377	wiki	NA	Melanin biosynthesis
RAMP_P_000049169	WP1775	wiki	NA	Cell Cycle Checkpoints
RAMP_P_000049170	WP3941	wiki	NA	Oxidative Damage
RAMP_P_000049171	WP474	wiki	NA	Endochondral Ossification
RAMP_P_000049172	WP3633	wiki	NA	Caffeine and Theobromine metabolism
RAMP_P_000049173	WP4259	wiki	NA	Disorders of Folate Metabolism and Transport
RAMP_P_000049174	WP3585	wiki	NA	Cytosine methylation
RAMP_P_000049175	WP3331	wiki	NA	Mitochondrial biogenesis
RAMP_P_000049176	WP430	wiki	NA	Statin Pathway
RAMP_P_000049177	WP4141	wiki	NA	PI3K/AKT/mTOR - VitD3 Signalling
RAMP_P_000049178	WP1916	wiki	NA	Signaling by PDGF
RAMP_P_000049179	WP706	wiki	NA	Sudden Infant Death Syndrome (SIDS) Susceptibility Pathways
RAMP_P_000049180	WP2786	wiki	NA	Pre-NOTCH Expression and Processing
RAMP_P_000049181	WP2675	wiki	NA	Signaling by NODAL
RAMP_P_000049182	WP3971	wiki	NA	Role of Osx and miRNAs in tooth development
RAMP_P_000049183	WP2873	wiki	NA	Aryl Hydrocarbon Receptor Pathway
RAMP_P_000049184	WP4085	wiki	NA	Phase I - Functionalization of compounds
RAMP_P_000049185	WP129	wiki	NA	Matrix Metalloproteinases
RAMP_P_000049186	WP1785	wiki	NA	Asparagine N-linked glycosylation
RAMP_P_000049187	WP2774	wiki	NA	Degradation of the extracellular matrix
RAMP_P_000049188	WP4084	wiki	NA	Nucleobase biosynthesis
RAMP_P_000049189	WP2742	wiki	NA	Signaling by TGF-beta Receptor Complex
RAMP_P_000049190	WP1800	wiki	NA	Presynaptic depolarization and calcium channel opening
RAMP_P_000049191	WP4426	wiki	NA	G alpha (12/13) signalling events
RAMP_P_000049192	WP3674	wiki	NA	Tgif disruption of Shh signaling
RAMP_P_000049193	WP3360	wiki	NA	Uptake and function of diphtheria toxin
RAMP_P_000049194	WP197	wiki	NA	Cholesterol Biosynthesis Pathway
RAMP_P_000049195	WP3981	wiki	NA	miRNA regulation of prostate cancer signaling pathways
RAMP_P_000049196	WP3685	wiki	NA	Vitamin D (calciferol) metabolism
RAMP_P_000049197	WP3812	wiki	NA	SALM protein interactions at the synapse
RAMP_P_000049198	WP3871	wiki	NA	Valproic acid pathway
RAMP_P_000049199	WP143	wiki	NA	Fatty Acid Beta Oxidation
RAMP_P_000049200	WP2722	wiki	NA	Signaling by NOTCH3
RAMP_P_000049201	WP3810	wiki	NA	Cardiac conduction
RAMP_P_000049202	WP4050	wiki	NA	Pentose phosphate pathway
RAMP_P_000049203	WP4096	wiki	NA	Chromatin organization
RAMP_P_000049204	WP3436	wiki	NA	Synthesis, secretion, and deacylation of Ghrelin
RAMP_P_000049205	WP3820	wiki	NA	Interleukin-17 signaling
RAMP_P_000049206	WP4052	wiki	NA	Interleukin-12 family signaling
RAMP_P_000049207	WP4428	wiki	NA	G-protein beta:gamma signalling
RAMP_P_000049208	WP3594	wiki	NA	Circadian rhythm related genes
RAMP_P_000049209	WP3372	wiki	NA	TET1,2,3 and TDG demethylate DNA
RAMP_P_000049210	WP4048	wiki	NA	NADPH regeneration
RAMP_P_000049211	WP2784	wiki	NA	Binding and Uptake of Ligands by Scavenger Receptors
RAMP_P_000049212	WP3942	wiki	NA	PPAR signaling pathway
RAMP_P_000049213	WP4156	wiki	NA	Biosynthesis and regeneration of tetrahydrobiopterin (BH4) and catabolism of phenylalanine, including diseases
RAMP_P_000049214	WP1904	wiki	NA	DDX58/IFIH1-mediated induction of interferon-alpha/beta
RAMP_P_000049215	WP3827	wiki	NA	RNA polymerase II transcribes snRNA genes
RAMP_P_000049216	WP4220	wiki	NA	Neurotransmitter Disorders
RAMP_P_000049217	WP3312	wiki	NA	PRC2 methylates histones and DNA
RAMP_P_000049218	WP2728	wiki	NA	Incretin synthesis, secretion, and inactivation
RAMP_P_000049219	WP1883	wiki	NA	Platelet Adhesion to exposed collagen
RAMP_P_000049220	WP3893	wiki	NA	Development and heterogeneity of the ILC family
RAMP_P_000049221	WP262	wiki	NA	EBV LMP1 signaling
RAMP_P_000049222	WP1909	wiki	NA	Signal regulatory protein family interactions
RAMP_P_000049223	WP1907	wiki	NA	Semaphorin interactions
RAMP_P_000049224	WP138	wiki	NA	Androgen receptor signaling pathway
RAMP_P_000049225	WP3926	wiki	NA	ApoE and miR-146 in inflammation and atherosclerosis
RAMP_P_000049226	WP1885	wiki	NA	Platelet homeostasis
RAMP_P_000049227	WP4146	wiki	NA	Macrophage markers
RAMP_P_000049228	WP3529	wiki	NA	Zinc homeostasis
RAMP_P_000049229	WP2889	wiki	NA	Oxytocin signaling
RAMP_P_000049230	WP2916	wiki	NA	Interactome of polycomb repressive complex 2 (PRC2) 
RAMP_P_000049231	WP2773	wiki	NA	Degradation of beta-catenin by the destruction complex
RAMP_P_000049232	WP1826	wiki	NA	GPVI-mediated activation cascade
RAMP_P_000049233	WP4404	wiki	NA	Interleukin-15 signaling
RAMP_P_000049234	WP4038	wiki	NA	Transcription from mitochondrial promoters
RAMP_P_000049235	WP2748	wiki	NA	Energy dependent regulation of mTOR by LKB1-AMPK
RAMP_P_000049236	WP3613	wiki	NA	Photodynamic therapy-induced unfolded protein response
RAMP_P_000049237	WP2735	wiki	NA	RAF/MAP kinase cascade
RAMP_P_000049238	WP3635	wiki	NA	Insulin signalling in human adipocytes (diabetic condition)
RAMP_P_000049239	WP3935	wiki	NA	Leptin Insulin Overlap
RAMP_P_000049240	WP2650	wiki	NA	Arachidonic acid metabolism
RAMP_P_000049241	WP2658	wiki	NA	HIV Life Cycle
RAMP_P_000049242	WP1799	wiki	NA	Costimulation by the CD28 family
RAMP_P_000049243	WP2596	wiki	NA	Gastric acid production
RAMP_P_000049244	WP58	wiki	NA	Monoamine GPCRs
RAMP_P_000049245	WP3578	wiki	NA	trans-Golgi Network Vesicle Budding
RAMP_P_000049246	WP4095	wiki	NA	RET signaling
RAMP_P_000049247	WP536	wiki	NA	Calcium Regulation in the Cardiac Cell
RAMP_P_000049248	WP2709	wiki	NA	Trafficking and processing of endosomal TLR
RAMP_P_000049249	WP2942	wiki	NA	DDX1 as a regulatory component of the Drosha microprocessor
RAMP_P_000049250	WP3963	wiki	NA	Mevalonate pathway
RAMP_P_000049251	WP1902	wiki	NA	Respiratory electron transport, ATP synthesis by chemiosmotic coupling, and heat production by uncoupling proteins.
RAMP_P_000049252	WP4239	wiki	NA	Epithelial to mesenchymal transition in colorectal cancer
RAMP_P_000049253	WP3593	wiki	NA	MicroRNA for Targeting Cancer Growth and Vascularization in Glioblastoma
RAMP_P_000049254	WP299	wiki	NA	Nuclear Receptors in Lipid Metabolism and Toxicity
RAMP_P_000049255	WP4415	wiki	NA	Transcriptional regulation by RUNX2
RAMP_P_000049256	WP2686	wiki	NA	Regulation of cholesterol biosynthesis by SREBP (SREBF)
RAMP_P_000049257	WP4286	wiki	NA	Genotoxicity pathway
RAMP_P_000049258	WP1903	wiki	NA	Response to elevated platelet cytosolic Ca2+
RAMP_P_000049259	WP2683	wiki	NA	Influenza Life Cycle
RAMP_P_000049260	WP4210	wiki	NA	Tryptophan catabolism leading to NAD+ production
RAMP_P_000049261	WP673	wiki	NA	ErbB Signaling Pathway
RAMP_P_000049262	WP1495	wiki	NA	Glycine Metabolism
RAMP_P_000049263	WP3561	wiki	NA	tRNA modification in the nucleus and cytosol
RAMP_P_000049264	WP3794	wiki	NA	SUMOylation of RNA binding proteins
RAMP_P_000049265	WP4036	wiki	NA	MTF1 activates gene expression
RAMP_P_000049266	WP2864	wiki	NA	Apoptosis-related network due to altered Notch3 in ovarian cancer
RAMP_P_000049267	WP2059	wiki	NA	Alzheimers Disease
RAMP_P_000049268	WP2731	wiki	NA	Meiotic synapsis
RAMP_P_000049269	WP3672	wiki	NA	LncRNA-mediated mechanisms of therapeutic resistance
RAMP_P_000049270	WP3352	wiki	NA	Toll Like Receptor 3 (TLR3) Cascade
RAMP_P_000049271	WP2740	wiki	NA	Glycerophospholipid biosynthesis
RAMP_P_000049272	WP4122	wiki	NA	Interleukin-6 family signaling
RAMP_P_000049273	WP2431	wiki	NA	Spinal Cord Injury
RAMP_P_000049274	WP3348	wiki	NA	Macroautophagy
RAMP_P_000049275	WP4414	wiki	NA	Regulation of RUNX2 expression and activity
RAMP_P_000049276	WP4150	wiki	NA	Wnt Signaling in Kidney Disease
RAMP_P_000049277	WP3498	wiki	NA	Assembly of the primary cilium
RAMP_P_000049278	WP4457	wiki	NA	GABA receptor activation
RAMP_P_000049279	WP4204	wiki	NA	Tumor suppressor activity of SMARCB1
RAMP_P_000049280	WP3798	wiki	NA	Regulation of TP53 Activity through Association with Co-factors
RAMP_P_000049281	WP2011	wiki	NA	SREBF and miR33 in cholesterol and lipid homeostasis
RAMP_P_000049282	WP3655	wiki	NA	Hypothetical Craniofacial Development Pathway
RAMP_P_000049283	WP2753	wiki	NA	ATF4 activates genes
RAMP_P_000049284	WP3333	wiki	NA	POU5F1 (OCT4), SOX2, NANOG activate genes related to proliferation
RAMP_P_000049285	WP4288	wiki	NA	MTHFR deficiency
RAMP_P_000049286	WP2791	wiki	NA	Signaling by Activin
RAMP_P_000049287	WP4133	wiki	NA	Neurexins and neuroligins
RAMP_P_000049288	WP3322	wiki	NA	RHO GTPases regulate CFTR trafficking
RAMP_P_000049289	WP2777	wiki	NA	Translocation of SLC2A4 (GLUT4) to the plasma membrane
RAMP_P_000049290	WP4093	wiki	NA	Glucose metabolism
RAMP_P_000049291	WP2653	wiki	NA	PIP3 activates AKT signaling
RAMP_P_000049292	WP690	wiki	NA	Polyol Pathway
RAMP_P_000049293	WP2759	wiki	NA	Fc epsilon receptor (FCERI) signaling
RAMP_P_000049294	WP3819	wiki	NA	B-WICH complex positively regulates rRNA expression
RAMP_P_000049295	WP1839	wiki	NA	Interleukin-1 family signaling
RAMP_P_000049296	WP3995	wiki	NA	Prion disease pathway
RAMP_P_000049297	WP2713	wiki	NA	Signaling by SCF-KIT
RAMP_P_000049298	WP2712	wiki	NA	Abacavir transport and metabolism
RAMP_P_000049299	WP4205	wiki	NA	MET in type 1 papillary renal cell carcinoma
RAMP_P_000049300	WP2583	wiki	NA	T-Cell Receptor and Co-stimulatory Signaling
RAMP_P_000049301	WP24	wiki	NA	Peptide GPCRs
RAMP_P_000049302	WP2878	wiki	NA	PPAR Alpha Pathway
RAMP_P_000049303	WP3527	wiki	NA	Preimplantation Embryo
RAMP_P_000049304	WP4312	wiki	NA	Rett syndrome causing genes
RAMP_P_000049305	WP4435	wiki	NA	Serine biosynthesis
RAMP_P_000049306	WP2743	wiki	NA	Glycosaminoglycan metabolism
RAMP_P_000049307	WP4114	wiki	NA	Fatty acyl-CoA biosynthesis
RAMP_P_000049308	WP1982	wiki	NA	Sterol Regulatory Element-Binding Proteins (SREBP) signalling
RAMP_P_000049309	WP3844	wiki	NA	PI3K-AKT-mTOR signaling pathway and therapeutic opportunities
RAMP_P_000049310	WP1559	wiki	NA	TFs Regulate miRNAs related to cardiac hypertrophy
RAMP_P_000049311	WP4507	wiki	NA	Molybdenum cofactor (Moco) biosynthesis
RAMP_P_000049312	WP4225	wiki	NA	Pyrimidine metabolism and related diseases
RAMP_P_000049313	WP516	wiki	NA	Hypertrophy Model
RAMP_P_000049314	WP2724	wiki	NA	alpha-linolenic (omega3) and linoleic (omega6) acid metabolism
RAMP_P_000049315	WP2037	wiki	NA	Prolactin Signaling Pathway
RAMP_P_000049316	WP1455	wiki	NA	Serotonin Transporter Activity
RAMP_P_000049317	WP2766	wiki	NA	The citric acid (TCA) cycle and respiratory electron transport
RAMP_P_000049318	WP1866	wiki	NA	NCAM signaling for neurite out-growth
RAMP_P_000049319	WP2751	wiki	NA	Transcriptional regulation of white adipocyte differentiation
RAMP_P_000049320	WP2738	wiki	NA	YAP1- and WWTR1 (TAZ)-stimulated gene expression
RAMP_P_000049321	WP2666	wiki	NA	Elastic fibre formation
RAMP_P_000049322	WP534	wiki	NA	Glycolysis and Gluconeogenesis
RAMP_P_000049323	WP4455	wiki	NA	Activation of NMDA receptors and postsynaptic events
RAMP_P_000049324	WP2023	wiki	NA	Cell Differentiation - Index expanded
RAMP_P_000049325	WP1589	wiki	NA	Folate-Alcohol and Cancer Pathway Hypotheses
RAMP_P_000049326	WP2656	wiki	NA	TAK1 activates NFkB by phosphorylation and activation of IKKs complex
RAMP_P_000049327	WP2895	wiki	NA	Differentiation of white and brown adipocyte   
RAMP_P_000049328	WP1852	wiki	NA	Metabolism of porphyrins
RAMP_P_000049329	WP4104	wiki	NA	Digestion
RAMP_P_000049330	WP395	wiki	NA	IL-4 Signaling Pathway
RAMP_P_000049331	WP3569	wiki	NA	Fanconi Anemia Pathway
RAMP_P_000049332	WP2875	wiki	NA	Constitutive Androstane Receptor Pathway
RAMP_P_000049333	WP1434	wiki	NA	Osteopontin Signaling
RAMP_P_000049334	WP2710	wiki	NA	Nonsense-Mediated Decay (NMD)
RAMP_P_000049335	WP1981	wiki	NA	Thyroxine (Thyroid Hormone) Production
RAMP_P_000049336	WP2652	wiki	NA	Mitotic Prometaphase
RAMP_P_000049337	WP1425	wiki	NA	Bone Morphogenic Protein (BMP) Signalling and Regulation
RAMP_P_000049338	WP3823	wiki	NA	Regulation of TP53 Activity through Methylation
RAMP_P_000049339	WP28	wiki	NA	Selenium Metabolism and Selenoproteins
RAMP_P_000049340	WP3651	wiki	NA	Pathways Affected in Adenoid Cystic Carcinoma
RAMP_P_000049341	WP1971	wiki	NA	Integrated Cancer Pathway
RAMP_P_000049342	WP4216	wiki	NA	Chromosomal and microsatellite instability in colorectal cancer 
RAMP_P_000049343	WP3394	wiki	NA	NR1D1 (REV-ERBA) represses gene expression
RAMP_P_000049344	WP3568	wiki	NA	FasL/ CD95L signaling
RAMP_P_000049345	WP3574	wiki	NA	Sulfur amino acid metabolism
RAMP_P_000049346	WP4458	wiki	NA	Signaling by Erythropoietin
RAMP_P_000049347	WP2694	wiki	NA	DAP12 interactions
RAMP_P_000049348	WP4111	wiki	NA	Phase II - Conjugation of compounds
RAMP_P_000049349	WP2854	wiki	NA	Gene regulatory network modelling somitogenesis 
RAMP_P_000049350	WP1842	wiki	NA	Kinesins
RAMP_P_000049351	WP4080	wiki	NA	Cargo recognition for clathrin-mediated endocytosis
RAMP_P_000049352	WP2324	wiki	NA	AGE/RAGE pathway
RAMP_P_000049353	WP2643	wiki	NA	Nanoparticle-mediated activation of receptor signaling
RAMP_P_000049354	WP4172	wiki	NA	PI3K-Akt Signaling Pathway
RAMP_P_000049355	WP3932	wiki	NA	Focal Adhesion-PI3K-Akt-mTOR-signaling pathway
RAMP_P_000049356	WP1422	wiki	NA	Sphingolipid pathway
RAMP_P_000049357	WP2118	wiki	NA	Arrhythmogenic Right Ventricular Cardiomyopathy
RAMP_P_000049358	WP1603	wiki	NA	Nicotine Activity on Chromaffin Cells
RAMP_P_000049359	WP3824	wiki	NA	SUMOylation of transcription factors
RAMP_P_000049360	WP4329	wiki	NA	miRNAs involvement in the immune response in sepsis
RAMP_P_000049361	WP3553	wiki	NA	Synthesis of wybutosine at G37 of tRNA(Phe)
RAMP_P_000049362	WP2338	wiki	NA	miRNA Biogenesis
RAMP_P_000049363	WP1935	wiki	NA	Transport of bile salts and organic acids, metal ions and amine compounds
RAMP_P_000049364	WP4074	wiki	NA	RNA Polymerase I Transcription
RAMP_P_000049365	WP3818	wiki	NA	Signaling by MST1
RAMP_P_000049366	WP698	wiki	NA	Glucuronidation
RAMP_P_000049367	WP2787	wiki	NA	Syndecan interactions
RAMP_P_000049368	WP244	wiki	NA	Alpha 6 Beta 4 signaling pathway
RAMP_P_000049369	WP1822	wiki	NA	Generic Transcription Pathway
RAMP_P_000049370	WP2762	wiki	NA	Gamma carboxylation, hypusine formation and arylsulfatase activation
RAMP_P_000049371	WP2636	wiki	NA	Common Pathways Underlying Drug Addiction
RAMP_P_000049372	WP247	wiki	NA	Small Ligand GPCRs
RAMP_P_000049373	WP4112	wiki	NA	Vitamin E
RAMP_P_000049374	WP437	wiki	NA	EGF/EGFR Signaling Pathway
RAMP_P_000049375	WP4269	wiki	NA	Ethanol metabolism resulting in production of ROS by CYP2E1
RAMP_P_000049376	WP2688	wiki	NA	DAG and IP3 signaling
RAMP_P_000049377	WP1927	wiki	NA	TCR signaling
RAMP_P_000049378	WP400	wiki	NA	p38 MAPK Signaling Pathway
RAMP_P_000049379	WP2733	wiki	NA	Regulation of mRNA stability by proteins that bind AU-rich elements
RAMP_P_000049380	WP3611	wiki	NA	Photodynamic therapy-induced AP-1 survival signaling.
RAMP_P_000049381	WP2806	wiki	NA	Human Complement System
RAMP_P_000049382	WP4437	wiki	NA	Signaling by PTK6
RAMP_P_000049383	WP619	wiki	NA	Type II interferon signaling (IFNG)
RAMP_P_000049384	WP3599	wiki	NA	Transcription factor regulation in adipogenesis
RAMP_P_000049385	WP3392	wiki	NA	LGI-ADAM interactions
RAMP_P_000049386	WP3876	wiki	NA	BMP2-WNT4-FOXO1 Pathway in Human Primary Endometrial Stromal Cell Differentiation
RAMP_P_000049387	WP4440	wiki	NA	Biosynthesis of EPA-derived SPMs
RAMP_P_000049388	WP4427	wiki	NA	G alpha (s) signalling events
RAMP_P_000049389	WP3564	wiki	NA	Amino acid synthesis and interconversion (transamination)
RAMP_P_000049390	WP1804	wiki	NA	DNA Damage Reversal
RAMP_P_000049391	WP167	wiki	NA	Eicosanoid Synthesis
RAMP_P_000049392	WP176	wiki	NA	Folate Metabolism
RAMP_P_000049393	WP3604	wiki	NA	Biochemical Pathways Part I
RAMP_P_000049394	WP3959	wiki	NA	DNA IR-Double Strand Breaks (DSBs) and cellular response via ATM
RAMP_P_000049395	WP2436	wiki	NA	Dopamine metabolism
RAMP_P_000049396	WP4117	wiki	NA	Regulation of RUNX1 Expression and Activity
RAMP_P_000049397	WP22	wiki	NA	IL-9 Signaling Pathway
RAMP_P_000049398	WP107	wiki	NA	Translation Factors
RAMP_P_000049399	WP3801	wiki	NA	ERCC6 (CSB) and EHMT2 (G9a) positively regulate rRNA expression
RAMP_P_000049400	WP1813	wiki	NA	Eukaryotic Translation Termination
RAMP_P_000049401	WP531	wiki	NA	DNA Mismatch Repair
RAMP_P_000049402	WP550	wiki	NA	Biogenic Amine Synthesis
RAMP_P_000049403	WP3388	wiki	NA	RHO GTPases Activate WASPs and WAVEs
RAMP_P_000049404	WP4438	wiki	NA	Biosynthesis of DPA-derived SPMs
RAMP_P_000049405	WP2670	wiki	NA	Iron uptake and transport
RAMP_P_000049406	WP45	wiki	NA	G1 to S cell cycle control
RAMP_P_000049407	WP1602	wiki	NA	Nicotine Activity on Dopaminergic Neurons
RAMP_P_000049408	WP4271	wiki	NA	Vitamin B12 Disorders
RAMP_P_000049409	WP581	wiki	NA	EPO Receptor Signaling
RAMP_P_000049410	WP179	wiki	NA	Cell Cycle
RAMP_P_000049411	WP2870	wiki	NA	Extracellular vesicle-mediated signaling in recipient cells
RAMP_P_000049412	WP2007	wiki	NA	Iron metabolism in placenta
RAMP_P_000049413	WP2853	wiki	NA	Endoderm Differentiation
RAMP_P_000049414	WP1884	wiki	NA	Platelet Aggregation (Plug Formation)
RAMP_P_000049415	WP2805	wiki	NA	exRNA mechanism of action and biogenesis
RAMP_P_000049416	WP4016	wiki	NA	DNA IR-damage and cellular response via ATR
RAMP_P_000049417	WP3596	wiki	NA	miR-517 relationship with ARCN1 and USP1
RAMP_P_000049418	WP4086	wiki	NA	Transcriptional regulation by the AP-2 (TFAP2) family of transcription factors
RAMP_P_000049419	WP1862	wiki	NA	mRNA Editing
RAMP_P_000049420	WP4341	wiki	NA	Non-genomic actions of 1,25 dihydroxyvitamin D3
RAMP_P_000049421	WP3339	wiki	NA	TCF dependent signaling in response to WNT
RAMP_P_000049422	WP2533	wiki	NA	Glycerophospholipid Biosynthetic Pathway
RAMP_P_000049423	WP2824	wiki	NA	Detoxification of Reactive Oxygen Species
RAMP_P_000049424	WP3930	wiki	NA	EDA Signalling in Hair Follicle Development
RAMP_P_000049425	WP1403	wiki	NA	AMP-activated Protein Kinase (AMPK) Signaling
RAMP_P_000049426	WP3330	wiki	NA	RHO GTPases activate IQGAPs
RAMP_P_000049427	WP4155	wiki	NA	Endometrial cancer
RAMP_P_000049428	WP3357	wiki	NA	RHO GTPases activate PKNs
RAMP_P_000049429	WP1818	wiki	NA	Formation of Fibrin Clot (Clotting Cascade)
RAMP_P_000049430	WP4352	wiki	NA	Ciliary landscape
RAMP_P_000049431	WP2525	wiki	NA	Trans-sulfuration and one carbon metabolism
RAMP_P_000049432	WP4129	wiki	NA	Plasma lipoprotein assembly, remodeling, and clearance
RAMP_P_000049433	WP4109	wiki	NA	Regulation of mitotic cell cycle
RAMP_P_000049434	WP254	wiki	NA	Apoptosis
RAMP_P_000049435	WP127	wiki	NA	IL-5 Signaling Pathway
RAMP_P_000049436	WP1925	wiki	NA	Synthesis of DNA
RAMP_P_000049437	WP1794	wiki	NA	Cell surface interactions at the vascular wall
RAMP_P_000049438	WP4075	wiki	NA	Carboxyterminal post-translational modifications of tubulin
RAMP_P_000049439	WP3400	wiki	NA	TRAIL  signaling
RAMP_P_000049440	WP4098	wiki	NA	Ion channel transport
RAMP_P_000049441	WP2718	wiki	NA	Signaling by NOTCH2
RAMP_P_000049442	WP4070	wiki	NA	RAB GEFs exchange GTP for GDP on RABs
RAMP_P_000049443	WP422	wiki	NA	MAPK Cascade
RAMP_P_000049444	WP3575	wiki	NA	Endosomal Sorting Complex Required For Transport (ESCRT)
RAMP_P_000049445	WP1423	wiki	NA	Ganglio Sphingolipid Metabolism
RAMP_P_000049446	WP3851	wiki	NA	TLR4 Signaling and Tolerance
RAMP_P_000049447	WP2752	wiki	NA	MyD88-independent TLR4 cascade 
RAMP_P_000049448	WP322	wiki	NA	Osteoblast Signaling
RAMP_P_000049449	WP3879	wiki	NA	4-hydroxytamoxifen, Dexamethasone, and Retinoic Acids Regulation of p27 Expression
RAMP_P_000049450	WP4443	wiki	NA	p75 NTR receptor-mediated signalling
RAMP_P_000049451	WP453	wiki	NA	Inflammatory Response Pathway
RAMP_P_000049452	WP4037	wiki	NA	Pyrophosphate hydrolysis
RAMP_P_000049453	WP712	wiki	NA	Estrogen signaling pathway
RAMP_P_000049454	WP4157	wiki	NA	GHB metabolic pathway
RAMP_P_000049455	WP4313	wiki	NA	Ferroptosis
RAMP_P_000049456	WP3308	wiki	NA	Oncogene Induced Senescence
RAMP_P_000049457	WP1895	wiki	NA	Rap1 signalling
RAMP_P_000049458	WP2725	wiki	NA	Collagen biosynthesis and modifying enzymes
RAMP_P_000049459	WP2702	wiki	NA	Mitochondrial iron-sulfur cluster biogenesis
RAMP_P_000049460	WP477	wiki	NA	Cytoplasmic Ribosomal Proteins
RAMP_P_000049461	WP2012	wiki	NA	miRs in Muscle Cell Differentiation
RAMP_P_000049462	WP3579	wiki	NA	Surfactant metabolism
RAMP_P_000049463	WP4091	wiki	NA	Butyrophilin (BTN) family interactions
RAMP_P_000049464	WP438	wiki	NA	Non-homologous end joining
RAMP_P_000049465	WP4431	wiki	NA	Integrin alphaIIb beta3 signaling
RAMP_P_000049466	WP3982	wiki	NA	miRNA regulation of p53 pathway in prostate cancer
RAMP_P_000049467	WP3396	wiki	NA	RHO GTPases Activate NADPH Oxidases
RAMP_P_000049468	WP23	wiki	NA	B Cell Receptor Signaling Pathway
RAMP_P_000049469	WP1544	wiki	NA	MicroRNAs in cardiomyocyte hypertrophy
RAMP_P_000049470	WP100	wiki	NA	Glutathione metabolism
RAMP_P_000049471	WP4448	wiki	NA	PI3K Cascade
RAMP_P_000049472	WP3646	wiki	NA	Hepatitis C and Hepatocellular Carcinoma
RAMP_P_000049473	WP2678	wiki	NA	Prolactin receptor signaling
RAMP_P_000049474	WP3299	wiki	NA	let-7 inhibition of ES cell reprogramming
RAMP_P_000049475	WP268	wiki	NA	Notch Signaling
RAMP_P_000049476	WP3656	wiki	NA	Interleukin-1 Induced Activation of NF-kappa-B
RAMP_P_000049477	WP558	wiki	NA	Complement and Coagulation Cascades
RAMP_P_000049478	WP530	wiki	NA	Cytokines and Inflammatory Response
RAMP_P_000049479	WP2064	wiki	NA	Neural Crest Differentiation
RAMP_P_000049480	WP3543	wiki	NA	DNA Double Strand Break Response
RAMP_P_000049481	WP3374	wiki	NA	Signaling by Leptin
RAMP_P_000049482	WP1531	wiki	NA	Vitamin D Metabolism
RAMP_P_000049483	WP1928	wiki	NA	Telomere Maintenance
RAMP_P_000049484	WP3315	wiki	NA	O-linked glycosylation
RAMP_P_000049485	WP3391	wiki	NA	Senescence-Associated Secretory Phenotype (SASP)
RAMP_P_000049486	WP4105	wiki	NA	Transcriptional regulation by RUNX1
RAMP_P_000049487	WP3408	wiki	NA	Evolocumab Mechanism
RAMP_P_000049488	WP4441	wiki	NA	COPI-mediated anterograde transport
RAMP_P_000049489	WP1918	wiki	NA	Signaling by ROBO receptors
RAMP_P_000049490	WP1877	wiki	NA	Passive transport by Aquaporins
RAMP_P_000049491	WP3595	wiki	NA	mir-124 predicted interactions with cell cycle and differentiation 
RAMP_P_000049492	WP3924	wiki	NA	Hfe effect on hepcidin production
RAMP_P_000049493	WP1978	wiki	NA	Opioid Signalling
RAMP_P_000049494	WP3334	wiki	NA	Signaling by FGFR4
RAMP_P_000049495	WP2757	wiki	NA	Mitotic Metaphase and Anaphase
RAMP_P_000049496	WP3808	wiki	NA	TP53 Regulates Transcription of DNA Repair Genes
RAMP_P_000049497	WP4217	wiki	NA	Ebola Virus Pathway on Host
RAMP_P_000049498	WP2359	wiki	NA	Parkin-Ubiquitin Proteasomal System pathway
RAMP_P_000049499	WP3300	wiki	NA	Dual hijack model of Vif in HIV infection
RAMP_P_000049500	WP1539	wiki	NA	Angiogenesis
RAMP_P_000049501	WP1857	wiki	NA	Metabolism of water-soluble vitamins and cofactors
RAMP_P_000049502	WP4136	wiki	NA	Fibrin Complement Receptor 3 Signaling Pathway
RAMP_P_000049503	WP3853	wiki	NA	ERK Pathway in Huntington's Disease
RAMP_P_000049504	WP4255	wiki	NA	Non-small cell lung cancer
RAMP_P_000049505	WP2715	wiki	NA	Metabolism of non-coding RNA
RAMP_P_000049506	WP4258	wiki	NA	LncRNA involvement in canonical Wnt signaling and colorectal cancer
RAMP_P_000049507	WP560	wiki	NA	TGF-beta Receptor Signaling
RAMP_P_000049508	WP3301	wiki	NA	MFAP5-mediated ovarian cancer cell motility and invasiveness
RAMP_P_000049509	WP1934	wiki	NA	Transmission across Electrical Synapses 
RAMP_P_000049510	WP2446	wiki	NA	Retinoblastoma Gene in Cancer
RAMP_P_000049511	WP3684	wiki	NA	tRNA modification in the mitochondrion
RAMP_P_000049512	WP3965	wiki	NA	Lipid Metabolism Pathway
RAMP_P_000049513	WP4284	wiki	NA	Ultraconserved region 339 modulation of tumor suppressor microRNAs in cancer
RAMP_P_000049514	WP4263	wiki	NA	Pancreatic adenocarcinoma pathway
RAMP_P_000049515	WP2911	wiki	NA	miRNA targets in ECM and membrane receptors
RAMP_P_000049516	WP3803	wiki	NA	Threonine catabolism
RAMP_P_000049517	WP4233	wiki	NA	Acrylamide Biotransformation and Exposure Biomarkers
RAMP_P_000049518	WP4108	wiki	NA	Aryl hydrocarbon receptor signalling
RAMP_P_000049519	WP2374	wiki	NA	Oncostatin M Signaling Pathway
RAMP_P_000049520	WP4290	wiki	NA	Metabolic reprogramming in colon cancer
RAMP_P_000049521	WP3601	wiki	NA	Composition of Lipid Particles
RAMP_P_000049522	WP3804	wiki	NA	TP53 Regulates Transcription of Cell Cycle Genes
RAMP_P_000049523	WP3316	wiki	NA	Hedgehog 'off' state
RAMP_P_000049524	WP4059	wiki	NA	Interconversion of nucleotide di- and triphosphates
RAMP_P_000049525	WP1843	wiki	NA	L1CAM interactions
RAMP_P_000049526	WP678	wiki	NA	Arachidonate Epoxygenase / Epoxide Hydrolase
RAMP_P_000049527	WP2572	wiki	NA	Primary Focal Segmental Glomerulosclerosis FSGS
RAMP_P_000049528	WP3998	wiki	NA	Prader-Willi and Angelman Syndrome
RAMP_P_000049529	WP1889	wiki	NA	Processing of Capped Intron-Containing Pre-mRNA
RAMP_P_000049530	WP1938	wiki	NA	tRNA Aminoacylation
RAMP_P_000049531	WP4241	wiki	NA	Type 2 papillary renal cell carcinoma
RAMP_P_000049532	WP2673	wiki	NA	Interleukin-7 signaling
RAMP_P_000049533	WP2857	wiki	NA	Mesodermal Commitment Pathway
RAMP_P_000049534	WP3390	wiki	NA	Uptake and function of anthrax toxins
RAMP_P_000049535	WP2755	wiki	NA	Transcriptional activity of SMAD2/SMAD3:SMAD4 heterotrimer
RAMP_P_000049536	WP3614	wiki	NA	Photodynamic therapy-induced HIF-1 survival signaling
RAMP_P_000049537	WP3800	wiki	NA	Protein repair
RAMP_P_000049538	WP3664	wiki	NA	Regulation of Wnt/B-catenin Signaling by Small Molecule Compounds
RAMP_P_000049539	WP334	wiki	NA	GPCRs, Class B Secretin-like
RAMP_P_000049540	WP15	wiki	NA	Selenium Micronutrient Network
RAMP_P_000049541	WP1433	wiki	NA	Nucleotide-binding Oligomerization Domain (NOD) pathway
RAMP_P_000049542	WP1898	wiki	NA	Regulation of DNA replication
RAMP_P_000049543	WP3313	wiki	NA	Hedgehog 'on' state
RAMP_P_000049544	WP399	wiki	NA	Wnt Signaling Pathway and Pluripotency
RAMP_P_000049545	WP1788	wiki	NA	Bile acid and bile salt metabolism
RAMP_P_000049546	WP1811	wiki	NA	Eukaryotic Translation Elongation
RAMP_P_000049547	WP3940	wiki	NA	One carbon metabolism and related pathways
RAMP_P_000049548	WP3624	wiki	NA	Lung fibrosis
RAMP_P_000049549	WP699	wiki	NA	Aflatoxin B1 metabolism
RAMP_P_000049550	WP3332	wiki	NA	RAF-independent MAPK1/3 activation
RAMP_P_000049551	WP3570	wiki	NA	HDR through MMEJ (alt-NHEJ)
RAMP_P_000049552	WP1906	wiki	NA	RNA Polymerase II Transcription
RAMP_P_000049553	WP2795	wiki	NA	Cardiac Hypertrophic Response
RAMP_P_000049554	WP4324	wiki	NA	Mitochondrial complex I assembly model OXPHOS system
RAMP_P_000049555	WP1850	wiki	NA	Metabolism of nitric oxide
RAMP_P_000049556	WP2719	wiki	NA	Fcgamma receptor (FCGR) dependent phagocytosis
RAMP_P_000049557	WP2760	wiki	NA	Signaling by BMP
RAMP_P_000049558	WP4191	wiki	NA	Caloric restriction and aging
RAMP_P_000049559	WP2770	wiki	NA	Reversible hydration of carbon dioxide
RAMP_P_000049560	WP4487	wiki	NA	Ophthalmate biosynthesis in hepatocytes
RAMP_P_000049561	WP3869	wiki	NA	Cannabinoid receptor signaling
RAMP_P_000049562	WP4148	wiki	NA	Splicing factor NOVA regulated synaptic proteins
RAMP_P_000049563	WP697	wiki	NA	Estrogen metabolism
RAMP_P_000049564	WP4125	wiki	NA	Protein ubiquitination
RAMP_P_000049565	WP3298	wiki	NA	Melatonin metabolism and effects
RAMP_P_000049566	WP455	wiki	NA	GPCRs, Class A Rhodopsin-like
RAMP_P_000049567	WP3972	wiki	NA	PDGFR-beta pathway
RAMP_P_000049568	WP205	wiki	NA	IL-7 Signaling Pathway
RAMP_P_000049569	WP2884	wiki	NA	NRF2 pathway
RAMP_P_000049570	WP1820	wiki	NA	Gap junction trafficking and regulation
RAMP_P_000049571	WP4194	wiki	NA	Hormonal control of Pubertal Growth Spurt
RAMP_P_000049572	WP3945	wiki	NA	TYROBP Causal Network
RAMP_P_000049573	WP2706	wiki	NA	Activation of gene expression by SREBF (SREBP)
RAMP_P_000049574	WP4147	wiki	NA	PTF1A related regulatory pathway
RAMP_P_000049575	WP2507	wiki	NA	Nanomaterial induced apoptosis
RAMP_P_000049576	WP2698	wiki	NA	Meiotic recombination
RAMP_P_000049577	WP3307	wiki	NA	MAPK6/MAPK4 signaling
RAMP_P_000049578	WP12	wiki	NA	Osteoclast Signaling
RAMP_P_000049579	WP4482	wiki	NA	Vitamin D in inflammatory diseases
RAMP_P_000049580	WP4116	wiki	NA	Lactose synthesis
RAMP_P_000049581	WP364	wiki	NA	IL-6 signaling pathway
RAMP_P_000049582	WP2790	wiki	NA	WNT ligand biogenesis and trafficking
RAMP_P_000049583	WP1601	wiki	NA	Fluoropyrimidine Activity
RAMP_P_000049584	WP3395	wiki	NA	Cellular response to heat stress
RAMP_P_000049585	WP3350	wiki	NA	TNFs bind their physiological receptors
RAMP_P_000049586	WP4051	wiki	NA	Lipid particle organization
RAMP_P_000049587	WP2788	wiki	NA	Sphingolipid metabolism
RAMP_P_000049588	WP716	wiki	NA	Vitamin A and Carotenoid Metabolism
RAMP_P_000049589	WP1789	wiki	NA	Insulin-like Growth Factor-2 mRNA Binding Proteins (IGF2BPs/IMPs/VICKZs) bind RNA
RAMP_P_000049590	WP408	wiki	NA	Oxidative Stress
RAMP_P_000049591	WP2681	wiki	NA	Erythrocytes take up oxygen and release carbon dioxide
RAMP_P_000049592	WP2691	wiki	NA	Peptide hormone biosynthesis
RAMP_P_000049593	WP3947	wiki	NA	Serotonin and anxiety
RAMP_P_000049594	WP391	wiki	NA	Mitochondrial Gene Expression
RAMP_P_000049595	WP3383	wiki	NA	Regulated Necrosis
RAMP_P_000049596	WP313	wiki	NA	Signaling of Hepatocyte Growth Factor Receptor
RAMP_P_000049597	WP3602	wiki	NA	Human metabolism overview
RAMP_P_000049598	WP1802	wiki	NA	Dissolution of Fibrin Clot
RAMP_P_000049599	WP1809	wiki	NA	Effects of PIP2 hydrolysis
RAMP_P_000049600	WP1896	wiki	NA	Regulation of Apoptosis
RAMP_P_000049601	WP4419	wiki	NA	Class A/1 (Rhodopsin-like receptors)
RAMP_P_000049602	WP4142	wiki	NA	Metabolism of Spingolipids in ER and Golgi apparatus
RAMP_P_000049603	WP4450	wiki	NA	SUMOylation of ubiquitinylation proteins
RAMP_P_000049604	WP710	wiki	NA	DNA Damage Response (only ATM dependent)
RAMP_P_000049605	WP2769	wiki	NA	Activation of Matrix Metalloproteinases
RAMP_P_000049606	WP2737	wiki	NA	SRP-dependent cotranslational protein targeting to membrane
RAMP_P_000049607	WP2513	wiki	NA	Nanoparticle triggered regulated necrosis
RAMP_P_000049608	WP3842	wiki	NA	Intra-Golgi and retrograde Golgi-to-ER traffic
RAMP_P_000049609	WP4097	wiki	NA	Nicotinate metabolism
RAMP_P_000049610	WP1835	wiki	NA	Interferon alpha/beta signaling
RAMP_P_000049611	WP1831	wiki	NA	Integration of energy metabolism
RAMP_P_000049612	WP4149	wiki	NA	White fat cell differentiation
RAMP_P_000049613	WP2877	wiki	NA	Vitamin D Receptor Pathway
RAMP_P_000049614	WP2776	wiki	NA	Visual phototransduction
RAMP_P_000049615	WP1845	wiki	NA	MAPK targets/ Nuclear events mediated by MAP kinases
RAMP_P_000049616	WP1995	wiki	NA	Effects of Nitric Oxide
RAMP_P_000049617	WP2447	wiki	NA	Amyotrophic lateral sclerosis (ALS)
RAMP_P_000049618	WP2290	wiki	NA	RalA downstream regulated genes
RAMP_P_000049619	WP3797	wiki	NA	Major pathway of rRNA processing in the nucleolus and cytosol
RAMP_P_000049620	WP1890	wiki	NA	Processing of Capped Intronless Pre-mRNA
RAMP_P_000049621	WP2640	wiki	NA	Aripiprazole Metabolic Pathway
RAMP_P_000049622	WP2542	wiki	NA	Sulindac Metabolic Pathway
RAMP_P_000049623	WP1867	wiki	NA	Nephrin family interactions
RAMP_P_000049624	WP4301	wiki	NA	Inhibition of exosome biogenesis and secretion by Manumycin A in CRPC cells
RAMP_P_000049625	WP3355	wiki	NA	BMAL1:CLOCK,NPAS2 activates circadian gene expression
RAMP_P_000049626	WP1859	wiki	NA	Mitotic G2-G2/M phases
RAMP_P_000049627	WP688	wiki	NA	Catalytic cycle of mammalian Flavin-containing MonoOxygenases (FMOs)
RAMP_P_000049628	WP2655	wiki	NA	ATF6 (ATF6-alpha) activates chaperone genes
RAMP_P_000049629	WP500	wiki	NA	Glycogen Synthesis and Degradation
RAMP_P_000049630	WP3630	wiki	NA	NAD metabolism, sirtuins and aging
RAMP_P_000049631	WP481	wiki	NA	Insulin Signaling
RAMP_P_000049632	WP1919	wiki	NA	Signaling by VEGF
RAMP_P_000049633	WP521	wiki	NA	Amino acid conjugation of benzoic acid
RAMP_P_000049634	WP384	wiki	NA	Apoptosis Modulation by HSP70
RAMP_P_000049635	WP694	wiki	NA	Arylamine metabolism
RAMP_P_000049636	WP2665	wiki	NA	Neurotoxicity of clostridium toxins
RAMP_P_000049637	WP2717	wiki	NA	Mitochondrial protein import
RAMP_P_000049638	WP2732	wiki	NA	Interleukin-2 family signaling
RAMP_P_000049639	WP288	wiki	NA	NLR Proteins
RAMP_P_000049640	WP4022	wiki	NA	Pyrimidine metabolism
RAMP_P_000049641	WP3365	wiki	NA	RHO GTPases Activate ROCKs
RAMP_P_000049642	WP286	wiki	NA	IL-3 Signaling Pathway
RAMP_P_000049643	WP3513	wiki	NA	Regulation of beta-cell development
RAMP_P_000049644	WP311	wiki	NA	Synthesis and Degradation of Ketone Bodies
RAMP_P_000049645	WP4409	wiki	NA	Interleukin-9 signaling
RAMP_P_000049646	WP2671	wiki	NA	Defensins
RAMP_P_000049647	WP1545	wiki	NA	miRNAs involved in DNA damage response
RAMP_P_000049648	WP2355	wiki	NA	Corticotropin-releasing hormone signaling pathway
RAMP_P_000049649	WP1533	wiki	NA	Vitamin B12 Metabolism
RAMP_P_000049650	WP2276	wiki	NA	Glial Cell Differentiation
RAMP_P_000049651	WP183	wiki	NA	Proteasome Degradation
RAMP_P_000049652	WP2865	wiki	NA	IL1 and megakaryocytes in obesity
RAMP_P_000049653	WP2780	wiki	NA	Signaling by ERBB2
RAMP_P_000049654	WP3617	wiki	NA	Photodynamic therapy-induced NF-kB survival signaling
RAMP_P_000049655	WP3381	wiki	NA	Mismatch Repair
RAMP_P_000049656	WP4054	wiki	NA	Synaptic adhesion-like molecules
